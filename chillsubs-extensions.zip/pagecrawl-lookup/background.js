// background.js
// Reads config from extension storage and proxies lookup requests to your backend API.
// Your backend should connect to MongoDB using DATABASE_URL and return the magazine id/url.

const DEFAULT_LOOKUP_URL = "https://page.chillsubs.com/api/magazine-lookup";
// const DEFAULT_LOOKUP_URL = "http://localhost:3000/api/magazine-lookup";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "LOOKUP_MAGAZINE") {
    handleLookup(request.name, request.pagecrawlUrl).then(sendResponse).catch((err) => {
      sendResponse({ error: err.message });
    });
    return true; // keeps the message channel open for async response
  }
});

async function handleLookup(name, pagecrawlUrl) {
  // Load config from extension storage (set via popup)
  const config = await getConfig();

  if (!config.lookupUrl) {
    throw new Error("Extension not configured. Click the extension icon to set up.");
  }

  const headers = {
    "Content-Type": "application/json",
  };

  if (config.apiToken) {
    headers.Authorization = `Bearer ${config.apiToken}`;
  }

  const response = await fetch(config.lookupUrl, {
    method: "POST",
    headers,
    body: JSON.stringify({ name, pagecrawlUrl }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Lookup API error ${response.status}: ${text}`);
  }

  const data = await response.json();

  if (data.found === false) {
    return { found: false };
  }

  const id = data.id || data._id || data?.document?._id;
  const url = data.url || (id ? `https://admin.chillsubs.com/magazines/${id}/calls` : null);
  const calls = data.calls || null;

  if (!id && !url) {
    return { found: false };
  }

  return {
    found: true,
    id,
    url,
    calls,
    lastAudited: data.lastAudited || null,
  };
}

function getConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["lookupUrl", "apiToken"], (result) =>
      resolve({ ...result, lookupUrl: result.lookupUrl || DEFAULT_LOOKUP_URL }),
    );
  });
}
