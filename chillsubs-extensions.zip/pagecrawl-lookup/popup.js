// popup.js
const fields = ["lookupUrl", "apiToken"];

// Load saved values
chrome.storage.local.get(fields, (saved) => {
  fields.forEach((f) => {
    if (saved[f]) document.getElementById(f).value = saved[f];
  });
});

document.getElementById("save").addEventListener("click", () => {
  const values = {};
  fields.forEach((f) => {
    values[f] = document.getElementById(f).value.trim();
  });

  chrome.storage.local.set(values, () => {
    const status = document.getElementById("status");
    status.textContent = "✅ Saved!";
    setTimeout(() => (status.textContent = ""), 2000);
  });
});
