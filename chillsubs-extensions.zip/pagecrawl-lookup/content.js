// content.js
const ATTR = "data-chillsubs-injected";

async function injectLink(h4El) {
  if (h4El.hasAttribute(ATTR)) return;
  h4El.setAttribute(ATTR, "true");

  const name = h4El.textContent.trim();
  if (!name) return;

  chrome.runtime.sendMessage(
    { type: "LOOKUP_MAGAZINE", name, pagecrawlUrl: window.location.href },
    (response) => {
      if (chrome.runtime.lastError) {
        console.warn("[ChillSubs] Extension error:", chrome.runtime.lastError.message);
        return;
      }

      if (!response || !response.found) {
        console.info(`[ChillSubs] No magazine found for: "${name}"`);
        return;
      }

      if (h4El.querySelector("[data-chillsubs-inline-link]")) return;

      const link = createInlineLink(response.url);
      h4El.appendChild(link);

      if (response.calls) {
        waitForSiblingDiv(h4El, (siblingDiv) => {
          injectCallsSpan(siblingDiv, response.calls, response.lastAudited);
        });
      }
    },
  );
}

function waitForSiblingDiv(h4El, callback) {
  const parent = h4El.parentElement;
  if (!parent) return;

  const existing = parent.nextElementSibling;
  if (existing && existing.tagName === "DIV") {
    callback(existing);
    return;
  }

  const grandparent = parent.parentElement;
  if (!grandparent) return;

  const observer = new MutationObserver(() => {
    const div = parent.nextElementSibling;
    if (div && div.tagName === "DIV") {
      observer.disconnect();
      callback(div);
    }
  });

  observer.observe(grandparent, { childList: true });
  setTimeout(() => observer.disconnect(), 3000);
}

function createInlineLink(href) {
  const el = document.createElement("a");
  el.href = href;
  el.target = "_blank";
  el.rel = "noopener noreferrer";
  el.textContent = " chillsubs →";
  el.setAttribute("data-chillsubs-inline-link", "true");

  Object.assign(el.style, {
    marginLeft: "6px",
    fontSize: "0.9em",
    fontWeight: "600",
    textDecoration: "none",
    color: "#0057ff",
    whiteSpace: "nowrap",
  });

  el.addEventListener("mouseenter", () => (el.style.textDecoration = "underline"));
  el.addEventListener("mouseleave", () => (el.style.textDecoration = "none"));

  return el;
}

function injectCallsSpan(div, calls, lastAudited) {
  if (div.querySelector("[data-chillsubs-calls]")) return;

  const wrapper = document.createElement("span");
  wrapper.setAttribute("data-chillsubs-calls", "true");

  Object.assign(wrapper.style, {
    cursor: "pointer",
    position: "relative",
    display: "inline-block",
  });

  const label = document.createElement("span");
  label.textContent = `Calls: ${calls.status ?? "unknown"}`;

  Object.assign(label.style, {
    fontSize: "0.85em",
    fontWeight: "600",
    color: "#0057ff",
  });

  const tooltip = document.createElement("span");
  // calls.calls is an array — show count + stringify for hover detail
  const callCount = Array.isArray(calls.calls) ? calls.calls.length : null;
  tooltip.textContent =
    callCount !== null
      ? callCount === 0
        ? "No open calls"
        : `${callCount} call${callCount > 1 ? "s" : ""}:\n${calls.calls
            .map((c) =>
              (
                c.titleGenreStyle + " " +
                  (c.status
                    ? c.status == "open"
                      ? c.closeDate
                        ? c.closeDate
                        : "open"
                      : c.status
                    : "unknown") 
                  + (c.fee ? `| ${c.fee}` : "")  
                    ||
                JSON.stringify(c) ||
                ""
              )
                .toString()
                .replace(/\s+/g, " ")
                .trim(),
            )
            .filter(Boolean)
            .join("\n")}`
      : (calls.calls ?? "No details available");

  Object.assign(tooltip.style, {
    display: "none",
    position: "absolute",
    top: "calc(100% + 6px)",
    bottom: "auto",
    left: "0",
    backgroundColor: "#1a1a1a",
    color: "#fff",
    padding: "5px 10px",
    borderRadius: "6px",
    fontSize: "0.78em",
    whiteSpace: "pre-line",
    zIndex: "9999",
    boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
    pointerEvents: "none",
    maxWidth: "500px",
    minWidth: "300px",
    width: "max-content",
  });

  wrapper.appendChild(label);
  wrapper.appendChild(tooltip);

  wrapper.addEventListener("mouseenter", () => (tooltip.style.display = "block"));
  wrapper.addEventListener("mouseleave", () => (tooltip.style.display = "none"));

  div.appendChild(wrapper);

  if (lastAudited) {
    const auditedSpan = document.createElement("span");
    auditedSpan.setAttribute("data-chillsubs-last-audited", "true");
    auditedSpan.textContent = `Last audited: ${lastAudited}`;

    Object.assign(auditedSpan.style, {
      marginLeft: "8px",
      // fontSize: "0.85em",
      // fontWeight: "600",
      color: "#666",
    });

    div.appendChild(auditedSpan);
  }
}

function processAll() {
  document.querySelectorAll("h4.ant-typography").forEach(injectLink);
}

const observer = new MutationObserver(processAll);
observer.observe(document.body, { childList: true, subtree: true });

processAll();
