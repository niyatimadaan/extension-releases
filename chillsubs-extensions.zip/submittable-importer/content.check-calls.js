(() => {
  const ns = window.ChillSubsExt;

  ns.getOwnerCheckHtml = function getOwnerCheckHtml(owner) {
    if (!owner?.id) return '';
    const ownerId = ns.escHtml(String(owner.id));
    const ownerTypeEsc = ns.escHtml(String(owner?.type || '').trim().toLowerCase());
    return `<button class="cs-owner-check-btn" type="button" data-owner-id="${ownerId}" data-owner-type="${ownerTypeEsc}">Verify</button>`;
  };

  ns.getOwnerCheckPanelHtml = function getOwnerCheckPanelHtml(owner) {
    if (!owner?.id) return '';
    const ownerId = ns.escHtml(String(owner.id));
    return `<div class="cs-check-panel" id="cs-check-${ownerId}" hidden></div>`;
  };

  function renderComparison(comparisonRows, dbCallCount, pageCallCount) {
    const summary = `<div class="cs-check-summary">${pageCallCount} call${pageCallCount !== 1 ? 's' : ''} found on page · ${dbCallCount} in database</div>`;

    if (!comparisonRows.length) {
      return summary + '<div class="cs-check-ok">No data to compare.</div>';
    }

    const mismatched = comparisonRows.filter(r => r.matchStatus === 'mismatched');
    const unconfirmed = comparisonRows.filter(r => r.matchStatus === 'unconfirmed');
    const matched = comparisonRows.filter(r => r.matchStatus === 'matched');
    // Mismatched rows first, then unconfirmed, matched rows below
    const ordered = [...mismatched, ...unconfirmed, ...matched];

    const rows = ordered.map(r => {
      const status = r.matchStatus;
      const badge = { matched: '✓', unconfirmed: '?', mismatched: '✗' }[status];
      const evidence = r.pageEvidence ? `<div class="cs-check-evidence">“${ns.escHtml(r.pageEvidence)}”</div>` : '';
      // Notes get a second full-width row only when present
      const notesRow = r.notes || evidence
        ? `<tr class="cs-check-tr-notes cs-check-tr-notes--${status}">
             <td colspan="4" class="cs-check-td-notes">${ns.escHtml(r.notes)}${evidence}</td>
           </tr>`
        : '';
      return `
        <tr class="cs-check-tr cs-check-tr--${status}">
          <td class="cs-check-td-cat">${ns.escHtml(r.category)}</td>
          <td class="cs-check-td-badge cs-check-td-badge--${status}">${badge}</td>
          <td class="cs-check-td-detail">${ns.escHtml(r.websiteDetails)}</td>
          <td class="cs-check-td-detail">${ns.escHtml(r.databaseDetails)}</td>
        </tr>${notesRow}`;
    }).join('');

    const table = `
      <table class="cs-check-table">
        <thead>
          <tr>
            <th class="cs-check-th">Category</th>
            <th class="cs-check-th"></th>
            <th class="cs-check-th">Page</th>
            <th class="cs-check-th">Database</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>`;

    return summary + table;
  }

  document.body.addEventListener('click', async (e) => {
    const btn = e.target.closest('.cs-owner-check-btn');
    if (!btn) return;

    const ownerId = btn.dataset.ownerId;
    const ownerType = btn.dataset.ownerType;
    if (!ownerId || !ownerType) return;

    const panel = document.getElementById(`cs-check-${ownerId}`);
    if (!panel) return;

    // Toggle closed
    if (!panel.hidden) {
      panel.hidden = true;
      btn.classList.remove('cs-owner-check-btn--open');
      return;
    }

    btn.disabled = true;
    btn.textContent = 'Checking…';

    try {
      // TODO: could fall back to owner's stored guidelinesLink/website as the source
      // URL when the current page is not the owner's submission listing page

      // Strip extension-injected elements (#cs-panel, #cs-existing-drawer, etc.)
      // before extracting text so the AI reads the actual page content, not our own UI.
      const bodyClone = document.body.cloneNode(true);
      bodyClone.querySelectorAll('[id^="cs-"]').forEach(el => el.remove());
      const pageText = (bodyClone.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 80000);

      const res = await fetch(`${ns.API_BASE}/extension/check-calls`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerId, ownerType, pageText, pageUrl: window.location.href }),
      });
      const data = await res.json();

      if (!res.ok) {
        panel.innerHTML = `<div class="cs-check-error">${ns.escHtml(data.error || 'Check failed.')}</div>`;
      } else {
        panel.innerHTML = renderComparison(data.comparisonRows || [], data.dbCallCount ?? 0, data.pageCallCount ?? 0);
      }
    } catch (err) {
      panel.innerHTML = `<div class="cs-check-error">Error: ${ns.escHtml(err?.message || String(err))}</div>`;
    } finally {
      btn.disabled = false;
      btn.textContent = 'Verify';
      panel.hidden = false;
      btn.classList.add('cs-owner-check-btn--open');
    }
  });
})();
