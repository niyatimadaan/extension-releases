(() => {
  const ns = window.ChillSubsExt;

  function normalizeUrl(rawUrl) {
    try {
      const parsed = new URL(rawUrl, window.location.href);
      return parsed.toString();
    } catch {
      return "";
    }
  }

  function getLinkText(node) {
    return String(node?.innerText || node?.textContent || "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function getDocumentFallbackTitle() {
    return String(document.title || "")
      .replace(/\|\s*Duosuma by Duotrope\s*$/i, "")
      .trim() || "Duosuma Call";
  }

  function findNearestCallTitle(linkEl) {
    const container = linkEl.closest(".card, .row, .col, article, section, li, .list-group-item") || linkEl.parentElement;
    const titleNode = container?.querySelector("h1, h2, h3, h4, .card-title, .header-3, strong");
    let titleText = titleNode?.textContent || "";
    if (titleNode?.querySelector("small")) {
      const clone = titleNode.cloneNode(true);
      clone.querySelectorAll("small").forEach((el) => el.remove());
      titleText = clone.textContent || "";
    }
    const title = String(titleText).replace(/\s+/g, " ").trim();
    return title || getDocumentFallbackTitle();
  }

  // Duosuma submit links carry `?id=<baseId>-<sessionToken>`; the session
  // token rotates per visit but baseId is stable per call/category. This is
  // the same rule backend/calls/routes/duosuma.js's selectTargetPage() uses
  // to find the right call inside a freshly-scraped manifest — ported here
  // since the content script can't import that Node module.
  function extractDuosumaBaseId(url) {
    try {
      const id = new URL(url).searchParams.get("id");
      if (!id) return null;
      const lastDash = id.lastIndexOf("-");
      return lastDash > 0 ? id.substring(0, lastDash) : id;
    } catch {
      return null;
    }
  }

  ns.autoMatchDuosumaIds = function autoMatchDuosumaIds(sourcePayload, calls) {
    const matched = new Set();
    const requestedBaseId = extractDuosumaBaseId(sourcePayload.callUrl);
    const incomingTitle = ns.normalizeMatchTitle(sourcePayload.title);
    for (const c of calls) {
      const callBaseId = extractDuosumaBaseId(c.link);
      if (requestedBaseId && callBaseId && callBaseId === requestedBaseId) { matched.add(c.id); continue; }
      if (incomingTitle && ns.normalizeMatchTitle(c.title) === incomingTitle) matched.add(c.id);
    }
    return matched;
  };

  ns.duosumaMatchReason = function duosumaMatchReason(sourcePayload, call) {
    const requestedBaseId = extractDuosumaBaseId(sourcePayload.callUrl);
    const callBaseId = extractDuosumaBaseId(call.link);
    return requestedBaseId && callBaseId && callBaseId === requestedBaseId ? "link" : "title";
  };

  // Separate from content.match.js's ensureCallsLoaded: Duosuma pages all
  // share the duotrope.com host, so owner resolution needs the full page URL
  // (path included) to disambiguate, not just the origin.
  let duosumaCallsCache = null;
  let duosumaCallsCacheLoading = false;
  let duosumaCallsCacheCallbacks = [];

  async function ensureDuosumaCallsLoaded() {
    if (duosumaCallsCache !== null) return duosumaCallsCache;
    if (duosumaCallsCacheLoading) {
      return new Promise((resolve) => duosumaCallsCacheCallbacks.push(resolve));
    }
    duosumaCallsCacheLoading = true;
    try {
      const res = await fetch(
        `${ns.API_BASE}/extension/calls-for-match?mainUrl=${encodeURIComponent(location.href)}`,
      );
      const data = await res.json();
      duosumaCallsCache = Array.isArray(data.calls) ? data.calls : [];
    } catch {
      duosumaCallsCache = [];
    }
    duosumaCallsCacheLoading = false;
    duosumaCallsCacheCallbacks.forEach((cb) => cb(duosumaCallsCache));
    duosumaCallsCacheCallbacks = [];
    return duosumaCallsCache;
  }

  ns.clearDuosumaCallsCache = function clearDuosumaCallsCache() {
    duosumaCallsCache = null;
  };

  function findDuosumaSubmitLinks() {
    const currentUrl = normalizeUrl(window.location.href);
    return Array.from(document.querySelectorAll('a[href]')).filter((link) => {
      if (link.closest("#cs-existing-drawer, #cs-panel, .cs-panel")) return false;
      const text = getLinkText(link);
      const href = normalizeUrl(link.getAttribute("href"));
      if (!href || href === currentUrl) return false;
      if (!/\/duosuma\/submit\//i.test(href)) return false;
      return /^submit$/i.test(text) || /\/duosuma\/submit\/form\.aspx/i.test(href);
    });
  }

  ns.buildDuosumaSourcePayloadFromLink = function buildDuosumaSourcePayloadFromLink(linkEl) {
    const callUrl = normalizeUrl(linkEl?.getAttribute("href"));
    return {
      provider: "duosuma",
      callUrl,
      mainUrl: window.location.href,
      title: findNearestCallTitle(linkEl),
    };
  };

  ns.injectDuosumaAddButtons = function injectDuosumaAddButtons() {
    const submitLinks = findDuosumaSubmitLinks();
    const currentSourceKeys = new Set();

    submitLinks.forEach((link) => {
      const sourcePayload = ns.buildDuosumaSourcePayloadFromLink(link);
      
      if (!sourcePayload.callUrl) return;

      const sourceKey = ns.getCallDraftKey(sourcePayload.callUrl);
      if (!sourceKey) return;

      currentSourceKeys.add(sourceKey);
      ns.state.availableCallSources.set(sourceKey, sourcePayload);

      let wrap = link.parentElement?.querySelector(`.cs-duosuma-add-wrap[data-cs-call-key="${sourceKey}"]`);
      if (!wrap) {
        wrap = document.createElement("span");
        wrap.className = "cs-duosuma-add-wrap";
        wrap.dataset.csCallKey = sourceKey;
        wrap.style.display = "inline-flex";
        wrap.style.marginLeft = "8px";
        wrap.style.gap = "6px";
        wrap.style.verticalAlign = "middle";
        link.insertAdjacentElement("afterend", wrap);
      }

      let btn = wrap.querySelector(".cs-add-btn");
      if (!btn) {
        btn = ns.el("button", "cs-add-btn");
        btn.type = "button";
        btn.title = "Add to ChillSubs";
        btn.textContent = "Add";
        wrap.appendChild(btn);
      }

      btn.onclick = async (event) => {
        event.preventDefault();
        event.stopPropagation();
        await ns.openSourcePayload(sourcePayload, "Parsing Duosuma call...");
      };

      ns.attachMatchButton(wrap, wrap, sourceKey, sourcePayload, ensureDuosumaCallsLoaded);
    });

    Array.from(ns.state.availableCallSources.keys()).forEach((sourceKey) => {
      const payload = ns.state.availableCallSources.get(sourceKey);
      if (payload?.provider === "duosuma" && !currentSourceKeys.has(sourceKey)) {
        ns.state.availableCallSources.delete(sourceKey);
      }
    });
  };

  ns.observeDuosuma = function observeDuosuma() {
    if (!ns.isDuosumaPage()) return;

    let observer = null;
    let injectionTimeout = null;

    const injectWithDebounce = () => {
      if (injectionTimeout) clearTimeout(injectionTimeout);

      injectionTimeout = window.setTimeout(() => {
        if (observer) observer.disconnect();
        ns.injectDuosumaAddButtons();
        if (observer) observer.observe(document.body, { childList: true, subtree: true });
      }, 300);
    };

    ns.injectDuosumaAddButtons();
    observer = new MutationObserver(injectWithDebounce);
    observer.observe(document.body, { childList: true, subtree: true });
  };

  const previousObserve = ns.observe;
  ns.observe = function observeWithDuosuma() {
    if (typeof previousObserve === "function") {
      previousObserve();
    }
    ns.observeDuosuma();

    // On pages that are neither Submittable nor Duosuma, add the generic AI parse button.
    if (!ns.isSubmittableHost() && !ns.isDuosumaPage()) {
      ns.initGenericPage();
    }
  };
})();
