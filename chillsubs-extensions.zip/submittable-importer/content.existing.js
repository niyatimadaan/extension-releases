(() => {
  const ns = window.ChillSubsExt;
  const FAB_POS_KEY = "cs-existing-fab-pos";
  const DRAWER_SIZE_KEY = "cs-existing-drawer-size";
  let callsById = new Map(); // callId -> full call object, refreshed on each drawer render

  function formatDateLabel(value) {
    if (!value) return "";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    const day = String(d.getUTCDate()).padStart(2, "0");
    const month = String(d.getUTCMonth() + 1).padStart(2, "0");
    return `${day}/${month}/${d.getUTCFullYear()}`;
  }

  function formatShortDate(value) {
    if (!value) return "";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    return `${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
  }

  function getRecurringType(call) {
    if (!call?.readingPeriod?.callPeriod?.recurring) return null;
    const interval = call?.readingPeriod?.interval || {};
    if (interval.monthly) return "monthly";
    if (interval.yearly) return "yearly";
    return null;
  }

  function formatMoney(amount, currency) {
    if (amount == null || Number.isNaN(Number(amount))) return "";
    const parsed = Number(amount);
    const amountText = Number.isInteger(parsed) ? String(parsed) : parsed.toFixed(2);
    return currency ? `${amountText} ${currency}` : amountText;
  }

  function formatRange(lower, upper, unit) {
    const hasLower = lower != null && !Number.isNaN(Number(lower));
    const hasUpper = upper != null && !Number.isNaN(Number(upper));
    if (!hasLower && !hasUpper) return "";
    if (hasLower && hasUpper) return `${lower}-${upper} ${unit}`;
    if (hasLower) return `min ${lower} ${unit}`;
    return `max ${upper} ${unit}`;
  }

  function getPrimaryGenreLabel(call) {
    const genre = call?.genre || {};
    if (genre.fiction) return "fiction";
    if (genre.nonfiction) return "nonfiction";
    if (genre.poetry) return "poetry";
    if (genre.hybrid) return "hybrid";
    if (genre.multimedia) return "multimedia";
    return "general";
  }

  function hasPositiveAmount(value) {
    return value != null && !Number.isNaN(Number(value)) && Number(value) > 0;
  }

  function isContestCall(call) {
    if (call?.callTypes?.contest != null) return Boolean(call.callTypes.contest);
    return /contest/i.test(String(call?.type || ""));
  }

  function buildHeadLine(call) {
    const temporalState = call?.temporalState?.state || "unknown";
    const genre = call?.callMetadata?.variant ? call?.callMetadata?.variant.toLowerCase().replace(/_/g, " ")
     : getPrimaryGenreLabel(call);
    const type = call?.type || "general";
    const style = call?.genreStyle ? ` / ${call.genreStyle}` : "";
    const closeDate = call?.temporalState?.closeDate ? ` | closes ${formatDateLabel(call.temporalState.closeDate)}` : "";
    const recurringType = getRecurringType(call);
    const recurringLabel = recurringType ? ` (${recurringType})` : "";
    return `${genre} / ${type}${style}${closeDate} | ${temporalState}${recurringLabel}`;
  }

  function buildFeePaymentLine(call) {
    const fee = call?.fee || {};
    const payment = call?.payment || {};

    let feeText = "Fee: free";
    if (fee?.charges) {
      const feeAmount = formatMoney(fee?.amount, fee?.currency || "USD");
      feeText = feeAmount ? `Fee: ${feeAmount}` : "Fee: charged";

      const cats = fee?.feeFreeCategories?.categories || {};
      const feeFreeParts = [
        cats.bipoc && "BIPOC",
        cats.accessbility && "accessibility",
        cats.lowIncome && "low-income",
        cats.firstComeFirstServe && "FCFS",
        cats.other && "other",
      ].filter(Boolean);
      if (feeFreeParts.length) feeText += ` (free: ${feeFreeParts.join(", ")})`;

      const extras = [
        fee?.paidFastResponses?.hasThis && `fast-response${fee.paidFastResponses?.price?.amount ? ` ${formatMoney(fee.paidFastResponses.price.amount, fee.paidFastResponses.price.currency || "USD")}` : ""}`,
        // fee?.tipJarOption?.hasThis && `tip-jar${...}`,  // tip jar commented out
        fee?.feedbackOption?.hasThis && `feedback${fee.feedbackOption?.price?.amount ? ` ${formatMoney(fee.feedbackOption.price.amount, fee.feedbackOption.price.currency || "USD")}` : ""}`,
      ].filter(Boolean);
      if (extras.length) feeText += ` +${extras.join(" +")}`;
    }

    let paymentText = "Payment: unpaid";
    if (payment?.pays) {
      const lower = payment?.amount?.lower;
      const upper = payment?.amount?.upper;
      const currency = payment?.currency || "USD";
      const exact = payment?.amount?.exact !== false;
      const hasLower = lower != null && !Number.isNaN(Number(lower));
      const hasUpper = upper != null && !Number.isNaN(Number(upper));
      const contest = isContestCall(call);

      if (contest) {
        const totalAwarded = call?.payment?.prize?.totalCashPrize;
        const topPrize = payment?.additional?.topPrize;

        if (hasPositiveAmount(totalAwarded) && hasPositiveAmount(topPrize)) {
          paymentText = `Payment: total awarded ${formatMoney(totalAwarded, currency)} | top prize ${formatMoney(topPrize, currency)}`;
        } else if (hasPositiveAmount(totalAwarded)) {
          paymentText = `Payment: total awarded ${formatMoney(totalAwarded, currency)}`;
        } else if (hasPositiveAmount(topPrize)) {
          paymentText = `Payment: top prize ${formatMoney(topPrize, currency)}`;
        } else if (hasLower || hasUpper) {
          if (!exact && hasLower && hasUpper && Number(lower) !== Number(upper)) {
            paymentText = `Payment: range ${formatMoney(lower, currency)} - ${formatMoney(upper, currency)}`;
          } else {
            paymentText = `Payment: exact ${formatMoney(hasLower ? lower : upper, currency)}`;
          }
        } else {
          paymentText = "Payment: pays";
        }
      } else if (hasLower || hasUpper) {
        if (!exact && hasLower && hasUpper && Number(lower) !== Number(upper)) {
          paymentText = `Payment: range ${formatMoney(lower, currency)} - ${formatMoney(upper, currency)}`;
        } else {
          paymentText = `Payment: exact ${formatMoney(hasLower ? lower : upper, currency)}`;
        }
      } else {
        paymentText = "Payment: pays";
      }
    }

    return `${feeText} | ${paymentText}`;
  }

  function buildLengthPiecesLine(call) {
    const length = call?.length || {};
    const lengthRangeLabel = (min, max, unit) => {
      if (Number(min) === 0 && Number(max) === 0) return "";
      return formatRange(min, max, unit);
    };
    const lengthParts = [
      lengthRangeLabel(length.minimumWordCount, length.maximumWordCount, "words"),
      lengthRangeLabel(length.minimumPageCount, length.maximumPageCount, "pages"),
      lengthRangeLabel(length.minimumLineCount, length.maximumLineCount, "lines"),
      lengthRangeLabel(length.minimumPitchCount, length.maximumPitchCount, "pitches"),
    ].filter(Boolean);

    const minPieces = call?.minPiecesPerSub;
    const maxPieces = call?.maxPiecesPerSub;
    let piecePart = "";
    if (Number(minPieces) === 0 && Number(maxPieces) === 0) {
      // skip
    } else if (minPieces != null && maxPieces != null) {
      piecePart = `pieces ${minPieces}-${maxPieces}`;
    } else if (minPieces != null) {
      piecePart = `pieces min ${minPieces}`;
    } else if (maxPieces != null) {
      piecePart = `pieces max ${maxPieces}`;
    }

    const parts = [];
    if (lengthParts.length) parts.push(`length ${lengthParts.join(" | ")}`);
    if (piecePart) parts.push(piecePart);

    return parts.length ? parts.join(" | ") : "";
  }

  function buildOwnerAdminCallsUrl(owner) {
    const ownerId = String(owner?.id || "").trim();
    if (!ownerId) return "";

    const ownerType = String(owner?.type || "magazine").trim().toLowerCase();
    const ownerPath = ownerType === "publisher"
      ? "presses"
      : ownerType === "organisation"
        ? "organisations"
        : "magazines";

    return `https://admin.chillsubs.com/${ownerPath}/${ownerId}/calls`;
  }

  function getLastWindow(call) {
    return call.lastWindow || null; // { openDate: "YYYY-MM-DD"|null, closeDate: "YYYY-MM-DD"|null } — offset-corrected by server
  }

  function buildRecurringGroupLabel(groupCalls) {
    for (const call of groupCalls) {
      if (call?.readingPeriod?.callPeriod?.recurring && call?.temporalState?.state === "open") {
        const type = getRecurringType(call);
        if (!type) continue;
        const closePart = call.temporalState.closeDate
          ? ` — open until ${formatShortDate(call.temporalState.closeDate)}`
          : "";
        return `Recurring ${type.charAt(0).toUpperCase() + type.slice(1)}${closePart}`;
      }
    }
    return null;
  }

  function formatWindowGroupLabel(openDate, closeDate) {
    if (!openDate && !closeDate) return "No window";
    const open = openDate ? formatDateLabel(openDate) : "—";
    const close = closeDate ? formatDateLabel(closeDate) : "—";
    if (!openDate) return `→ ${close}`;
    if (!closeDate) return `${open} → —`;
    return `${open} → ${close}`;
  }

  function groupAndSortCallsByLastWindow(calls) {
    const groupMap = new Map();
    for (const call of calls) {
      const last = getLastWindow(call);
      const key = last ? `${last.openDate || ""}|${last.closeDate || ""}` : null;
      if (!groupMap.has(key)) {
        groupMap.set(key, { openDate: last?.openDate || null, closeDate: last?.closeDate || null, calls: [] });
      }
      groupMap.get(key).calls.push(call);
    }

    function getGroupCategory(group, key) {
      const hasOpen = group.calls.some((c) => c?.temporalState?.state === "open");
      const hasUpcoming = group.calls.some((c) => c?.temporalState?.state === "upcoming");
      if (hasOpen && group.closeDate) return 0; // open with close date
      if (hasOpen) return 1; // always open (no close date)
      if (hasUpcoming) return 2; // upcoming
      if (key !== null) return 3; // closed with window
      return 4; // no window, not open/upcoming
    }

    return [...groupMap.entries()].sort(([keyA, gA], [keyB, gB]) => {
      const catA = getGroupCategory(gA, keyA);
      const catB = getGroupCategory(gB, keyB);
      if (catA !== catB) return catA - catB;
      if (catA === 0) {
        return new Date(gA.closeDate).getTime() - new Date(gB.closeDate).getTime();
      }
      if (catA === 2) {
        const tA = gA.openDate ? new Date(gA.openDate).getTime() : Infinity;
        const tB = gB.openDate ? new Date(gB.openDate).getTime() : Infinity;
        return tA - tB;
      }
      if (catA === 3) {
        const tA = gA.closeDate ? new Date(gA.closeDate).getTime() : -Infinity;
        const tB = gB.closeDate ? new Date(gB.closeDate).getTime() : -Infinity;
        return tB - tA;
      }
      return 0;
    });
  }

  function renderCallCard(call) {
    const lengthPieces = buildLengthPiecesLine(call);
    return `
      <div class="cs-existing-call"
        data-call-id="${ns.escHtml(call.id || "")}"
        data-last-open="${ns.escHtml(call.lastWindow?.openDate || "")}"
        data-last-close="${ns.escHtml(call.lastWindow?.closeDate || "")}">
        <input type="checkbox" class="cs-call-checkbox" value="${ns.escHtml(call.id || "")}">
        <div class="cs-call-content">
          <a class="cs-existing-call-title" href="${ns.escHtml(call.link || "#")}" target="_blank" rel="noopener noreferrer">${ns.escHtml(call.title || "Untitled")}</a>
          <div class="cs-existing-call-meta">${ns.escHtml(buildHeadLine(call))}</div>
          <div class="cs-existing-call-meta">${ns.escHtml(buildFeePaymentLine(call))}</div>
          ${lengthPieces ? `<div class="cs-existing-call-meta">${ns.escHtml(lengthPieces)}</div>` : ""}
        </div>
      </div>`;
  }

  function renderExistingCallsDrawer(callsByOwner) {
    const body = ns.qs("#cs-existing-body");
    if (!body) return;

    callsById = new Map();
    for (const group of Array.isArray(callsByOwner) ? callsByOwner : []) {
      for (const call of Array.isArray(group.calls) ? group.calls : []) {
        if (call?.id) callsById.set(call.id, call);
      }
    }

    if (!Array.isArray(callsByOwner) || callsByOwner.length === 0) {
      body.innerHTML = '<div class="cs-existing-empty">No mapped owners found for this page.</div>';
      return;
    }

    body.innerHTML = callsByOwner
      .map((group) => {
        const owner = group.owner || {};
        const adminCallsUrl = buildOwnerAdminCallsUrl(owner);
        const calls = Array.isArray(group.calls) ? group.calls : [];
        let callsHtml;
        if (!calls.length) {
          callsHtml = '<div class="cs-existing-empty">No active calls for this mapping.</div>';
        } else {
          const sortedGroups = groupAndSortCallsByLastWindow(calls);
          const renderGroup = ([, group]) => {
            const isAlwaysOpen = group.calls.some((c) => c?.temporalState?.state === "open") && !group.closeDate;
            const label = buildRecurringGroupLabel(group.calls) || (isAlwaysOpen ? "Always Open" : formatWindowGroupLabel(group.openDate, group.closeDate));
            return `
              <div class="cs-window-group">
                <div class="cs-window-group-header">
                  <input type="checkbox" class="cs-group-select-all">
                  <span class="cs-window-group-label">${ns.escHtml(label)}</span>
                </div>
                ${group.calls.map(renderCallCard).join("")}
              </div>`;
          };
          const openGroups = sortedGroups.filter(([, g]) => g.calls.some((c) => c?.temporalState?.state === "open" || c?.temporalState?.state === "upcoming"));
          const closedGroups = sortedGroups.filter(([, g]) => !g.calls.some((c) => c?.temporalState?.state === "open" || c?.temporalState?.state === "upcoming"));
          callsHtml = [
            openGroups.length ? `<div class="cs-calls-section-heading cs-calls-section-open">Open</div>${openGroups.map(renderGroup).join("")}` : "",
            closedGroups.length ? `<div class="cs-calls-section-heading cs-calls-section-closed">Closed</div>${closedGroups.map(renderGroup).join("")}` : "",
          ].join("");
        }

        return `
          <div class="cs-existing-owner-group">
            <div class="cs-existing-owner-title-row">
              <div class="cs-existing-owner-title">${ns.escHtml(owner.label || owner.name || "Owner")}</div>
              ${ns.getOwnerAuditHtml ? ns.getOwnerAuditHtml(owner) : ""}
              ${ns.getOwnerCheckHtml ? ns.getOwnerCheckHtml(owner) : ""}
              <button class="cs-owner-toggle" type="button" aria-expanded="true" aria-label="Collapse calls">▾</button>
            </div>
            ${ns.getOwnerAuditPanelHtml ? ns.getOwnerAuditPanelHtml(owner) : ""}
            ${ns.getOwnerCheckPanelHtml ? ns.getOwnerCheckPanelHtml(owner) : ""}
            ${adminCallsUrl ? `<a class="cs-existing-owner-link" href="${ns.escHtml(adminCallsUrl)}" target="_blank" rel="noopener noreferrer">${ns.escHtml(adminCallsUrl)}</a>` : ""}
            <div class="cs-existing-owner-id">${ns.escHtml(owner.id || "")}</div>
            ${owner.pageCrawlSlug ? `<div class="cs-existing-owner-link">PageCrawl: <a href="https://pagecrawl.io/app/pages/${ns.escHtml(owner.pageCrawlSlug)}" target="_blank" rel="noopener noreferrer">${ns.escHtml(owner.pageCrawlSlug)}</a></div>` : ""}
            <div class="cs-owner-calls">${callsHtml}</div>
          </div>
        `;
      })
      .join("");
  }

  async function loadExistingCalls() {
    const body = ns.qs("#cs-existing-body");
    if (!body) return;
    body.innerHTML = '<div class="cs-existing-loading">Loading existing calls...</div>';

    try {
      const host = window.location.host || "";
      const url = ns.isSubmittableHost(host)
        ? `${ns.API_BASE}/extension/existing?mainUrl=${encodeURIComponent(ns.getMainUrl())}`
        : `${ns.API_BASE}/extension/fetch-existing?pageUrl=${encodeURIComponent(window.location.href)}`;
      const res = await fetch(url);
      const data = await res.json();
      if (!res.ok) {
        body.innerHTML = `<div class="cs-existing-empty">${ns.escHtml(data.error || "Failed to load existing calls.")}</div>`;
        return;
      }
      renderExistingCallsDrawer(data.callsByOwner || []);
    } catch (error) {
      console.error("Error loading existing calls:", error);
      const errorMsg = error?.message || String(error) || "Unknown error occurred";
      body.innerHTML = `<div class="cs-existing-empty">Error loading existing calls:<br><small>${ns.escHtml(errorMsg)}</small><br><small style="opacity: 0.7;">Check browser console for full error.</small></div>`;
    }
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(value, max));
  }

  function getDrawerSize(drawer) {
    const computed = window.getComputedStyle(drawer);
    const width = drawer.offsetWidth || Number.parseFloat(computed.width) || 460;
    const height = drawer.offsetHeight || Number.parseFloat(computed.height) || 520;
    return { width, height };
  }

  function positionDrawerRelativeToFab(fab, drawer) {
    if (!fab || !drawer) return;

    const gap = 10;
    const viewportPadding = 8;
    const fabRect = fab.getBoundingClientRect();
    const { width, height } = getDrawerSize(drawer);
    const maxLeft = Math.max(viewportPadding, window.innerWidth - width - viewportPadding);
    const maxTop = Math.max(viewportPadding, window.innerHeight - height - viewportPadding);

    let left = fabRect.right - width;
    left = clamp(left, viewportPadding, maxLeft);

    let top = fabRect.top - height - gap;
    if (top < viewportPadding) {
      top = fabRect.bottom + gap;
    }
    top = clamp(top, viewportPadding, maxTop);

    drawer.style.left = `${left}px`;
    drawer.style.top = `${top}px`;
    drawer.style.right = "auto";
    drawer.style.bottom = "auto";
  }

  ns.ensureExistingCallsDrawer = function ensureExistingCallsDrawer() {
    if (ns.qs("#cs-existing-fab") && ns.qs("#cs-existing-drawer")) return;

    const fab = ns.el("button", "cs-existing-fab");
    fab.id = "cs-existing-fab";
    fab.type = "button";
    fab.textContent = "Existing Calls";

    const drawer = ns.el("div", "cs-existing-drawer");
    drawer.id = "cs-existing-drawer";
    drawer.innerHTML = `
      <div class="cs-existing-header">
        <div class="cs-existing-title">Existing Calls</div>
        <div class="cs-header-default-btns">
          <button class="cs-existing-close" id="cs-select-btn" type="button">Select</button>
          <button class="cs-existing-close" id="cs-existing-close" type="button">Close</button>
        </div>
        <div class="cs-header-select-btns" id="cs-header-select-btns">
          <button class="cs-existing-close cs-btn-primary" id="cs-edit-calls-bulk" type="button" disabled>Edit Calls (0)</button>
          <button class="cs-existing-close" id="cs-select-done" type="button">Done</button>
        </div>
      </div>
      <div class="cs-existing-body" id="cs-existing-body"></div>
    `;

    const savedPosRaw = window.localStorage.getItem(FAB_POS_KEY);
    if (savedPosRaw) {
      try {
        const savedPos = JSON.parse(savedPosRaw);
        if (Number.isFinite(savedPos?.right) && Number.isFinite(savedPos?.bottom)) {
          fab.style.right = `${savedPos.right}px`;
          fab.style.bottom = `${savedPos.bottom}px`;
          fab.style.left = "auto";
          fab.style.top = "auto";
        }
      } catch {
        // Ignore invalid saved state.
      }
    }

    const savedDrawerSizeRaw = window.localStorage.getItem(DRAWER_SIZE_KEY);
    if (savedDrawerSizeRaw) {
      try {
        const savedSize = JSON.parse(savedDrawerSizeRaw);
        if (Number.isFinite(savedSize?.width)) {
          drawer.style.width = `${savedSize.width}px`;
        }
        if (Number.isFinite(savedSize?.height)) {
          drawer.style.height = `${savedSize.height}px`;
        }
      } catch {
        // Ignore invalid saved state.
      }
    }

    let dragging = false;
    let moved = false;
    let ignoreNextClick = false;
    let dragOffsetX = 0;
    let dragOffsetY = 0;

    fab.addEventListener("pointerdown", (event) => {
      dragging = true;
      moved = false;
      const rect = fab.getBoundingClientRect();
      dragOffsetX = event.clientX - rect.left;
      dragOffsetY = event.clientY - rect.top;
      fab.classList.add("cs-dragging");
      fab.setPointerCapture(event.pointerId);
    });

    fab.addEventListener("pointermove", (event) => {
      if (!dragging) return;

      const nextLeft = Math.max(8, Math.min(event.clientX - dragOffsetX, window.innerWidth - fab.offsetWidth - 8));
      const nextTop = Math.max(8, Math.min(event.clientY - dragOffsetY, window.innerHeight - fab.offsetHeight - 8));
      fab.style.left = `${nextLeft}px`;
      fab.style.top = `${nextTop}px`;
      fab.style.right = "auto";
      fab.style.bottom = "auto";
      moved = true;
      positionDrawerRelativeToFab(fab, drawer);
    });

    fab.addEventListener("pointerup", (event) => {
      if (!dragging) return;
      dragging = false;
      fab.classList.remove("cs-dragging");
      fab.releasePointerCapture(event.pointerId);

      if (moved) {
        ignoreNextClick = true;
        const rect = fab.getBoundingClientRect();
        const right = window.innerWidth - rect.right;
        const bottom = window.innerHeight - rect.bottom;
        fab.style.right = `${right}px`;
        fab.style.bottom = `${bottom}px`;
        fab.style.left = "auto";
        fab.style.top = "auto";
        window.localStorage.setItem(FAB_POS_KEY, JSON.stringify({ right, bottom }));
      }
    });

    fab.addEventListener("click", async () => {
      if (ignoreNextClick) {
        ignoreNextClick = false;
        return;
      }
      const open = drawer.classList.toggle("cs-open");
      if (open) {
        positionDrawerRelativeToFab(fab, drawer);
        await loadExistingCalls();
      }
    });

    ns.qs("#cs-existing-close", drawer).addEventListener("click", () => {
      drawer.classList.remove("cs-open");
    });

    function updateBulkButton(count) {
      const btn = ns.qs("#cs-edit-calls-bulk", drawer);
      if (btn) {
        btn.textContent = `Edit Calls (${count})`;
        btn.disabled = count === 0;
      }
    }

    function exitSelectMode() {
      drawer.classList.remove("cs-select-mode");
      drawer.querySelectorAll(".cs-call-checkbox, .cs-group-select-all").forEach((cb) => {
        cb.checked = false;
        cb.indeterminate = false;
      });
      updateBulkButton(0);
    }

    ns.exitExistingSelectMode = exitSelectMode;

    ns.qs("#cs-select-btn", drawer).addEventListener("click", () => {
      drawer.classList.add("cs-select-mode");
    });

    ns.qs("#cs-select-done", drawer).addEventListener("click", exitSelectMode);

    drawer.addEventListener("click", (e) => {
      const toggle = e.target.closest(".cs-owner-toggle");
      if (!toggle) return;
      const ownerGroup = toggle.closest(".cs-existing-owner-group");
      if (!ownerGroup) return;
      const callsContainer = ownerGroup.querySelector(".cs-owner-calls");
      if (!callsContainer) return;
      const expanded = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!expanded));
      toggle.textContent = expanded ? "▸" : "▾";
      callsContainer.classList.toggle("cs-owner-calls--collapsed", expanded);
    });

    drawer.addEventListener("change", (e) => {
      if (e.target.classList.contains("cs-group-select-all")) {
        const group = e.target.closest(".cs-window-group");
        if (group) {
          group.querySelectorAll(".cs-call-checkbox").forEach((cb) => { cb.checked = e.target.checked; });
        }
      } else if (e.target.classList.contains("cs-call-checkbox")) {
        const group = e.target.closest(".cs-window-group");
        if (group) {
          const groupCb = group.querySelector(".cs-group-select-all");
          const callCbs = [...group.querySelectorAll(".cs-call-checkbox")];
          const checkedCount = callCbs.filter((cb) => cb.checked).length;
          if (groupCb) {
            groupCb.checked = checkedCount === callCbs.length;
            groupCb.indeterminate = checkedCount > 0 && checkedCount < callCbs.length;
          }
        }
      } else {
        return;
      }
      const count = drawer.querySelectorAll(".cs-call-checkbox:checked").length;
      updateBulkButton(count);
    });

    ns.qs("#cs-edit-calls-bulk", drawer).addEventListener("click", () => {
      const checked = [...drawer.querySelectorAll(".cs-call-checkbox:checked")];
      if (!checked.length) return;
      const callIds = checked.map((cb) => cb.value);
      const cards = checked.map((cb) => cb.closest(".cs-existing-call"));

      const openDates = new Set(cards.map((c) => c?.dataset.lastOpen || ""));
      const closeDates = new Set(cards.map((c) => c?.dataset.lastClose || ""));
      const lastWindow = openDates.size === 1 && closeDates.size === 1
        ? { openDate: [...openDates][0] || null, closeDate: [...closeDates][0] || null }
        : null;

      const selectedCalls = callIds.map((id) => callsById.get(id)).filter(Boolean);
      const callFlags = ns.getCallPeriodFlags(selectedCalls);
      const subWindows = ns.getSharedSubWindows(selectedCalls);

      const feeValues = new Set(selectedCalls.map((c) => JSON.stringify(c?.fee || {})));
      const fee = feeValues.size === 1 ? selectedCalls[0]?.fee || null : null;
      const paymentValues = new Set(selectedCalls.map((c) => JSON.stringify(c?.payment || {})));
      const payment = paymentValues.size === 1 ? selectedCalls[0]?.payment || null : null;

      const genreValues = new Set(selectedCalls.map((c) => JSON.stringify(c?.genre || {})));
      const genre = genreValues.size === 1 ? selectedCalls[0]?.genre || null : null;
      const genreStyleValues = new Set(selectedCalls.map((c) => c?.genreStyle || ""));
      const genreStyle = genreStyleValues.size === 1 ? selectedCalls[0]?.genreStyle || null : null;
      const subGenreValues = new Set(selectedCalls.map((c) => JSON.stringify(c?.subGenre || [])));
      const subGenre = subGenreValues.size === 1 ? selectedCalls[0]?.subGenre || null : null;

      // true/false only when every selected call agrees; null means the selection mixes
      // book-length and short-form calls, which the genre editor can't handle in one edit.
      const bookLengthFlags = selectedCalls.map((c) => ns.isBookLengthType(c?.type));
      const isBookLength = new Set(bookLengthFlags).size === 1 ? bookLengthFlags[0] : null;

      // Preselect the Type dropdown from the calls' existing shape (short/flash/book-length,
      // contest or not) — only when every selected call agrees, same as genre/genreStyle above.
      const typeTokenValues = new Set(selectedCalls.map((c) => ns.variantToTypeToken(c?.callMetadata?.variant) || ""));
      const type = typeTokenValues.size === 1 ? (ns.variantToTypeToken(selectedCalls[0]?.callMetadata?.variant) || null) : null;

      ns.openAddWindowModal({ callIds, callCount: callIds.length, lastWindow, callFlags, subWindows, fee, payment, genre, genreStyle, subGenre, isBookLength, type });
    });

    window.addEventListener("resize", () => {
      positionDrawerRelativeToFab(fab, drawer);
    });

    if (typeof window.ResizeObserver === "function") {
      const resizeObserver = new ResizeObserver(() => {
        const { width, height } = getDrawerSize(drawer);
        positionDrawerRelativeToFab(fab, drawer);
        window.localStorage.setItem(DRAWER_SIZE_KEY, JSON.stringify({ width, height }));
      });
      resizeObserver.observe(drawer);
    }

    document.body.appendChild(fab);
    document.body.appendChild(drawer);
    positionDrawerRelativeToFab(fab, drawer);
  };
})();
