(() => {
  const ns = window.ChillSubsExt;

  ns.getMainUrl = function getMainUrl() {
    const u = new URL(location.href);
    return `${u.protocol}//${u.host}`;
  };

  ns.resolveCallUrlFromCategory = function resolveCallUrlFromCategory(cat) {
    const candidates = [
      cat.getAttribute("data-go"),
      cat.querySelector('.submit-column a[href]')?.getAttribute("href"),
      cat.querySelector('.title-column a[href]')?.getAttribute("href"),
      cat.querySelector("a[href]")?.getAttribute("href"),
    ].filter(Boolean);

    for (const candidate of candidates) {
      try {
        const href = new URL(candidate, location.href);
        const returnUrl = href.searchParams.get("returnUrl") || href.searchParams.get("ReturnUrl");
        if (returnUrl) {
          const decoded = decodeURIComponent(returnUrl);
          const id = decoded.match(/\/submit\/(\d+)(?:\/|$)/i)?.[1];
          if (id) return `${ns.getMainUrl()}/submit/${id}`;
        }

        const directId = href.pathname.match(/\/submit\/(\d+)(?:\/|$)/i)?.[1];
        if (directId) return `${ns.getMainUrl()}/submit/${directId}`;
      } catch {
        // Ignore malformed candidate URLs.
      }
    }

    return null;
  };

  function shiftYmd(ymd, days) {
    const dt = new Date(`${ymd}T00:00:00Z`);
    if (Number.isNaN(dt.getTime())) return ymd;
    dt.setUTCDate(dt.getUTCDate() + days);
    return dt.toISOString().slice(0, 10);
  }

  // Extracts a YYYY-MM-DD close date out of a raw data-render-react-date value.
  // Mirrors backend/calls/services/scraper/preview-builder.js's normalizeReadingWindow:
  // a deadline timestamped before 8pm is treated as closing the previous day.
  ns.extractDeadlineDate = function extractDeadlineDate(deadline) {
    if (!deadline) return null;
    const raw = String(deadline).trim();
    const parsedParts = raw.match(
      /(\d{4}-\d{2}-\d{2})(?:[T\s](\d{2}):(\d{2})(?::(\d{2}))?)?(?:Z|[+-]\d{2}:?\d{2})?/,
    );
    const datePart = parsedParts?.[1] ?? null;
    const hourPart = parsedParts?.[2] ?? null;

    let closeDate = datePart;
    if (!closeDate) {
      const parsed = new Date(raw);
      closeDate = Number.isNaN(parsed.getTime()) ? null : parsed.toISOString().slice(0, 10);
    }

    if (closeDate && hourPart != null) {
      const hour = Number(hourPart);
      if (Number.isFinite(hour) && hour < 20) {
        closeDate = shiftYmd(closeDate, -1);
      }
    }

    return closeDate;
  };

  ns.buildSourcePayloadFromCategory = function buildSourcePayloadFromCategory(cat) {
    const header = cat.querySelector(".header-3");
    const title = header?.textContent.trim() || "Untitled Call";
    const feeEl = cat.querySelector(".fee-column");
    const fee = feeEl?.textContent.trim() ?? null;
    const deadEl = cat.querySelector("[data-render-react-date]");
    const deadline = deadEl?.getAttribute("data-render-react-date") ?? null;
    const callUrl = ns.resolveCallUrlFromCategory(cat);
    let hasSubmissionCap = false;
    let submissionCapAmount = null;
    const capSpan = Array.from(cat.querySelectorAll(".date-text, .additional-text span")).find((el) =>
      /close[s]?\s+after/i.test(el.textContent),
    );
    if (capSpan) {
      hasSubmissionCap = true;
      const numEl = capSpan.querySelector("[data-notranslate]");
      // Submittable formats caps with thousands separators ("1,000"); parseInt would stop at the comma.
      const parsed = numEl ? parseInt(numEl.textContent.replace(/[,\s]/g, ""), 10) : NaN;
      submissionCapAmount = Number.isFinite(parsed) && parsed > 0 ? parsed : null;
    }

    return {
      callUrl,
      mainUrl: ns.getMainUrl(),
      title,
      fee,
      deadline,
      hasSubmissionCap,
      submissionCapAmount,
    };
  };

  ns.ensureBatchToolbar = function ensureBatchToolbar() {
    if (ns.state.batchToolbarEl) return ns.state.batchToolbarEl;

    const toolbar = ns.el("div", "cs-batch-toolbar");
    toolbar.innerHTML = `
      <span class="cs-batch-toolbar-count">0 selected</span>
      <button type="button" class="cs-batch-toolbar-btn">Add Selected</button>
    `;

    const actionBtn = toolbar.querySelector(".cs-batch-toolbar-btn");
    actionBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      ns.handleBatchAddSelected();
    });

    document.body.appendChild(toolbar);
    ns.state.batchToolbarEl = toolbar;
    return toolbar;
  };

  ns.updateBatchToolbar = function updateBatchToolbar() {
    const toolbar = ns.ensureBatchToolbar();
    const count = ns.state.selectedCallKeys.size;
    const countLabel = toolbar.querySelector(".cs-batch-toolbar-count");
    const actionBtn = toolbar.querySelector(".cs-batch-toolbar-btn");
    if (countLabel) {
      countLabel.textContent = `${count} call${count === 1 ? "" : "s"} selected`;
    }
    if (actionBtn) {
      actionBtn.disabled = count < 2;
      actionBtn.textContent = count > 1 ? `Add Selected (${count})` : "Add Selected";
    }
    toolbar.classList.toggle("cs-visible", count > 1);
  };

  ns.clearSelectedCalls = function clearSelectedCalls() {
    ns.state.selectedCallKeys.clear();
    document.querySelectorAll(".cs-call-select-input").forEach((input) => {
      input.checked = false;
    });
    document.querySelectorAll(".category.panel-btn.cs-call-selected").forEach((card) => {
      card.classList.remove("cs-call-selected");
    });
    ns.updateBatchToolbar();
  };

  ns.handleBatchAddSelected = async function handleBatchAddSelected() {
    const selectedSources = Array.from(ns.state.selectedCallKeys)
      .map((sourceKey) => ns.state.availableCallSources.get(sourceKey))
      .filter((sourcePayload) => Boolean(sourcePayload?.callUrl));
    if (selectedSources.length < 2) return;

    // Open panel and drawer immediately with loading state
    ns.ensurePanel();
    ns.openPanel();

    // Collect all previews from selected sources
    const allPreviews = [];
    let combinedMagazineId = null;
    let combinedMagazineName = null;
    let combinedOwnerCandidates = [];
    let combinedSelectedOwner = null;
    let combinedParseToken = null;
    const previewTokenMap = new Map(); // Map to store parseToken for each preview

    // Show loading state first
    ns.renderEditor(
      [{ title: "Loading...", description: "", genre: {}, medium: {} }],
      null,
      "Loading calls...",
      selectedSources[0],
      null,
      [],
      null,
      null,
    );

    // Fetch all uncached sources in parallel
    const fetchPromises = [];
    const sourcesToFetch = [];

    for (const sourcePayload of selectedSources) {
      const fallbackOrigin = `${location.protocol}//${location.host}`;
      const normalizedSourcePayload = {
        ...sourcePayload,
        callUrl: sourcePayload?.callUrl || location.href,
        mainUrl: sourcePayload?.mainUrl || (typeof ns.getMainUrl === "function" ? ns.getMainUrl() : fallbackOrigin),
      };
      const sourceKey = ns.getCallDraftKey(normalizedSourcePayload.callUrl);

      // Check cache first
      const cached = ns.state.draftCacheByCall.get(sourceKey);
      if (!cached) {
        sourcesToFetch.push({ sourcePayload: normalizedSourcePayload, sourceKey });
        fetchPromises.push(ns.fetchAndRenderParse(normalizedSourcePayload, sourceKey, "Parsing calls..."));
      }
    }

    // Wait for all fetches to complete
    if (fetchPromises.length > 0) {
      await Promise.all(fetchPromises);
    }

    // Now collect from cache (both pre-cached and newly fetched)
    const ownerMap = new Map(); // Use Map to deduplicate by ID

    for (const sourcePayload of selectedSources) {
      const fallbackOrigin = `${location.protocol}//${location.host}`;
      const normalizedSourcePayload = {
        ...sourcePayload,
        callUrl: sourcePayload?.callUrl || location.href,
        mainUrl: sourcePayload?.mainUrl || (typeof ns.getMainUrl === "function" ? ns.getMainUrl() : fallbackOrigin),
      };
      const sourceKey = ns.getCallDraftKey(normalizedSourcePayload.callUrl);
      const cached = ns.state.draftCacheByCall.get(sourceKey);

      if (cached) {
        const startIndex = allPreviews.length;
        allPreviews.push(...cached.previews);
        
        // Store parseToken for each preview from this source
        if (cached.parseToken) {
          for (let i = startIndex; i < allPreviews.length; i++) {
            previewTokenMap.set(i, cached.parseToken);
          }
          if (!combinedParseToken) {
            combinedParseToken = cached.parseToken;
          }
        }
        
        if (!combinedMagazineId) {
          combinedMagazineId = cached.magazineId;
          combinedMagazineName = cached.magazineName;
        }
        if (Array.isArray(cached.ownerCandidates)) {
          cached.ownerCandidates.forEach((owner) => {
            if (owner?.id && !ownerMap.has(owner.id)) {
              ownerMap.set(owner.id, owner);
            }
          });
        }
        if (!combinedSelectedOwner && cached.selectedOwner) {
          combinedSelectedOwner = cached.selectedOwner;
        }
      }
    }

    combinedOwnerCandidates = Array.from(ownerMap.values());
    
    // Store preview-to-token mapping in state for use during save
    if (ns.state.activeData) {
      ns.state.activeData.previewTokenMap = previewTokenMap;
    }

    // Render final state with all previews
    if (allPreviews.length > 0) {
      ns.renderEditor(
        allPreviews,
        combinedMagazineId,
        combinedMagazineName,
        selectedSources[0],
        null,
        combinedOwnerCandidates,
        combinedSelectedOwner,
        combinedParseToken,
      );
    }

    ns.clearSelectedCalls();
  };

  ns.injectAddButtons = function injectAddButtons() {
    const categories = document.querySelectorAll(".category.panel-btn");
    const currentSourceKeys = new Set();

    ns.ensureBatchToolbar();

    categories.forEach((cat) => {
      const header = cat.querySelector(".header-3");
      if (!header) return;
      const sourcePayload = ns.buildSourcePayloadFromCategory(cat);
      if (!sourcePayload.callUrl) return;
      const sourceKey = ns.getCallDraftKey(sourcePayload.callUrl);
      if (!sourceKey) return;

      currentSourceKeys.add(sourceKey);
      ns.state.availableCallSources.set(sourceKey, sourcePayload);
      cat.dataset.csCallKey = sourceKey;

      let titleRow = cat.querySelector(".cs-call-title-row");
      if (!titleRow) {
        titleRow = ns.el("div", "cs-call-title-row");
        header.parentNode.insertBefore(titleRow, header);
        titleRow.appendChild(header);
      }

      let checkboxWrap = titleRow.querySelector(".cs-call-select");
      if (!checkboxWrap) {
        checkboxWrap = ns.el("label", "cs-call-select");
        checkboxWrap.innerHTML = `
          <input type="checkbox" class="cs-call-select-input" aria-label="Select this call for batch add">
          <span class="cs-call-select-box"></span>
        `;
        titleRow.insertBefore(checkboxWrap, titleRow.firstChild);
      }

      // Prevent clicks on the label wrapper from bubbling to parent
      checkboxWrap.addEventListener("click", (event) => {
        event.stopPropagation();
      });
      checkboxWrap.addEventListener("mousedown", (event) => {
        event.stopPropagation();
      });

      const checkbox = checkboxWrap.querySelector(".cs-call-select-input");
      if (checkbox) {
        checkbox.checked = ns.state.selectedCallKeys.has(sourceKey);
        checkbox.addEventListener("change", (event) => {
          const isChecked = Boolean(event.currentTarget?.checked);
          if (isChecked) {
            ns.state.selectedCallKeys.add(sourceKey);
          } else {
            ns.state.selectedCallKeys.delete(sourceKey);
          }
          cat.classList.toggle("cs-call-selected", isChecked);
          ns.updateBatchToolbar();
        });
      }

      let btn = titleRow.querySelector(".cs-add-btn");
      if (!btn) {
        btn = ns.el("button", "cs-add-btn");
        btn.title = "Add to ChillSubs";
        btn.innerHTML = `
          <svg viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 1v12M1 7h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          Add
        `;
        titleRow.appendChild(btn);
      }

      btn.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await ns.openSourcePayload(ns.state.availableCallSources.get(sourceKey), "Parsing call...");
      };

      cat.classList.toggle("cs-call-selected", ns.state.selectedCallKeys.has(sourceKey));
    });

    Array.from(ns.state.selectedCallKeys).forEach((sourceKey) => {
      if (!currentSourceKeys.has(sourceKey)) {
        ns.state.selectedCallKeys.delete(sourceKey);
      }
    });
    Array.from(ns.state.availableCallSources.keys()).forEach((sourceKey) => {
      if (!currentSourceKeys.has(sourceKey)) {
        ns.state.availableCallSources.delete(sourceKey);
      }
    });

    ns.updateBatchToolbar();
  };

  ns.observe = function observe() {
    // Existing calls drawer should load on ALL pages
    ns.ensureExistingCallsDrawer();

    // Add buttons only on Submittable hosts
    if (!ns.isSubmittableHost()) return;

    let observer = null;
    let injectionTimeout = null;
    
    const injectWithDebounce = () => {
      // Clear any pending injection
      if (injectionTimeout) clearTimeout(injectionTimeout);
      
      // Debounce injection by 300ms to avoid infinite loops
      injectionTimeout = setTimeout(() => {
        if (observer) observer.disconnect();
        ns.injectAddButtons();
        if (observer) observer.observe(document.body, { childList: true, subtree: true });
      }, 300);
    };

    // Initial inject
    if (observer) observer.disconnect();
    ns.injectAddButtons();

    // Setup observer for future DOM changes
    observer = new MutationObserver(injectWithDebounce);
    observer.observe(document.body, { childList: true, subtree: true });
  };
})();
