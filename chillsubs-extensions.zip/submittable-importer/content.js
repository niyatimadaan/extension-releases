(() => {
  window.ChillSubsExt.observe();
  window.ChillSubsExt.observePagecrawlHandoff();
})();
