(() => {
  const ns = window.ChillSubsExt;
  const ELIGIBILITY_LABELS = {
    location: "Location-specific",
    lgbtq: "LGBTQ+",
    bipoc: "BIPOC",
    women: "Women",
    nonbinary: "Non-binary",
    youngCreators: "Young creators",
    over18: "18+",
    creatorsWithDisabilities: "Creators with disabilities",
    other: "Other restriction",
  };

  function toOwnerLabel(owner) {
    if (!owner) return "";
    if (owner.label) return owner.label;
    const typeLabel = owner.type === "publisher" ? "Press" : owner.type === "organisation" ? "Organisation" : "Magazine";
    return `${typeLabel}: ${owner.name}`;
  }

  function getEligibilityTags(eligibility) {
    return Object.entries(ELIGIBILITY_LABELS)
      .filter(([key]) => Boolean(eligibility?.[key]))
      .map(([key, label]) => ({ key, label }));
  }

  ns.renderEditor = function renderEditor(
    previews,
    magazineId,
    magazineName,
    sourcePayload = null,
    sourceKey = null,
    ownerCandidates = null,
    selectedOwner = null,
    parseToken = null,
    activeTabOverride = 0,
  ) {
    const preparedPreviews = JSON.parse(JSON.stringify(previews));
    preparedPreviews.forEach((preview) => ns.initializePreviewType(preview));
    const normalizedOwnerCandidates = Array.isArray(ownerCandidates)
      ? ownerCandidates
      : selectedOwner
        ? [selectedOwner]
        : magazineId
          ? [{ type: "magazine", id: magazineId, name: magazineName || "Matched Magazine", label: `Magazine: ${magazineName || "Matched Magazine"}` }]
          : [];
    const normalizedSelectedOwner = selectedOwner
      || (normalizedOwnerCandidates.length === 1 ? normalizedOwnerCandidates[0] : null);

    ns.state.activeData = {
      previews: preparedPreviews,
      magazineId,
      magazineName,
      ownerCandidates: normalizedOwnerCandidates,
      selectedOwner: normalizedSelectedOwner,
      parseToken: parseToken || null,
      activeTab: preparedPreviews.length
        ? Math.min(Math.max(activeTabOverride, 0), preparedPreviews.length - 1)
        : 0,
      sourcePayload,
      sourceKey,
    };

    const body = ns.qs("#cs-panel-body");
    body.innerHTML = "";

    const badge = ns.el("div", "cs-mag-badge");
    const selectedOwnerLabel = toOwnerLabel(normalizedSelectedOwner);
    const selectedOwnerId = normalizedSelectedOwner?.id || "";
    badge.innerHTML = `<div class="cs-mag-dot"></div><span class="cs-mag-name">${ns.escHtml(selectedOwnerLabel || (magazineName ?? "Mapped Owner"))}</span>${selectedOwnerId ? `<span class="cs-mag-id" style="margin-left:8px;opacity:.75;">${ns.escHtml(selectedOwnerId)}</span>` : ""}`;
    body.appendChild(badge);

    if (normalizedOwnerCandidates.length > 0) {
      const ownerList = ns.el("div", "cs-owner-map");
      ownerList.innerHTML = `
        <div class="cs-owner-map-title">Mapped Entities</div>
        ${normalizedOwnerCandidates
          .map((owner) => `<div class="cs-owner-map-row">${ns.escHtml(toOwnerLabel(owner))} <span class="cs-owner-map-id">(${ns.escHtml(owner.id)})</span></div>`)
          .join("")}
      `;
      body.appendChild(ownerList);
    }

    if (normalizedOwnerCandidates.length === 0) {
      const ownerManual = ns.el("div", "cs-owner-manual");
      ownerManual.innerHTML = `
        <div class="cs-owner-map-title">Link to Owner</div>
        <div class="cs-error-detail cs-owner-manual-hint">This URL wasn't auto-matched. Fill exactly one ID to link these calls.</div>
        <div class="cs-owner-manual-inputs">
          <div class="cs-owner-manual-row">
            <label class="cs-label">Magazine ID</label>
            <input class="cs-input" id="cs-manual-magazine-id" placeholder="e.g. 64abc…" autocomplete="off" />
          </div>
          <div class="cs-owner-manual-row">
            <label class="cs-label">Publisher ID</label>
            <input class="cs-input" id="cs-manual-publisher-id" placeholder="e.g. 64def…" autocomplete="off" />
          </div>
          <div class="cs-owner-manual-row">
            <label class="cs-label">Organisation ID</label>
            <input class="cs-input" id="cs-manual-org-id" placeholder="e.g. 64ghi…" autocomplete="off" />
          </div>
        </div>
      `;
      body.appendChild(ownerManual);

      function resolveManualOwner() {
        const magId = ns.qs("#cs-manual-magazine-id", body)?.value?.trim() || "";
        const pubId = ns.qs("#cs-manual-publisher-id", body)?.value?.trim() || "";
        const orgId = ns.qs("#cs-manual-org-id", body)?.value?.trim() || "";
        const filled = [
          magId && { type: "magazine", id: magId, label: `Magazine: ${magId}` },
          pubId && { type: "publisher", id: pubId, label: `Press: ${pubId}` },
          orgId && { type: "organisation", id: orgId, label: `Organisation: ${orgId}` },
        ].filter(Boolean);
        ns.state.activeData.selectedOwner = filled.length === 1 ? filled[0] : null;
      }

      ["cs-manual-magazine-id", "cs-manual-publisher-id", "cs-manual-org-id"].forEach((id) => {
        const inp = ns.qs(`#${id}`, body);
        if (inp) inp.addEventListener("input", resolveManualOwner);
      });
    }

    if (normalizedOwnerCandidates.length > 1) {
      const ownerWrap = ns.el("div", "cs-field-group");
      ownerWrap.innerHTML = `
        <label class="cs-label">Save Under</label>
        <select class="cs-select" id="cs-owner-select">
          <option value="">Choose where to create this call</option>
          ${normalizedOwnerCandidates
            .map((owner) => {
              const value = `${owner.type}:${owner.id}`;
              const selected = normalizedSelectedOwner && normalizedSelectedOwner.type === owner.type && normalizedSelectedOwner.id === owner.id
                ? "selected"
                : "";
              return `<option value="${ns.escHtml(value)}" ${selected}>${ns.escHtml(toOwnerLabel(owner))} (${ns.escHtml(owner.id)})</option>`;
            })
            .join("")}
        </select>
      `;
      body.appendChild(ownerWrap);

      const ownerSelect = ns.qs("#cs-owner-select", body);
      if (ownerSelect) {
        ownerSelect.addEventListener("change", () => {
          const selectedValue = ownerSelect.value || "";
          if (!selectedValue.includes(":")) {
            ns.state.activeData.selectedOwner = null;
            ns.saveActiveDraft();
            return;
          }
          const [type, id] = selectedValue.split(":");
          ns.state.activeData.selectedOwner = normalizedOwnerCandidates.find((owner) => owner.type === type && owner.id === id) || null;
          ns.saveActiveDraft();
        });
      }
    }

    const tabsEl = ns.el("div", "cs-tabs");
    preparedPreviews.forEach((p, i) => {
      const tabItem = ns.el("div", `cs-tab-item${i === ns.state.activeData.activeTab ? " cs-active" : ""}`);
      const tab = ns.el("button", "cs-tab");
      tab.type = "button";
      tab.innerHTML = `<span class="cs-tab-label">${ns.escHtml(p.detectedGenre ?? `Call ${i + 1}`)}</span>`;
      tab.addEventListener("click", () => ns.switchTab(i));

      const copyBtn = ns.el("button", "cs-tab-copy");
      copyBtn.type = "button";
      copyBtn.title = "Duplicate this call in a new tab";
      copyBtn.setAttribute("aria-label", `Duplicate ${p.detectedGenre ?? `Call ${i + 1}`}`);
      copyBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="4" y="4" width="7" height="7" rx="1" stroke="currentColor" stroke-width="1.25"/><path d="M1 8V2a1 1 0 0 1 1-1h6" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/></svg>`;
      copyBtn.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        ns.copyPreview(i);
      });

      tabItem.appendChild(tab);
      tabItem.appendChild(copyBtn);

      if (preparedPreviews.length > 1) {
        const removeBtn = ns.el("button", "cs-tab-remove");
        removeBtn.type = "button";
        removeBtn.title = "Remove this parsed call";
        removeBtn.setAttribute("aria-label", `Remove ${p.detectedGenre ?? `Call ${i + 1}`}`);
        removeBtn.innerHTML = "&times;";
        removeBtn.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          ns.removePreview(i);
        });
        tabItem.appendChild(removeBtn);
      }

      tabsEl.appendChild(tabItem);
    });
    body.appendChild(tabsEl);

    const editorWrap = ns.el("div", "");
    editorWrap.id = "cs-editor-wrap";
    editorWrap.style.cssText = "flex:1;overflow:hidden;display:flex;flex-direction:column;";
    body.appendChild(editorWrap);

    if (preparedPreviews.length > 0) {
      ns.renderTabEditor(ns.state.activeData.activeTab);
    } else {
      ns.renderEmptyEditor();
    }

    const footer = ns.qs("#cs-panel-footer");
    footer.style.display = "flex";
    const confirmBtn = ns.qs("#cs-confirm-btn");
    confirmBtn.disabled = preparedPreviews.length === 0;
    confirmBtn.textContent = preparedPreviews.length === 0 ? "No Calls to Save" : "Add to ChillSubs";
  };

  ns.switchTab = function switchTab(index) {
    if (!ns.state.activeData) return;
    if (index < 0 || index >= ns.state.activeData.previews.length) return;
    ns.collectEdits(ns.state.activeData.activeTab);
    ns.state.activeData.activeTab = index;

    const tabs = document.querySelectorAll(".cs-tab-item");
    tabs.forEach((t, i) => t.classList.toggle("cs-active", i === index));

    ns.renderTabEditor(index);
  };

  ns.renderEmptyEditor = function renderEmptyEditor() {
    const wrap = ns.qs("#cs-editor-wrap");
    if (!wrap) return;
    wrap.innerHTML = `
      <div class="cs-editor-empty">
        <div class="cs-editor-empty-title">No parsed calls left</div>
        <div class="cs-error-detail">Reload to re-parse this page, or close the panel.</div>
      </div>
    `;
  };

  ns.removePreview = function removePreview(index) {
    if (!ns.state.activeData) return;
    const { previews, activeTab } = ns.state.activeData;
    if (index < 0 || index >= previews.length) return;

    if (activeTab >= 0 && activeTab < previews.length) {
      ns.collectEdits(activeTab);
    }

    previews.splice(index, 1);

    let nextActiveTab = activeTab;
    if (previews.length === 0) {
      nextActiveTab = 0;
    } else if (activeTab > index) {
      nextActiveTab = activeTab - 1;
    } else if (activeTab === index) {
      nextActiveTab = Math.min(index, previews.length - 1);
    }

    ns.renderEditor(
      previews,
      ns.state.activeData.magazineId,
      ns.state.activeData.magazineName,
      ns.state.activeData.sourcePayload,
      ns.state.activeData.sourceKey,
      ns.state.activeData.ownerCandidates,
      ns.state.activeData.selectedOwner,
      ns.state.activeData.parseToken,
      nextActiveTab,
    );
    ns.saveActiveDraft();
  };

  ns.copyPreview = function copyPreview(index) {
    if (!ns.state.activeData) return;
    const { previews } = ns.state.activeData;
    if (index < 0 || index >= previews.length) return;

    ns.collectEdits(ns.state.activeData.activeTab);
    const scroll = ns.captureEditorScroll();

    const copy = JSON.parse(JSON.stringify(previews[index]));
    previews.splice(index + 1, 0, copy);

    ns.renderEditor(
      previews,
      ns.state.activeData.magazineId,
      ns.state.activeData.magazineName,
      ns.state.activeData.sourcePayload,
      ns.state.activeData.sourceKey,
      ns.state.activeData.ownerCandidates,
      ns.state.activeData.selectedOwner,
      ns.state.activeData.parseToken,
      index + 1,
    );
    ns.restoreEditorScroll(scroll);
    ns.saveActiveDraft();
  };

  ns.renderTabEditor = function renderTabEditor(index) {
    const wrap = ns.qs("#cs-editor-wrap");
    if (!wrap) return;
    const p = ns.state.activeData.previews[index];
    if (!p) {
      ns.renderEmptyEditor();
      return;
    }
    wrap.innerHTML = `<div class="cs-editor-body" id="cs-editor-body">${ns.buildEditorHTML(p, index)}</div>`;
    ns.bindEditorEvents(index);
  };

  ns.buildEditorHTML = function buildEditorHTML(p, idx) {
    ns.normalizeStyleByGenre(p);
    ns.normalizePaymentAmount(p);
    ns.normalizeReadingPeriodModes(p);
    ns.ensureDefaultSubgenresForSelectedGenres(p);
    ns.ensureDefaultStylesForSelectedGenres(p);
    ns.syncPreviewStyles(p);
    ns.syncPreviewSubGenres(p);

    const genreOptions = ["fiction", "nonfiction", "poetry", "hybrid", "multimedia"];
    const typeOptions = ns.getTypeOptionsForPreview(p);
    const statusOpts = ["open", "closed", "archived"];

    const genreChecks = genreOptions
      .map(
        (g) => `
      <label class="cs-check-label">
        <input type="checkbox" data-field="genre.${g}" ${p.genre?.[g] ? "checked" : ""}> ${g}
      </label>
    `,
      )
      .join("");

    const mediumChecks = ["print", "online"]
      .map(
        (m) => `
      <label class="cs-check-label">
        <input type="checkbox" data-field="medium.${m}" ${p.medium?.[m] ? "checked" : ""}> ${m}
      </label>
    `,
      )
      .join("");

    const pays = p.payment?.pays ?? false;
    const charges = p.fee?.charges ?? false;
    const hasFastResponse = Boolean(p.fee?.paidFastResponses?.hasThis);
    // const hasTipJar = Boolean(p.fee?.tipJarOption?.hasThis);
    const hasFeedbackOption = Boolean(p.fee?.feedbackOption?.hasThis);
    const isThemed = p.theme?.isThemedCall ?? false;
    const isContestType = ns.isContestType(p);
    const paymentIsUnspecified = Boolean(p.payment?.amount?.unspecified);
    const paymentIsExact = p.payment?.amount?.exact == null
      ? (p.payment?.amount?.upper == null || p.payment?.amount?.upper === "")
      : Boolean(p.payment?.amount?.exact);
    const useAiEligibility = Boolean(p.useAiEligibility);
    const eligibilityTags = getEligibilityTags(p.aiEligibilityPreview?.eligibility);
    const eligibilityText = String(p.aiEligibilityPreview?.eligibilityText || "").trim();
    const hasEligibilityPreview = Boolean(p.aiEligibilityPreview);

    const subWindows = p.readingPeriod?.subWindows ?? [];
    const closeDate = subWindows[0]?.closeDate ?? "";
    const openDate = subWindows[0]?.openDate ?? "";
    const hasSubmissionCap = Boolean(p.readingPeriod?.submissionCap?.hasThis);
    const submissionCapAmount = p.readingPeriod?.submissionCap?.amount ?? "";

    const payTypeChecks = ["flatRate", "perWord", "perPage", "perPiece", "perLine"]
      .map(
        (pt) => `
      <label class="cs-check-label">
        <input type="checkbox" data-field="payment.type.${pt}" ${p.payment?.type?.[pt] ? "checked" : ""}> ${pt}
      </label>
    `,
      )
      .join("");

    const selectedGenres = genreOptions.filter((g) => p.genre?.[g]);
    const styleGenres = ns.typeRequiresGenreStyle(p)
      ? selectedGenres.filter((genre) => ns.getStyleOptionsForGenre(genre).length > 0)
      : [];
    const styleByGenre = p.styleByGenre || {};
    const subGenreByGenre = p.subGenreByGenre || {};
    
    // Check if current type is book-length
    const pType = String(p?.type || "").trim();
    const pIsBookType = /^bookLength/i.test(pType);
    const isBookLengthType = pIsBookType;

    const multiCall = (ns.state.activeData?.previews?.length ?? 0) > 1;
    const applyAllBtn = (key) => multiCall
      ? `<button type="button" class="cs-apply-all-btn" data-apply-all="${key}">→ all</button>`
      : '';

    // Build style options for book-length types
    const bookStyleOptions = isBookLengthType ? (ns.BOOK_STYLE_OPTIONS || []) : [];
    const styleBlocks = isBookLengthType && bookStyleOptions.length
      ? selectedGenres.length
        ? selectedGenres.map((genre) => {
            const currentBookType = (p.styleByGenre?.[genre] || [])[0] || p.genreStyle || bookStyleOptions[0];
            return `
              <div class="cs-field-group">
                <label class="cs-label">${genre[0].toUpperCase()}${genre.slice(1)} Book Type</label>
                <select class="cs-select" data-style-genre="${ns.escHtml(genre)}">
                  ${bookStyleOptions
                    .map((opt) => `<option value="${ns.escHtml(opt)}" ${currentBookType === opt ? "selected" : ""}>${ns.formatTypeLabel(opt)}</option>`)
                    .join("")}
                </select>
              </div>
            `;
          }).join("")
        : '<div class="cs-field-group"><label class="cs-label">Book Type</label><div class="cs-error-detail">Select at least one genre to choose book type.</div></div>'
      : styleGenres.length
        ? styleGenres
            .map((genre) => {
              const options = ns.getStyleOptionsForGenre(genre);
              const selected = new Set(Array.isArray(styleByGenre[genre]) ? styleByGenre[genre] : []);
              if (selected.size === 0 && options.length > 0) {
                selected.add(options[0]);
              }
              return `
            <div class="cs-field-group">
              <label class="cs-label">${genre[0].toUpperCase()}${genre.slice(1)} style</label>
              <select class="cs-select" data-style-genre="${genre}">
                ${options
                  .map((opt) => `<option value="${ns.escHtml(opt)}" ${selected.has(opt) ? "selected" : ""}>${ns.formatTypeLabel(opt)}</option>`)
                  .join("")}
              </select>
            </div>
          `;
            })
            .join("")
        : selectedGenres.length
          ? '<div class="cs-field-group"><label class="cs-label">Style</label><div class="cs-error-detail">Style is not used for the currently selected genre/type.</div></div>'
          : '<div class="cs-field-group"><label class="cs-label">Style</label><div class="cs-error-detail">Select at least one genre to choose styles.</div></div>';
    const subgenreBlocks = selectedGenres.length
      ? selectedGenres
          .map((genre) => {
            const options = ns.SUBGENRE_OPTIONS_BY_GENRE[genre] || [];
            const selected = new Set(Array.isArray(subGenreByGenre[genre]) ? subGenreByGenre[genre] : []);
            if (selected.size === 0 && options.length > 0) {
              selected.add(options[0]);
            }
            return `
          <div class="cs-field-group">
            <label class="cs-label">${genre[0].toUpperCase()}${genre.slice(1)} subgenres</label>
            <select class="cs-select" data-subgenre-genre="${genre}" multiple>
              ${options
                .map((opt) => `<option value="${ns.escHtml(opt)}" ${selected.has(opt) ? "selected" : ""}>${ns.escHtml(opt)}</option>`)
                .join("")}
            </select>
          </div>
        `;
          })
          .join("")
      : '<div class="cs-field-group"><label class="cs-label">Subgenres</label><div class="cs-error-detail">Select at least one genre to choose subgenres.</div></div>';

    return `
      <div class="cs-section-title">Basic</div>

      <div class="cs-field-group">
        <div class="cs-field-label-row">
          <label class="cs-label">Title</label>
          ${applyAllBtn('title')}
        </div>
        <input class="cs-input" data-field="title" value="${ns.escHtml(p.title ?? "")}" />
      </div>

      <div class="cs-field-row">
        <div class="cs-field-group">
          <label class="cs-label">Type</label>
          <select class="cs-select" data-field="type">
            ${typeOptions
              .map((t) => `<option value="${t}" ${p.type === t ? "selected" : ""}>${ns.formatTypeLabel(t)}</option>`)
              .join("")}
          </select>
        </div>
        <div class="cs-field-group">
          <label class="cs-label">Status</label>
          <select class="cs-select" data-field="status">
            ${statusOpts.map((s) => `<option value="${s}" ${p.status === s ? "selected" : ""}>${s}</option>`).join("")}
          </select>
        </div>
      </div>

      <div class="cs-field-group">
        <label class="cs-label">Description / Guidelines</label>
        <textarea class="cs-textarea" data-field="description" rows="5">${ns.escHtml(p.description ?? "")}</textarea>
      </div>

      <div class="cs-field-group">
        <label class="cs-label">Submission Link</label>
        <input class="cs-input" data-field="link" value="${ns.escHtml(p.link ?? "")}" />
      </div>

      <div class="cs-section-title">Genre</div>

      <div class="cs-field-group">
        <label class="cs-label">Genres</label>
        <div class="cs-checks">${genreChecks}</div>
      </div>

      <div class="cs-field-group">
        <label class="cs-label">Style By Genre</label>
        ${styleBlocks}
      </div>

      <div class="cs-field-group">
        <label class="cs-label">Subgenres By Genre</label>
        ${subgenreBlocks}
      </div>

      <div class="cs-field-group">
        <label class="cs-label">Medium</label>
        <div class="cs-checks">${mediumChecks}</div>
      </div>

      <div class="cs-section-title">Theme ${applyAllBtn('themed')}</div>

      <div class="cs-toggle-row">
        <span class="cs-toggle-label">Themed call</span>
        <label class="cs-toggle">
          <input type="checkbox" data-field="theme.isThemedCall" id="cs-themed-toggle-${idx}" ${isThemed ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>

      <div class="cs-section-title">Reading Period ${applyAllBtn('readingPeriod')}</div>

      <div class="cs-field-group">
        <label class="cs-label">Period Type</label>
        <div class="cs-checks">
          ${["alwaysOpen", "limited", "recurring"]
            .map(
              (pt) => `
            <label class="cs-check-label">
              <input type="checkbox" data-field="readingPeriod.callPeriod.${pt}" ${p.readingPeriod?.callPeriod?.[pt] ? "checked" : ""}> ${pt}
            </label>
          `,
            )
            .join("")}
        </div>
      </div>

      <div class="cs-conditional ${p.readingPeriod?.callPeriod?.alwaysOpen ? "" : "cs-shown"}" id="cs-dates-fields-${idx}">
      <div class="cs-field-row">
        <div class="cs-field-group">
          <label class="cs-label">Open Date</label>
          <input class="cs-input" type="date" data-field="readingPeriod.subWindows.0.openDate" value="${openDate}" />
        </div>
        <div class="cs-field-group">
          <label class="cs-label">Close Date / Deadline</label>
          <input class="cs-input" type="date" data-field="readingPeriod.subWindows.0.closeDate" value="${closeDate}" />
        </div>
      </div>
      </div>

      <div class="cs-toggle-row">
        <span class="cs-toggle-label">Submission cap</span>
        ${applyAllBtn('submissionCap')}
        <label class="cs-toggle">
          <input type="checkbox" data-field="readingPeriod.submissionCap.hasThis" id="cs-submission-cap-toggle-${idx}" ${hasSubmissionCap ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>
      <div class="cs-conditional ${hasSubmissionCap ? "cs-shown" : ""}" id="cs-submission-cap-fields-${idx}">
        <div class="cs-field-group">
          <label class="cs-label">Max submissions allowed</label>
          <input class="cs-input" type="number" min="1" step="1" data-field="readingPeriod.submissionCap.amount" value="${submissionCapAmount}" />
        </div>
      </div>

      <div class="cs-section-title">Payment ${applyAllBtn('payment')}</div>

      <div class="cs-toggle-row">
        <span class="cs-toggle-label">Pays contributors</span>
        <label class="cs-toggle">
          <input type="checkbox" data-field="payment.pays" id="cs-pays-toggle-${idx}" ${pays ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>
      <div class="cs-conditional ${pays ? "cs-shown" : ""}" id="cs-payment-fields-${idx}">
        ${
          isContestType
            ? `
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">Top Prize</label>
              <input class="cs-input" type="number" data-field="payment.additional.topPrize" value="${p.payment?.additional?.topPrize ?? 0}" />
            </div>
            <div class="cs-field-group">
              <label class="cs-label">Total Awarded</label>
              <input class="cs-input" type="number" data-field="payment.prize.totalCashPrize" value="${p.payment?.prize?.totalCashPrize ?? 0}" />
            </div>
          </div>
          <div class="cs-field-group">
            <label class="cs-label">Recognitions</label>
            <div class="cs-checks">
              <label class="cs-check-label">
                <input type="checkbox" data-field="payment.prize.recognitions.longlist" ${p.payment?.prize?.recognitions?.longlist ? "checked" : ""}> Longlist
              </label>
              <label class="cs-check-label">
                <input type="checkbox" data-field="payment.prize.recognitions.shortlist" ${p.payment?.prize?.recognitions?.shortlist ? "checked" : ""}> Shortlist
              </label>
              <label class="cs-check-label">
                <input type="checkbox" data-field="payment.prize.recognitions.honorableMentions" ${p.payment?.prize?.recognitions?.honorableMentions ? "checked" : ""}> Honorable Mentions
              </label>
            </div>
          </div>
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">Currency</label>
              <input class="cs-input" data-field="payment.currency" value="${ns.escHtml(p.payment?.currency ?? "USD")}" />
            </div>
          </div>
          <div class="cs-field-group">
            <label class="cs-label">Additional Info</label>
            <textarea class="cs-textarea" data-field="payment.additional.additionalInfo" rows="2">${ns.escHtml(p.payment?.additional?.additionalInfo ?? "")}</textarea>
          </div>
        `
            : `
          <div class="cs-toggle-row">
            <span class="cs-toggle-label">Exact amount</span>
            <label class="cs-toggle">
              <input type="checkbox" data-field="payment.amount.exact" id="cs-payment-exact-toggle-${idx}" ${paymentIsExact ? "checked" : ""}>
              <span class="cs-toggle-track"></span>
            </label>
          </div>
          <div class="cs-toggle-row">
            <span class="cs-toggle-label">Amount unspecified</span>
            <label class="cs-toggle">
              <input type="checkbox" data-field="payment.amount.unspecified" id="cs-payment-unspecified-toggle-${idx}" ${paymentIsUnspecified ? "checked" : ""}>
              <span class="cs-toggle-track"></span>
            </label>
          </div>
          ${paymentIsUnspecified
            ? `
          <div class="cs-field-group">
            <label class="cs-label">Payment Amount</label>
            <div class="cs-error-detail">This call pays, but the amount is not specified.</div>
          </div>
          `
            : `
          <div class="cs-field-group">
            <label class="cs-label">Payment Type</label>
            <div class="cs-checks">${payTypeChecks}</div>
          </div>
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">${paymentIsExact ? "Amount" : "Amount (lower)"}</label>
              <input class="cs-input" type="number" data-field="payment.amount.lower" value="${p.payment?.amount?.lower ?? ""}" />
            </div>
            ${paymentIsExact
              ? ""
              : `
            <div class="cs-field-group">
              <label class="cs-label">Amount (upper)</label>
              <input class="cs-input" type="number" data-field="payment.amount.upper" value="${p.payment?.amount?.upper ?? ""}" />
            </div>
            `}
          </div>
          `}
          <div class="cs-field-group">
            <label class="cs-label">Currency</label>
            <input class="cs-input" data-field="payment.currency" value="${ns.escHtml(p.payment?.currency ?? "USD")}" />
          </div>
        `
        }
      </div>

      ${isContestType
        ? `
      <div class="cs-section-title">Contest</div>
      <div class="cs-field-group">
        <label class="cs-label">Judges (one per line)</label>
        <textarea class="cs-textarea" data-judges rows="2">${ns.escHtml((p.judges || []).join("\n"))}</textarea>
      </div>
      `
        : ""}

      <div class="cs-section-title">Fee ${applyAllBtn('fee')}</div>

      <div class="cs-toggle-row">
        <span class="cs-toggle-label">Charges submission fee</span>
        <label class="cs-toggle">
          <input type="checkbox" data-field="fee.charges" id="cs-fee-toggle-${idx}" ${charges ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>
      <div class="cs-conditional ${charges ? "cs-shown" : ""}" id="cs-fee-fields-${idx}">
        <div class="cs-field-row">
          <div class="cs-field-group">
            <label class="cs-label">Fee Amount</label>
            <input class="cs-input" type="number" data-field="fee.amount" value="${p.fee?.amount ?? ""}" />
          </div>
          <div class="cs-field-group">
            <label class="cs-label">Currency</label>
            <input class="cs-input" data-field="fee.currency" value="${ns.escHtml(p.fee?.currency ?? "USD")}" />
          </div>
        </div>

        <div class="cs-field-group">
          <label class="cs-label">Fee-free for</label>
          <div class="cs-checks">
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.bipoc" ${p.fee?.feeFreeCategories?.categories?.bipoc ? "checked" : ""}> BIPOC</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.accessbility" ${p.fee?.feeFreeCategories?.categories?.accessbility ? "checked" : ""}> Accessibility</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.lowIncome" ${p.fee?.feeFreeCategories?.categories?.lowIncome ? "checked" : ""}> Low income</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.firstComeFirstServe" ${p.fee?.feeFreeCategories?.categories?.firstComeFirstServe ? "checked" : ""}> First come first serve</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.other" ${p.fee?.feeFreeCategories?.categories?.other ? "checked" : ""}> Other</label>
          </div>
        </div>

        <div class="cs-toggle-row">
          <span class="cs-toggle-label">Paid fast responses</span>
          <label class="cs-toggle">
            <input type="checkbox" data-field="fee.paidFastResponses.hasThis" id="cs-fast-response-toggle-${idx}" ${hasFastResponse ? "checked" : ""}>
            <span class="cs-toggle-track"></span>
          </label>
        </div>
        <div class="cs-conditional ${hasFastResponse ? "cs-shown" : ""}" id="cs-fast-response-fields-${idx}">
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">Amount</label>
              <input class="cs-input" type="number" data-field="fee.paidFastResponses.price.amount" value="${p.fee?.paidFastResponses?.price?.amount ?? ""}" />
            </div>
            <div class="cs-field-group">
              <label class="cs-label">Currency</label>
              <input class="cs-input" data-field="fee.paidFastResponses.price.currency" value="${ns.escHtml(p.fee?.paidFastResponses?.price?.currency ?? "USD")}" />
            </div>
          </div>
        </div>

        ${ /* tip jar option: commented out */ ''}
        <div class="cs-toggle-row">
          <span class="cs-toggle-label">Paid feedback option</span>
          <label class="cs-toggle">
            <input type="checkbox" data-field="fee.feedbackOption.hasThis" id="cs-feedback-toggle-${idx}" ${hasFeedbackOption ? "checked" : ""}>
            <span class="cs-toggle-track"></span>
          </label>
        </div>
        <div class="cs-conditional ${hasFeedbackOption ? "cs-shown" : ""}" id="cs-feedback-fields-${idx}">
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">Amount</label>
              <input class="cs-input" type="number" data-field="fee.feedbackOption.price.amount" value="${p.fee?.feedbackOption?.price?.amount ?? ""}" />
            </div>
            <div class="cs-field-group">
              <label class="cs-label">Currency</label>
              <input class="cs-input" data-field="fee.feedbackOption.price.currency" value="${ns.escHtml(p.fee?.feedbackOption?.price?.currency ?? "USD")}" />
            </div>
          </div>
        </div>
      </div>

      <div class="cs-section-title">Piece Length</div>

      <div class="cs-field-row">
        <div class="cs-field-group">
          <label class="cs-label cs-length-label">Min Words</label>
          <input class="cs-input" type="number" data-field="length.minimumWordCount" value="${p.length?.minimumWordCount ?? ""}" />
        </div>
        <div class="cs-field-group">
          <div class="cs-field-label-row">
            <label class="cs-label">Max Words</label>
            <button type="button" class="cs-reset-icon-btn" data-reset-fields="length.minimumWordCount,length.maximumWordCount" title="Clear word count">↺</button>
          </div>
          <input class="cs-input" type="number" data-field="length.maximumWordCount" value="${p.length?.maximumWordCount ?? ""}" />
        </div>
      </div>

      <div class="cs-field-row">
        <div class="cs-field-group">
          <label class="cs-label cs-length-label">Min Pages</label>
          <input class="cs-input" type="number" data-field="length.minimumPageCount" value="${p.length?.minimumPageCount ?? ""}" />
        </div>
        <div class="cs-field-group">
          <div class="cs-field-label-row">
            <label class="cs-label">Max Pages</label>
            <button type="button" class="cs-reset-icon-btn" data-reset-fields="length.minimumPageCount,length.maximumPageCount" title="Clear page count">↺</button>
          </div>
          <input class="cs-input" type="number" data-field="length.maximumPageCount" value="${p.length?.maximumPageCount ?? ""}" />
        </div>
      </div>

      <div class="cs-field-row">
        <div class="cs-field-group">
          <label class="cs-label cs-length-label">Min Lines</label>
          <input class="cs-input" type="number" data-field="length.minimumLineCount" value="${p.length?.minimumLineCount ?? ""}" />
        </div>
        <div class="cs-field-group">
          <div class="cs-field-label-row">
            <label class="cs-label">Max Lines</label>
            <button type="button" class="cs-reset-icon-btn" data-reset-fields="length.minimumLineCount,length.maximumLineCount" title="Clear line count">↺</button>
          </div>
          <input class="cs-input" type="number" data-field="length.maximumLineCount" value="${p.length?.maximumLineCount ?? ""}" />
        </div>
      </div>

      <div class="cs-field-row">
        <div class="cs-field-group">
          <label class="cs-label cs-length-label">Min Pieces / Submission</label>
          <input class="cs-input" type="number" data-field="minPiecesPerSub" value="${p.minPiecesPerSub ?? ""}" />
        </div>
        <div class="cs-field-group">
          <div class="cs-field-label-row">
            <label class="cs-label">Max Pieces / Submission</label>
            <button type="button" class="cs-reset-icon-btn" data-reset-fields="minPiecesPerSub,maxPiecesPerSub" title="Clear pieces per submission">↺</button>
          </div>
          <input class="cs-input" type="number" data-field="maxPiecesPerSub" value="${p.maxPiecesPerSub ?? ""}" />
        </div>
      </div>

      <div class="cs-section-title">Eligibility ${applyAllBtn('eligibility')}</div>

      <div class="cs-toggle-row">
        <span class="cs-toggle-label">Add eligibility with AI</span>
        <label class="cs-toggle">
          <input type="checkbox" data-field="useAiEligibility" id="cs-eligibility-toggle-${idx}" ${useAiEligibility ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>
      <div class="cs-field-group">
        <div class="cs-error-detail">
          ${useAiEligibility
            ? "AI eligibility is fetched from the current title and guidelines, then saved into ChillSubs eligibility fields."
            : "Turn this on to fetch and show AI-mapped eligibility before saving."}
        </div>
      </div>

      ${useAiEligibility
        ? `
      <div class="cs-eligibility-preview">
        <div class="cs-eligibility-preview-title">AI Fetched Eligibility</div>
        ${p.aiEligibilityLoading
          ? `<div class="cs-eligibility-status">Fetching eligibility...</div>`
          : p.aiEligibilityError
            ? `<div class="cs-eligibility-status cs-eligibility-status-error">${ns.escHtml(p.aiEligibilityError)}</div>`
            : hasEligibilityPreview
              ? `
        <div class="cs-eligibility-tags">
          ${eligibilityTags.length
            ? eligibilityTags.map(({ key, label }) => `<label class="cs-check-label"><input type="checkbox" data-field="eligibility.${key}" ${p.eligibility?.[key] ? "checked" : ""}> ${ns.escHtml(label)}</label>`).join("")
            : '<span class="cs-eligibility-tag cs-eligibility-tag-empty">No restrictions detected</span>'}
        </div>
        <div class="cs-field-group">
          <label class="cs-label">Eligibility Notes</label>
          <textarea class="cs-textarea" data-field="eligibilityText" rows="2">${ns.escHtml(eligibilityText)}</textarea>
        </div>
        `
              : `<div class="cs-eligibility-status">Turn the toggle on to fetch eligibility.</div>`}
      </div>
      `
        : ""}

      <div style="height:8px;"></div>
    `;
  };

  ns.bindEditorEvents = function bindEditorEvents(idx) {
    const body = ns.qs("#cs-editor-body");
    if (!body) return;

    const paysToggle = ns.qs(`#cs-pays-toggle-${idx}`, body);
    const paymentFields = ns.qs(`#cs-payment-fields-${idx}`, body);
    if (paysToggle && paymentFields) {
      paysToggle.addEventListener("change", () => {
        paymentFields.classList.toggle("cs-shown", paysToggle.checked);
        ns.collectEdits(idx);
      });
    }

    const paymentExactToggle = ns.qs(`#cs-payment-exact-toggle-${idx}`, body);
    if (paymentExactToggle) {
      paymentExactToggle.addEventListener("change", () => {
        ns.collectEdits(idx);
        ns.rerenderTabPreservingScroll(idx);
      });
    }

    const paymentUnspecifiedToggle = ns.qs(`#cs-payment-unspecified-toggle-${idx}`, body);
    if (paymentUnspecifiedToggle) {
      paymentUnspecifiedToggle.addEventListener("change", () => {
        ns.collectEdits(idx);
        ns.rerenderTabPreservingScroll(idx);
      });
    }

    const feeToggle = ns.qs(`#cs-fee-toggle-${idx}`, body);
    const feeFields = ns.qs(`#cs-fee-fields-${idx}`, body);
    if (feeToggle && feeFields) {
      feeToggle.addEventListener("change", () => {
        feeFields.classList.toggle("cs-shown", feeToggle.checked);
      });
    }

    const fastResponseToggle = ns.qs(`#cs-fast-response-toggle-${idx}`, body);
    const fastResponseFields = ns.qs(`#cs-fast-response-fields-${idx}`, body);
    if (fastResponseToggle && fastResponseFields) {
      fastResponseToggle.addEventListener("change", () => {
        fastResponseFields.classList.toggle("cs-shown", fastResponseToggle.checked);
      });
    }

    // tip jar option: commented out
    // const tipJarToggle = ns.qs(`#cs-tip-jar-toggle-${idx}`, body);
    // const tipJarFields = ns.qs(`#cs-tip-jar-fields-${idx}`, body);
    // if (tipJarToggle && tipJarFields) {
    //   tipJarToggle.addEventListener("change", () => {
    //     tipJarFields.classList.toggle("cs-shown", tipJarToggle.checked);
    //   });
    // }

    const feedbackOptionToggle = ns.qs(`#cs-feedback-toggle-${idx}`, body);
    const feedbackOptionFields = ns.qs(`#cs-feedback-fields-${idx}`, body);
    if (feedbackOptionToggle && feedbackOptionFields) {
      feedbackOptionToggle.addEventListener("change", () => {
        feedbackOptionFields.classList.toggle("cs-shown", feedbackOptionToggle.checked);
      });
    }

    const eligibilityToggle = ns.qs(`#cs-eligibility-toggle-${idx}`, body);
    if (eligibilityToggle) {
      eligibilityToggle.addEventListener("change", async () => {
        ns.collectEdits(idx);
        const preview = ns.state.activeData?.previews?.[idx];
        if (!preview) return;

        if (!eligibilityToggle.checked) {
          // collectEdits above copied the AI preview inputs into the real fields — undo that.
          preview.eligibility = Object.fromEntries(Object.keys(ELIGIBILITY_LABELS).map((key) => [key, false]));
          preview.eligibilityText = "";
          preview.aiEligibilityLoading = false;
          preview.aiEligibilityError = "";
          preview.aiEligibilityPreview = null;
          ns.saveActiveDraft();
        } else {
          preview.aiEligibilityLoading = true;
          preview.aiEligibilityError = "";
          preview.aiEligibilityPreview = null;
          ns.saveActiveDraft();
        }
        ns.rerenderTabPreservingScroll(idx);

        if (eligibilityToggle.checked) {
          await ns.fetchEligibilityPreview(idx);
        }
      });
    }

    body.querySelectorAll('input[data-field^="readingPeriod.callPeriod."]').forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) {
          body.querySelectorAll('input[data-field^="readingPeriod.callPeriod."]').forEach((other) => {
            if (other !== checkbox) other.checked = false;
          });
        } else if (![...body.querySelectorAll('input[data-field^="readingPeriod.callPeriod."]')].some((item) => item.checked)) {
          checkbox.checked = true;
        }
        ns.collectEdits(idx);
      });
    });

    const submissionCapToggle = ns.qs(`#cs-submission-cap-toggle-${idx}`, body);
    const submissionCapFields = ns.qs(`#cs-submission-cap-fields-${idx}`, body);
    if (submissionCapToggle && submissionCapFields) {
      submissionCapToggle.addEventListener("change", () => {
        submissionCapFields.classList.toggle("cs-shown", submissionCapToggle.checked);
        ns.collectEdits(idx);
      });
    }

    body.querySelectorAll('input[data-field^="genre."]').forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        ns.collectEdits(idx);
        ns.rerenderTabPreservingScroll(idx);
      });
    });

    body.querySelectorAll('[data-style-genre]').forEach((select) => {
      select.addEventListener("change", () => {
        ns.collectEdits(idx);
        ns.rerenderTabPreservingScroll(idx);
      });
    });

    body.querySelectorAll('select[data-field="type"]').forEach((select) => {
      select.addEventListener("change", () => {
        ns.collectEdits(idx);
        ns.rerenderTabPreservingScroll(idx);
      });
    });

    body.querySelectorAll('input[data-field="payment.pays"], input[data-field="fee.charges"]').forEach((input) => {
      input.addEventListener("change", () => {
        ns.collectEdits(idx);
      });
    });

    body.querySelectorAll('input[type="number"]').forEach((input) => {
      input.addEventListener("wheel", () => { input.blur(); }, { passive: true });
    });

    body.querySelectorAll('[data-apply-all]').forEach((btn) => {
      btn.addEventListener('click', () => {
        ns.collectEdits(idx);
        ns.applyToAll(idx, btn.getAttribute('data-apply-all'));
      });
    });

    body.querySelectorAll('[data-reset-fields]').forEach((btn) => {
      btn.addEventListener('click', () => {
        btn.getAttribute('data-reset-fields').split(',').forEach((path) => {
          const input = body.querySelector(`[data-field="${path}"]`);
          if (input) input.value = '';
        });
        ns.collectEdits(idx);
      });
    });
  };

  ns.collectEdits = function collectEdits(index) {
    const body = ns.qs("#cs-editor-body");
    if (!body || !ns.state.activeData) return;

    const preview = ns.state.activeData.previews[index];
    if (!preview) return;

    body.querySelectorAll("[data-field]").forEach((input) => {
      const path = input.dataset.field;
      const parts = path.split(".");

      let value;
      if (input.type === "checkbox") {
        value = input.checked;
      } else if (input.type === "number") {
        value = input.value === "" ? null : Number.parseFloat(input.value);
      } else {
        value = input.value;
      }

      if (parts[0] === "readingPeriod" && parts[1] === "subWindows") {
        const arrIdx = Number.parseInt(parts[2], 10);
        const subKey = parts[3];
        if (!preview.readingPeriod.subWindows[arrIdx]) {
          preview.readingPeriod.subWindows[arrIdx] = {};
        }
        preview.readingPeriod.subWindows[arrIdx][subKey] = value;
        return;
      }

      ns.setDeep(preview, parts, value);
    });

    const nextSubGenreByGenre = { ...(preview.subGenreByGenre || {}) };
    body.querySelectorAll("[data-subgenre-genre]").forEach((select) => {
      const genre = select.getAttribute("data-subgenre-genre");
      if (!genre) return;
      nextSubGenreByGenre[genre] = Array.from(select.selectedOptions).map((option) => option.value);
    });
    preview.subGenreByGenre = nextSubGenreByGenre;

    const nextStyleByGenre = { ...(preview.styleByGenre || {}) };
    body.querySelectorAll("[data-style-genre]").forEach((select) => {
      const genre = select.getAttribute("data-style-genre");
      if (!genre) return;
      nextStyleByGenre[genre] = select.value ? [select.value] : [];
    });
    preview.styleByGenre = nextStyleByGenre;

    const judgesInput = body.querySelector("[data-judges]");
    if (judgesInput) {
      preview.judges = judgesInput.value.split("\n").map((name) => name.trim()).filter(Boolean);
    }

    ns.normalizePaymentAmount(preview);
    ns.normalizeReadingPeriodModes(preview);
    ns.normalizeEligibilityAutomation(preview);
    ns.syncPreviewStyles(preview);
    ns.syncPreviewSubGenres(preview);
    ns.syncPreviewTypeToCallTypes(preview);

    if (preview.fee?.feeFreeCategories?.categories) {
      const cats = preview.fee.feeFreeCategories.categories;
      preview.fee.feeFreeCategories.value = Object.values(cats).some(Boolean);
    }
    
    if (preview?.readingPeriod?.callPeriod?.alwaysOpen) {
      if (preview.readingPeriod.subWindows && preview.readingPeriod.subWindows[0]) {
        preview.readingPeriod.subWindows[0].openDate = null;
        preview.readingPeriod.subWindows[0].closeDate = null;
      }
    }
    
    ns.saveActiveDraft();
  };

  ns.applyToAll = function applyToAll(sourceIdx, key) {
    if (!ns.state.activeData) return;
    const previews = ns.state.activeData.previews;
    const source = previews[sourceIdx];
    if (!source || previews.length <= 1) return;

    previews.forEach((preview, i) => {
      if (i === sourceIdx) return;
      if (key === 'title') {
        preview.title = source.title;
      } else if (key === 'themed') {
        if (!preview.theme) preview.theme = {};
        preview.theme.isThemedCall = source.theme?.isThemedCall ?? false;
      } else if (key === 'payment') {
        preview.payment = JSON.parse(JSON.stringify(source.payment || {}));
      } else if (key === 'readingPeriod') {
        preview.readingPeriod = JSON.parse(JSON.stringify(source.readingPeriod || {}));
      } else if (key === 'submissionCap') {
        if (!preview.readingPeriod) preview.readingPeriod = {};
        preview.readingPeriod.submissionCap = JSON.parse(JSON.stringify(source.readingPeriod?.submissionCap || {}));
      } else if (key === 'fee') {
        preview.fee = JSON.parse(JSON.stringify(source.fee || {}));
      } else if (key === 'eligibility') {
        preview.useAiEligibility = source.useAiEligibility ?? false;
        preview.eligibility = JSON.parse(JSON.stringify(source.eligibility || {}));
        preview.aiEligibilityPreview = source.aiEligibilityPreview
          ? JSON.parse(JSON.stringify(source.aiEligibilityPreview))
          : null;
        preview.aiEligibilityError = source.aiEligibilityError || "";
        preview.aiEligibilityLoading = false;
      }
    });

    ns.saveActiveDraft();
  };

  ns.fetchEligibilityPreview = async function fetchEligibilityPreview(index) {
    const preview = ns.state.activeData?.previews?.[index];
    if (!preview || !preview.useAiEligibility) return;

    preview.aiEligibilityLoading = true;
    preview.aiEligibilityError = "";
    preview.aiEligibilityPreview = null;
    ns.saveActiveDraft();
    ns.rerenderTabPreservingScroll(index);

    try {
      const res = await fetch(`${ns.API_BASE}/extension/preview-eligibility`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: preview.title,
          description: preview.description,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        preview.aiEligibilityError = data.error || "Failed to fetch eligibility.";
        preview.aiEligibilityPreview = null;
      } else {
        preview.aiEligibilityPreview = {
          eligibility: { ...(data.eligibility || {}) },
          eligibilityText: String(data.eligibilityText || ""),
        };
        preview.aiEligibilityError = "";
      }
    } catch {
      preview.aiEligibilityError = "Could not reach ChillSubs backend for eligibility preview.";
      preview.aiEligibilityPreview = null;
    } finally {
      preview.aiEligibilityLoading = false;
      ns.saveActiveDraft();
      ns.rerenderTabPreservingScroll(index);
    }
  };

  ns.handleConfirm = async function handleConfirm() {
    if (!ns.state.activeData) return;

    ns.collectEdits(ns.state.activeData.activeTab);

    if (!Array.isArray(ns.state.activeData.previews) || ns.state.activeData.previews.length === 0) {
      ns.renderError("No parsed calls selected.", "Reload to parse this page again before saving.");
      return;
    }

    const invalidPreview = ns.state.activeData.previews
      .map((preview, index) => ({
        preview,
        index,
        errors: ns.validatePreview(preview),
      }))
      .find((item) => item.errors.length > 0);
    if (invalidPreview) {
      const previewLabel = String(invalidPreview.preview?.title || "").trim() || `Call ${invalidPreview.index + 1}`;
      window.alert(`Fix "${previewLabel}" before saving:\n- ${invalidPreview.errors.join("\n- ")}`);
      return;
    }

    const btn = ns.qs("#cs-confirm-btn");
    btn.disabled = true;
    btn.textContent = "Saving...";

    if (!ns.state.activeData.parseToken) {
      ns.renderError("Missing parse session token.", "Please reload and parse again before saving.");
      btn.disabled = false;
      btn.textContent = "Add to ChillSubs";
      return;
    }

    const ownerCandidates = Array.isArray(ns.state.activeData.ownerCandidates)
      ? ns.state.activeData.ownerCandidates
      : [];
    if (ownerCandidates.length === 0 && !ns.state.activeData.selectedOwner) {
      ns.renderError("Owner required.", "Fill in exactly one Magazine, Publisher, or Organisation ID at the top of the editor.");
      btn.disabled = false;
      btn.textContent = "Add to ChillSubs";
      return;
    }
    if (ownerCandidates.length > 1 && !ns.state.activeData.selectedOwner) {
      ns.renderError("Select where to save this call.", "Multiple mappings were found for this page.");
      btn.disabled = false;
      btn.textContent = "Add to ChillSubs";
      return;
    }

    try {
      const res = await fetch(`${ns.API_BASE}/extension/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          parseToken: ns.state.activeData.parseToken,
          ownerType: ns.state.activeData.selectedOwner?.type || null,
          ownerId: ns.state.activeData.selectedOwner?.id || null,
          calls: ns.state.activeData.previews,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        ns.renderError(data.error ?? "Failed to save.", data.detail ?? "");
        return;
      }

      ns.renderSuccess(data.created ?? []);
      if (ns.state.activeData?.sourceKey) {
        ns.state.draftCacheByCall.delete(ns.state.activeData.sourceKey);
      }
    } catch {
      ns.renderError("Could not reach ChillSubs backend.", "Is the server running on localhost:3001?");
    }
  };

  ns.fetchAndRenderParse = async function fetchAndRenderParse(sourcePayload, sourceKey, loadingMessage = "Parsing call...") {
    ns.renderLoading(loadingMessage);

    try {
      const res = await fetch(ns.getParseEndpoint(sourcePayload), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sourcePayload),
      });

      const data = await res.json();
      if (!res.ok) {
        ns.renderError(data.error ?? "Parse failed.", data.detail ?? "");
        return;
      }

      ns.renderEditor(
        data.previews,
        data.magazineId,
        data.magazineName,
        sourcePayload,
        sourceKey,
        data.ownerCandidates,
        data.selectedOwner,
        data.parseToken,
      );
      ns.saveActiveDraft();
    } catch {
      ns.renderError("Could not reach ChillSubs backend.", "Is the server running on localhost:3001?");
    }
  };

  ns.handleReload = async function handleReload() {
    if (!ns.state.activeData?.sourcePayload || !ns.state.activeData?.sourceKey) return;
    await ns.fetchAndRenderParse(ns.state.activeData.sourcePayload, ns.state.activeData.sourceKey, "Reloading call...");
  };
})();
