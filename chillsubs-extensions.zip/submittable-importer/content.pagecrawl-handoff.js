(() => {
  const ns = window.ChillSubsExt;

  // Hand-off from the PageCrawl webhook review page (backend/calls/webhooks/pagecrawl/review.html
  // and diff-triage*.html): "Open in editor" opens the real Submittable call page with
  // ?csPendingId=<id> (single) or ?csPendingIds=<id1>,<id2>,... (bulk — "open all new calls" for a diff).
  // On load, we fetch GET /webhooks/pagecrawl/pending/:id/resolve per id (same response shape as
  // POST /extension/parse) and render the normal editor directly, with every resolved entry's
  // previews merged into one editor session so they show as tabs via the editor's existing
  // multi-call cs-tabs UI (content.editor.js) — reusing the exact same editor/save pipeline as a
  // manual "Add" click, just skipping the step where a human has to find and click Add per category.
  function getPendingIdsFromUrl() {
    try {
      const params = new URL(location.href).searchParams;
      const bulk = params.get("csPendingIds");
      if (bulk) return bulk.split(",").map((id) => id.trim()).filter(Boolean);
      const single = params.get("csPendingId");
      return single ? [single] : [];
    } catch {
      return [];
    }
  }

  function stripPendingIdFromUrl() {
    try {
      const url = new URL(location.href);
      url.searchParams.delete("csPendingId");
      url.searchParams.delete("csPendingIds");
      history.replaceState(null, "", url.toString());
    } catch {
      // Non-fatal — leaving the param in place just risks re-triggering on reload.
    }
  }

  async function resolvePendingEntry(pendingId) {
    const res = await fetch(`${ns.API_BASE}/webhooks/pagecrawl/pending/${pendingId}/resolve`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  async function openPendingEntries(pendingIds) {
    ns.ensurePanel();
    ns.openPanel();
    ns.renderEditor(
      [{ title: "Loading…", description: "", genre: {}, medium: {} }],
      null, null, null, null, [], null, null,
    );

    // Resolved independently (each id may be a different Submittable category
    // page) — one failure shouldn't sink the rest.
    const settled = await Promise.allSettled(pendingIds.map(resolvePendingEntry));
    const results = [];
    settled.forEach((outcome, i) => {
      if (outcome.status === "fulfilled") {
        results.push(outcome.value);
      } else {
        console.warn(`[pagecrawl-handoff] failed to resolve ${pendingIds[i]}:`, outcome.reason);
      }
    });

    if (!results.length) {
      ns.renderEditor(
        [{ title: "Could not load this call", description: String(settled[0]?.reason?.message || settled[0]?.reason || ""), genre: {}, medium: {} }],
        null, null, null, null, [], null, null,
      );
      return;
    }

    // All entries in one diff share the same tracked page, so owner
    // resolution should agree across them — the first resolved entry's
    // ownerCandidates/selectedOwner/parseToken stand in for the merged
    // session. parseToken only backs owner resolution server-side (see
    // /extension/confirm), not the previews list, so combining previews
    // from separate resolve calls under one parseToken is safe.
    const mergedPreviews = results.flatMap((r) => r.previews);
    const first = results[0];
    const sourcePayload = { callUrl: first.source?.callUrl, mainUrl: first.source?.mainUrl };
    ns.renderEditor(
      mergedPreviews,
      null,
      null,
      sourcePayload,
      ns.getCallDraftKey(first.source?.callUrl),
      first.ownerCandidates,
      first.selectedOwner,
      first.parseToken,
    );

    stripPendingIdFromUrl();
  }

  ns.observePagecrawlHandoff = function observePagecrawlHandoff() {
    if (!ns.isSubmittableHost()) return;
    const pendingIds = getPendingIdsFromUrl();
    if (!pendingIds.length) return;
    openPendingEntries(pendingIds);
  };
})();
