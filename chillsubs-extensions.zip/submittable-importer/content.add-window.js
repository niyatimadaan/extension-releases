(() => {
  const ns = window.ChillSubsExt;

  const FEE_DEFAULT = Object.freeze({
    charges: false,
    amount: 0,
    currency: "USD",
    feeFreeCategories: {
      value: false,
      categories: { bipoc: false, accessbility: false, lowIncome: false, firstComeFirstServe: false, other: true },
    },
    paidFastResponses: { hasThis: false, price: { amount: 0, currency: "USD" } },
    feedbackOption: { hasThis: false, price: { amount: 0, currency: "USD" } },
  });
  const PAYMENT_DEFAULT = Object.freeze({
    pays: false,
    type: { flatRate: false, perWord: false, perPage: false, perPiece: false, perLine: false },
    amount: { exact: true, unspecified: false, lower: null, upper: null },
    currency: "USD",
  });

  const GENRE_OPTIONS = ["fiction", "nonfiction", "poetry", "hybrid", "multimedia"];
  const GENRE_DEFAULT = Object.freeze({
    fiction: false, nonfiction: false, poetry: false, hybrid: false, multimedia: false,
  });

  let overlay = null;
  let currentCallIds = [];
  let currentCallCount = 0;
  let activeSection = "time"; // "time" | "feePay" | "genre" — mutually exclusive; only the active section is edited/sent on save
  let mode = "add"; // "add" | "edit-latest" | "edit-index" | "type-only" — time section only
  let currentLastWindow = null; // { openDate, closeDate } | null — shared last window of all selected calls
  let currentOnSaved = null; // optional callback fired after a successful save
  let currentInitialCloseDate = null;
  let currentCallPeriod = null; // { alwaysOpen, limited, recurring, unconfirmed } — editable, sent back on save
  let currentSubWindows = []; // shared subWindows across selected calls (only when identical), used for recurring edit-index
  let currentWindowIndex = null; // index into currentSubWindows when mode === "edit-index"
  let currentFee = null; // fee edit state — only sent on save when activeSection === "feePay"
  let currentPayment = null; // payment edit state — only sent on save when activeSection === "feePay"
  let currentGenre = null; // single-select genre flags — only sent on save when activeSection === "genre"
  let currentGenreStyle = null;
  let currentSubGenre = []; // only sent on save when activeSection === "genre"
  let currentIsBookLength = false; // true/false when all selected calls agree, null when mixed (blocks the genre section)
  let currentType = null; // Type dropdown value (e.g. "flashFiction", "bookLengthFiction", "shortFictionContest")
  // — drives book-length/contest mode live, unlike currentIsBookLength which only gates bulk edits

  function todayInputDate() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function isoToInputDate(value) {
    // Server provides offset-corrected YYYY-MM-DD strings via lastWindow; pass through directly.
    if (!value || typeof value !== "string") return "";
    return value.trim().slice(0, 10);
  }

  function formatShortDate(value) {
    const d = isoToInputDate(value);
    if (!d) return "—";
    const [, month, day] = d.split("-");
    return `${day}/${month}`;
  }

  // Collapses a possibly-mixed union of flags (from several selected calls) down to
  // one valid state: alwaysOpen/limited/recurring are mutually exclusive, same priority
  // as ns.normalizeReadingPeriodModes uses for a single call.
  function resolveInitialCallPeriod(flags) {
    const modePriority = ["alwaysOpen", "limited", "recurring"];
    const resolvedMode = modePriority.find((m) => flags?.[m]) || "limited";
    return {
      alwaysOpen: resolvedMode === "alwaysOpen",
      limited: resolvedMode === "limited",
      recurring: resolvedMode === "recurring",
      unconfirmed: Boolean(flags?.unconfirmed),
    };
  }

  function sectionSelectHtml() {
    return `
      <div class="cs-aw-field">
        <label class="cs-aw-label" for="cs-aw-section-select">Edit</label>
        <select class="cs-aw-input" id="cs-aw-section-select">
          <option value="time" ${activeSection === "time" ? "selected" : ""}>Time (reading window / call type)</option>
          <option value="feePay" ${activeSection === "feePay" ? "selected" : ""}>Fee &amp; Pay</option>
          <option value="genre" ${activeSection === "genre" ? "selected" : ""}>Genre</option>
        </select>
      </div>`;
  }

  function typeControlsHtml() {
    const period = currentCallPeriod || { alwaysOpen: false, limited: true, recurring: false, unconfirmed: false };
    const pill = (type, label) => `<button class="cs-aw-type-btn${period[type] ? " active" : ""}" data-type="${type}" type="button">${label}</button>`;
    return `
      <div class="cs-aw-type-row">
        <div class="cs-aw-type-pills">
          ${pill("alwaysOpen", "Always Open")}
          ${pill("limited", "Limited")}
          ${pill("recurring", "Recurring")}
        </div>
        <label class="cs-aw-unconfirmed-toggle">
          <input type="checkbox" id="cs-aw-unconfirmed" ${period.unconfirmed ? "checked" : ""}> Unconfirmed
        </label>
      </div>`;
  }

  function modeToggleHtml() {
    const buttons = ['<button class="cs-aw-mode-btn active" data-mode="add" type="button">Add window</button>'];

    if (currentCallPeriod?.recurring && currentSubWindows.length > 0) {
      currentSubWindows.forEach((w, idx) => {
        const isLatest = idx === currentSubWindows.length - 1;
        const label = `${idx + 1}: ${formatShortDate(w.openDate)}–${formatShortDate(w.closeDate)}${isLatest ? " (latest)" : ""}`;
        buttons.push(`<button class="cs-aw-mode-btn" data-mode="edit-index" data-window-index="${idx}" type="button">${label}</button>`);
      });
    } else {
      buttons.push('<button class="cs-aw-mode-btn" data-mode="edit-latest" type="button">Edit latest window</button>');
    }

    return `<div class="cs-aw-mode-toggle">${buttons.join("")}</div>`;
  }

  function feePaymentFieldsHtml() {
    const fee = currentFee || FEE_DEFAULT;
    const payment = currentPayment || PAYMENT_DEFAULT;
    const pays = Boolean(payment.pays);
    const charges = Boolean(fee.charges);
    const hasFastResponse = Boolean(fee.paidFastResponses?.hasThis);
    const hasFeedbackOption = Boolean(fee.feedbackOption?.hasThis);
    const paymentIsUnspecified = Boolean(payment.amount?.unspecified);
    const paymentIsExact = payment.amount?.exact !== false;
    const isContest = /contest/i.test(String(currentType || ""));

    const payTypeChecks = ["flatRate", "perWord", "perPage", "perPiece", "perLine"]
      .map((pt) => `
        <label class="cs-check-label">
          <input type="checkbox" data-field="payment.type.${pt}" ${payment.type?.[pt] ? "checked" : ""}> ${pt}
        </label>
      `)
      .join("");

    const paymentFields = isContest
      ? `
        <div class="cs-field-row">
          <div class="cs-field-group">
            <label class="cs-label">Top Prize</label>
            <input class="cs-input" type="number" data-field="payment.additional.topPrize" value="${payment.additional?.topPrize ?? 0}" />
          </div>
          <div class="cs-field-group">
            <label class="cs-label">Total Awarded</label>
            <input class="cs-input" type="number" data-field="payment.prize.totalCashPrize" value="${payment.prize?.totalCashPrize ?? 0}" />
          </div>
        </div>
        <div class="cs-field-group">
          <label class="cs-label">Recognitions</label>
          <div class="cs-checks">
            <label class="cs-check-label">
              <input type="checkbox" data-field="payment.prize.recognitions.longlist" ${payment.prize?.recognitions?.longlist ? "checked" : ""}> Longlist
            </label>
            <label class="cs-check-label">
              <input type="checkbox" data-field="payment.prize.recognitions.shortlist" ${payment.prize?.recognitions?.shortlist ? "checked" : ""}> Shortlist
            </label>
            <label class="cs-check-label">
              <input type="checkbox" data-field="payment.prize.recognitions.honorableMentions" ${payment.prize?.recognitions?.honorableMentions ? "checked" : ""}> Honorable Mentions
            </label>
          </div>
        </div>
        <div class="cs-field-row">
          <div class="cs-field-group">
            <label class="cs-label">Currency</label>
            <input class="cs-input" data-field="payment.currency" value="${ns.escHtml(payment.currency ?? "USD")}" />
          </div>
        </div>
        <div class="cs-field-group">
          <label class="cs-label">Additional Info</label>
          <textarea class="cs-textarea" data-field="payment.additional.additionalInfo" rows="2">${ns.escHtml(payment.additional?.additionalInfo ?? "")}</textarea>
        </div>
      `
      : `
        <div class="cs-toggle-row">
          <span class="cs-toggle-label">Exact amount</span>
          <label class="cs-toggle">
            <input type="checkbox" data-field="payment.amount.exact" ${paymentIsExact ? "checked" : ""}>
            <span class="cs-toggle-track"></span>
          </label>
        </div>
        <div class="cs-toggle-row">
          <span class="cs-toggle-label">Amount unspecified</span>
          <label class="cs-toggle">
            <input type="checkbox" data-field="payment.amount.unspecified" ${paymentIsUnspecified ? "checked" : ""}>
            <span class="cs-toggle-track"></span>
          </label>
        </div>
        ${paymentIsUnspecified ? "" : `
        <div class="cs-field-group">
          <label class="cs-label">Payment Type</label>
          <div class="cs-checks">${payTypeChecks}</div>
        </div>
        <div class="cs-field-row">
          <div class="cs-field-group">
            <label class="cs-label">${paymentIsExact ? "Amount" : "Amount (lower)"}</label>
            <input class="cs-input" type="number" data-field="payment.amount.lower" value="${payment.amount?.lower ?? ""}" />
          </div>
          ${paymentIsExact ? "" : `
          <div class="cs-field-group">
            <label class="cs-label">Amount (upper)</label>
            <input class="cs-input" type="number" data-field="payment.amount.upper" value="${payment.amount?.upper ?? ""}" />
          </div>
          `}
        </div>
        `}
        <div class="cs-field-group">
          <label class="cs-label">Currency</label>
          <input class="cs-input" data-field="payment.currency" value="${ns.escHtml(payment.currency ?? "USD")}" />
        </div>
      `;

    return `
      <div class="cs-toggle-row">
        <span class="cs-toggle-label">${isContest ? "Gives an award" : "Pays contributors"}</span>
        <label class="cs-toggle">
          <input type="checkbox" data-field="payment.pays" ${pays ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>
      <div class="cs-conditional ${pays ? "cs-shown" : ""}">
        ${paymentFields}
      </div>

      <div class="cs-toggle-row">
        <span class="cs-toggle-label">Charges submission fee</span>
        <label class="cs-toggle">
          <input type="checkbox" data-field="fee.charges" ${charges ? "checked" : ""}>
          <span class="cs-toggle-track"></span>
        </label>
      </div>
      <div class="cs-conditional ${charges ? "cs-shown" : ""}">
        <div class="cs-field-row">
          <div class="cs-field-group">
            <label class="cs-label">Fee Amount</label>
            <input class="cs-input" type="number" data-field="fee.amount" value="${fee.amount ?? ""}" />
          </div>
          <div class="cs-field-group">
            <label class="cs-label">Currency</label>
            <input class="cs-input" data-field="fee.currency" value="${ns.escHtml(fee.currency ?? "USD")}" />
          </div>
        </div>
        <div class="cs-field-group">
          <label class="cs-label">Fee-free for</label>
          <div class="cs-checks">
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.bipoc" ${fee.feeFreeCategories?.categories?.bipoc ? "checked" : ""}> BIPOC</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.accessbility" ${fee.feeFreeCategories?.categories?.accessbility ? "checked" : ""}> Accessibility</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.lowIncome" ${fee.feeFreeCategories?.categories?.lowIncome ? "checked" : ""}> Low income</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.firstComeFirstServe" ${fee.feeFreeCategories?.categories?.firstComeFirstServe ? "checked" : ""}> First come first serve</label>
            <label class="cs-check-label"><input type="checkbox" data-field="fee.feeFreeCategories.categories.other" ${fee.feeFreeCategories?.categories?.other ? "checked" : ""}> Other</label>
          </div>
        </div>
        <div class="cs-toggle-row">
          <span class="cs-toggle-label">Paid fast responses</span>
          <label class="cs-toggle">
            <input type="checkbox" data-field="fee.paidFastResponses.hasThis" ${hasFastResponse ? "checked" : ""}>
            <span class="cs-toggle-track"></span>
          </label>
        </div>
        <div class="cs-conditional ${hasFastResponse ? "cs-shown" : ""}">
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">Amount</label>
              <input class="cs-input" type="number" data-field="fee.paidFastResponses.price.amount" value="${fee.paidFastResponses?.price?.amount ?? ""}" />
            </div>
            <div class="cs-field-group">
              <label class="cs-label">Currency</label>
              <input class="cs-input" data-field="fee.paidFastResponses.price.currency" value="${ns.escHtml(fee.paidFastResponses?.price?.currency ?? "USD")}" />
            </div>
          </div>
        </div>
        <div class="cs-toggle-row">
          <span class="cs-toggle-label">Paid feedback option</span>
          <label class="cs-toggle">
            <input type="checkbox" data-field="fee.feedbackOption.hasThis" ${hasFeedbackOption ? "checked" : ""}>
            <span class="cs-toggle-track"></span>
          </label>
        </div>
        <div class="cs-conditional ${hasFeedbackOption ? "cs-shown" : ""}">
          <div class="cs-field-row">
            <div class="cs-field-group">
              <label class="cs-label">Amount</label>
              <input class="cs-input" type="number" data-field="fee.feedbackOption.price.amount" value="${fee.feedbackOption?.price?.amount ?? ""}" />
            </div>
            <div class="cs-field-group">
              <label class="cs-label">Currency</label>
              <input class="cs-input" data-field="fee.feedbackOption.price.currency" value="${ns.escHtml(fee.feedbackOption?.price?.currency ?? "USD")}" />
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // Reads the fee/payment section's inputs into currentFee/currentPayment. Called on every
  // change inside #cs-aw-fp-fields so state stays live even though only a subset of fields
  // gets rebuilt into HTML after conditional toggles (pays/charges/exact/unspecified etc.).
  function collectFeePaymentFromDom() {
    const container = ns.qs("#cs-aw-fp-fields", overlay);
    if (!container) return;

    container.querySelectorAll("[data-field]").forEach((input) => {
      const parts = input.dataset.field.split(".");
      let value;
      if (input.type === "checkbox") {
        value = input.checked;
      } else if (input.type === "number") {
        value = input.value === "" ? null : Number.parseFloat(input.value);
      } else {
        value = input.value;
      }
      const root = parts[0] === "fee" ? currentFee : currentPayment;
      ns.setDeep(root, parts.slice(1), value);
    });

    if (currentFee?.feeFreeCategories?.categories) {
      currentFee.feeFreeCategories.value = Object.values(currentFee.feeFreeCategories.categories).some(Boolean);
    }
  }

  function renderFeePaymentFieldsOnly() {
    const el = ns.qs("#cs-aw-fp-fields", overlay);
    if (el) el.innerHTML = feePaymentFieldsHtml();
  }

  // Gates bulk genre editing: null (mixed book-length/short-form selection) blocks it
  // outright. bookMode itself is driven live by currentType (see the Type dropdown below),
  // not by this flag — currentIsBookLength only reflects the selected calls' state as of
  // when the modal opened.
  function genreModeInfo() {
    if (currentIsBookLength === null) return null;
    const bookMode = /^bookLength/i.test(String(currentType || ""));
    return { bookMode };
  }

  function genreFieldsHtml() {
    const modeInfo = genreModeInfo();
    if (!modeInfo) {
      return `
        <div class="cs-field-group">
          <label class="cs-label">Genre</label>
          <div class="cs-error-detail">Selected calls mix book-length and short-form types — genre can't be bulk-edited across both kinds at once. Select calls of only one kind.</div>
        </div>`;
    }

    const genre = currentGenre || GENRE_DEFAULT;
    const selectedGenre = GENRE_OPTIONS.find((g) => genre[g]) || null;

    // Keep currentType a valid option for the selected genre — falls back to its first
    // Type option when the genre just changed and the previous type token doesn't apply.
    const typeOptions = selectedGenre ? (ns.TYPE_OPTIONS_BY_GENRE?.[selectedGenre] || []) : [];
    if (selectedGenre && typeOptions.length && !typeOptions.includes(currentType)) {
      currentType = typeOptions[0];
    }

    const bookMode = /^bookLength/i.test(String(currentType || ""));
    const styleOptions = selectedGenre ? (bookMode ? (ns.BOOK_STYLE_OPTIONS || []) : (ns.STYLE_OPTIONS_BY_GENRE?.[selectedGenre] || [])) : [];
    const subGenreOptions = selectedGenre ? (ns.SUBGENRE_OPTIONS_BY_GENRE?.[selectedGenre] || []) : [];
    const selectedSubGenres = new Set(Array.isArray(currentSubGenre) ? currentSubGenre : []);
    const styleLabel = bookMode ? "Book Type" : "Style";

    const genrePills = GENRE_OPTIONS
      .map((g) => `<button class="cs-aw-genre-btn${selectedGenre === g ? " active" : ""}" data-genre="${g}" type="button">${ns.formatTypeLabel ? ns.formatTypeLabel(g) : g}</button>`)
      .join("");

    const typeField = selectedGenre && typeOptions.length
      ? `
        <div class="cs-field-group">
          <label class="cs-label">Type</label>
          <select class="cs-select" id="cs-aw-genre-type">
            ${typeOptions
              .map((t) => `<option value="${t}" ${currentType === t ? "selected" : ""}>${ns.formatTypeLabel(t)}</option>`)
              .join("")}
          </select>
        </div>`
      : "";

    const styleField = styleOptions.length
      ? `
        <div class="cs-field-group">
          <label class="cs-label">${styleLabel}</label>
          <select class="cs-select" id="cs-aw-genre-style">
            ${styleOptions
              .map((opt) => `<option value="${ns.escHtml(opt)}" ${currentGenreStyle === opt ? "selected" : ""}>${ns.formatTypeLabel(opt)}</option>`)
              .join("")}
          </select>
        </div>`
      : "";

    const subGenreField = selectedGenre
      ? `
        <div class="cs-field-group">
          <label class="cs-label">Subgenres</label>
          <div class="cs-checks">
            ${subGenreOptions
              .map((opt) => `
                <label class="cs-check-label">
                  <input type="checkbox" data-subgenre="${ns.escHtml(opt)}" ${selectedSubGenres.has(opt) ? "checked" : ""}> ${ns.escHtml(opt)}
                </label>
              `)
              .join("")}
          </div>
        </div>`
      : '<div class="cs-field-group"><label class="cs-label">Subgenres</label><div class="cs-error-detail">Select a genre to choose subgenres.</div></div>';

    return `
      ${bookMode ? '<div class="cs-aw-always-open-note">This type is book-length — the dropdown below sets a book type, not a short-form style.</div>' : ""}
      <div class="cs-aw-type-pills">${genrePills}</div>
      ${typeField}
      ${styleField}
      ${subGenreField}
    `;
  }

  function renderGenreFieldsOnly() {
    const el = ns.qs("#cs-aw-genre-fields", overlay);
    if (el) el.innerHTML = genreFieldsHtml();
  }

  function fillDates(openValue, closeValue) {
    const openInput = ns.qs("#cs-aw-open-date", overlay);
    const closeInput = ns.qs("#cs-aw-close-date", overlay);
    if (openInput) openInput.value = openValue;
    if (closeInput) closeInput.value = closeValue;
  }

  function ensureOverlay() {
    if (overlay) return overlay;

    overlay = ns.el("div", "cs-aw-overlay");
    overlay.id = "cs-aw-overlay";
    overlay.innerHTML = `
      <div class="cs-aw-modal">
        <div class="cs-aw-header">
          <div class="cs-aw-header-title" id="cs-aw-title">Add Submission Window</div>
          <button class="cs-aw-close" id="cs-aw-close" type="button">Close</button>
        </div>
        <div class="cs-aw-body" id="cs-aw-body"></div>
        <div class="cs-aw-footer">
          <span class="cs-aw-status" id="cs-aw-status"></span>
          <button class="cs-aw-btn-cancel" id="cs-aw-btn-cancel" type="button">Cancel</button>
          <button class="cs-aw-btn-save" id="cs-aw-btn-save" type="button">Add Window</button>
        </div>
      </div>`;

    document.body.appendChild(overlay);

    ns.qs("#cs-aw-close", overlay).addEventListener("click", closeModal);
    ns.qs("#cs-aw-btn-cancel", overlay).addEventListener("click", closeModal);
    ns.qs("#cs-aw-btn-save", overlay).addEventListener("click", handleSave);

    overlay.addEventListener("click", (e) => {
      const typeBtn = e.target.closest(".cs-aw-type-btn");
      if (typeBtn) {
        const type = typeBtn.dataset.type;
        currentCallPeriod = {
          alwaysOpen: type === "alwaysOpen",
          limited: type === "limited",
          recurring: type === "recurring",
          unconfirmed: currentCallPeriod?.unconfirmed || false,
        };
        renderBody();
        return;
      }
      const modeBtn = e.target.closest(".cs-aw-mode-btn");
      if (modeBtn) {
        const windowIndex = modeBtn.dataset.windowIndex !== undefined ? Number(modeBtn.dataset.windowIndex) : null;
        setMode(modeBtn.dataset.mode, windowIndex);
        return;
      }
      const genreBtn = e.target.closest(".cs-aw-genre-btn");
      if (genreBtn) {
        const g = genreBtn.dataset.genre;
        if (!currentGenre?.[g]) {
          currentGenre = { ...GENRE_DEFAULT, [g]: true };
          // A <select> always shows its first option as selected even with no
          // explicit `selected` attribute — default the state to match so a user
          // who never touches the dropdown doesn't silently send genreStyle/type: null.
          // A type token from the previous genre (e.g. "flashFiction") doesn't carry
          // over — reset to this genre's own first Type option.
          const typeOptions = ns.TYPE_OPTIONS_BY_GENRE?.[g] || [];
          currentType = typeOptions.length ? typeOptions[0] : null;
          const bookMode = /^bookLength/i.test(String(currentType || ""));
          const styleOptions = bookMode ? (ns.BOOK_STYLE_OPTIONS || []) : (ns.STYLE_OPTIONS_BY_GENRE?.[g] || []);
          currentGenreStyle = styleOptions.length ? styleOptions[0] : null;
          currentSubGenre = [];
          renderGenreFieldsOnly();
        }
        return;
      }
      if (e.target === overlay) closeModal();
    });

    overlay.addEventListener("change", (e) => {
      if (e.target?.id === "cs-aw-section-select") {
        activeSection = e.target.value === "feePay" ? "feePay" : (e.target.value === "genre" ? "genre" : "time");
        renderBody();
        return;
      }
      if (e.target?.id === "cs-aw-unconfirmed" && currentCallPeriod) {
        currentCallPeriod.unconfirmed = Boolean(e.target.checked);
        return;
      }
      if (e.target?.id === "cs-aw-genre-type") {
        currentType = e.target.value || null;
        // Switching book-length/short-form via Type changes which style options apply.
        // Keep the current style pick when it's still valid (e.g. flashFiction ->
        // flashFictionContest keeps "flash"); only re-default when it isn't (e.g.
        // switching to a book-length type, where the style list becomes book types).
        const genre = currentGenre || GENRE_DEFAULT;
        const selectedGenre = GENRE_OPTIONS.find((g) => genre[g]) || null;
        const bookMode = /^bookLength/i.test(String(currentType || ""));
        const styleOptions = selectedGenre
          ? (bookMode ? (ns.BOOK_STYLE_OPTIONS || []) : (ns.STYLE_OPTIONS_BY_GENRE?.[selectedGenre] || []))
          : [];
        if (!styleOptions.includes(currentGenreStyle)) {
          currentGenreStyle = styleOptions.length ? styleOptions[0] : null;
        }
        renderGenreFieldsOnly();
        return;
      }
      if (e.target?.id === "cs-aw-genre-style") {
        currentGenreStyle = e.target.value || null;
        return;
      }
      if (e.target?.matches?.("[data-subgenre]")) {
        const value = e.target.dataset.subgenre;
        const set = new Set(currentSubGenre || []);
        if (e.target.checked) set.add(value); else set.delete(value);
        currentSubGenre = Array.from(set);
        return;
      }
      if (e.target.closest("#cs-aw-fp-fields")) {
        collectFeePaymentFromDom();
        renderFeePaymentFieldsOnly();
      }
    });

    return overlay;
  }

  function setMode(newMode, windowIndex = null) {
    mode = newMode;
    currentWindowIndex = mode === "edit-index" ? windowIndex : null;
    const isAdd = mode === "add";

    overlay.querySelectorAll(".cs-aw-mode-btn").forEach((btn) => {
      const active = btn.dataset.mode === "edit-index"
        ? (mode === "edit-index" && Number(btn.dataset.windowIndex) === currentWindowIndex)
        : btn.dataset.mode === mode;
      btn.classList.toggle("active", active);
    });

    const titleEl = ns.qs("#cs-aw-title", overlay);
    if (titleEl) {
      titleEl.textContent = isAdd
        ? "Add Submission Window"
        : mode === "edit-index"
          ? `Edit Window ${currentWindowIndex + 1}`
          : "Edit Latest Window";
    }

    const countEl = ns.qs("#cs-aw-count-line", overlay);
    if (countEl) {
      const noun = currentCallCount === 1 ? "call" : "calls";
      countEl.innerHTML = isAdd
        ? `Adding a window to <strong>${currentCallCount}</strong> ${noun}`
        : `Editing window on <strong>${currentCallCount}</strong> ${noun}`;
    }

    const saveBtn = ns.qs("#cs-aw-btn-save", overlay);
    if (saveBtn) saveBtn.textContent = isAdd ? "Add Window" : "Update Window";

    // Fill dates based on mode
    if (isAdd) {
      const today = todayInputDate();
      fillDates(today, currentInitialCloseDate || today);
    } else if (mode === "edit-index") {
      const w = currentSubWindows[currentWindowIndex] || {};
      fillDates(isoToInputDate(w.openDate), isoToInputDate(w.closeDate));
    } else {
      fillDates(
        isoToInputDate(currentLastWindow?.openDate),
        isoToInputDate(currentLastWindow?.closeDate),
      );
    }
  }

  // Renders the Time section (reading window + call type) — the original modal content,
  // unchanged except that it now lives behind the section dropdown instead of always showing.
  function renderTimeSection(body, titleEl, saveBtn) {
    const noun = currentCallCount === 1 ? "call" : "calls";

    // Always Open calls have no reading window — don't offer one, just save the type.
    if (currentCallPeriod?.alwaysOpen) {
      mode = "type-only";
      currentWindowIndex = null;

      body.innerHTML = `
        ${sectionSelectHtml()}

        ${typeControlsHtml()}

        <div class="cs-aw-count-line" id="cs-aw-count-line">
          Setting <strong>${currentCallCount}</strong> ${noun} to Always Open
        </div>

        <div class="cs-aw-always-open-note">Always Open calls have no reading window — saving just updates the call type.</div>`;

      if (titleEl) titleEl.textContent = "Update Call Type";
      if (saveBtn) saveBtn.textContent = "Save";
      return;
    }

    mode = "add";
    currentWindowIndex = null;

    const limited = currentCallPeriod?.limited === true;
    const closeSuffix = limited
      ? '<span class="cs-aw-required">*</span>'
      : '<span class="cs-aw-optional">(optional)</span>';
    const limitedNote = limited
      ? '<div class="cs-aw-limited-note">* Close date is required — this call type is Limited.</div>'
      : "";

    const today = todayInputDate();
    const closeDefault = currentInitialCloseDate || today;

    body.innerHTML = `
      ${sectionSelectHtml()}

      ${modeToggleHtml()}

      ${typeControlsHtml()}

      <div class="cs-aw-count-line" id="cs-aw-count-line">
        Adding a window to <strong>${currentCallCount}</strong> ${noun}
      </div>

      <form class="cs-aw-form" id="cs-aw-form" onsubmit="return false">
        <div class="cs-aw-field">
          <label class="cs-aw-label" for="cs-aw-open-date">
            Open date <span class="cs-aw-optional">(optional)</span>
          </label>
          <input class="cs-aw-input" type="date" id="cs-aw-open-date" value="${today}">
        </div>
        <div class="cs-aw-field">
          <label class="cs-aw-label" for="cs-aw-close-date">
            Close date ${closeSuffix}
          </label>
          <input class="cs-aw-input" type="date" id="cs-aw-close-date" value="${closeDefault}">
          ${limitedNote}
        </div>
      </form>`;

    if (titleEl) titleEl.textContent = "Add Submission Window";
    if (saveBtn) saveBtn.textContent = "Add Window";
  }

  // Renders the Fee & Pay section — time (window/type) is entirely absent from the DOM here,
  // so it can't be touched or sent, matching the Time section's isolation the other way round.
  function renderFeePaySection(body, titleEl, saveBtn) {
    const noun = currentCallCount === 1 ? "call" : "calls";

    body.innerHTML = `
      ${sectionSelectHtml()}

      <div class="cs-aw-count-line">
        Editing fee &amp; payment for <strong>${currentCallCount}</strong> ${noun}
      </div>

      <div id="cs-aw-fp-fields">
        ${feePaymentFieldsHtml()}
      </div>`;

    if (titleEl) titleEl.textContent = "Edit Fee & Payment";
    if (saveBtn) saveBtn.textContent = "Update Fee & Payment";
  }

  // Renders the Genre section — genre, style, and subgenres are edited together and sent
  // as one patch; time and fee/payment fields are entirely absent from the DOM here.
  function renderGenreSection(body, titleEl, saveBtn) {
    const noun = currentCallCount === 1 ? "call" : "calls";

    body.innerHTML = `
      ${sectionSelectHtml()}

      <div class="cs-aw-count-line">
        Editing genre for <strong>${currentCallCount}</strong> ${noun}
      </div>

      <div id="cs-aw-genre-fields">
        ${genreFieldsHtml()}
      </div>`;

    if (titleEl) titleEl.textContent = "Edit Genre";
    if (saveBtn) saveBtn.textContent = "Update Genre";
  }

  // Builds the modal body from current module state. Called on open, on section-dropdown
  // change, and again whenever the call type changes within the Time section.
  function renderBody() {
    const body = ns.qs("#cs-aw-body", overlay);
    if (!body) return;

    const titleEl = ns.qs("#cs-aw-title", overlay);
    const saveBtn = ns.qs("#cs-aw-btn-save", overlay);

    if (activeSection === "feePay") {
      renderFeePaySection(body, titleEl, saveBtn);
      return;
    }
    if (activeSection === "genre") {
      renderGenreSection(body, titleEl, saveBtn);
      return;
    }
    renderTimeSection(body, titleEl, saveBtn);
  }

  function openModal({ callIds, callCount, lastWindow = null, onSaved = null, initialCloseDate = null, callFlags = null, subWindows = null, fee = null, payment = null, genre = null, genreStyle = null, subGenre = null, isBookLength = false, type = null }) {
    currentCallIds = callIds;
    currentCallCount = callCount;
    currentLastWindow = lastWindow;
    currentOnSaved = onSaved;
    currentInitialCloseDate = initialCloseDate;
    currentCallPeriod = resolveInitialCallPeriod(callFlags);
    currentSubWindows = Array.isArray(subWindows) ? subWindows : [];
    currentWindowIndex = null;
    currentFee = JSON.parse(JSON.stringify(fee || FEE_DEFAULT));
    currentPayment = JSON.parse(JSON.stringify(payment || PAYMENT_DEFAULT));
    currentGenre = { ...GENRE_DEFAULT, ...(genre || {}) };
    currentGenreStyle = genreStyle || null;
    currentSubGenre = Array.isArray(subGenre) ? [...subGenre] : [];
    currentIsBookLength = isBookLength;
    currentType = type || null;
    activeSection = "time";
    mode = "add";

    const el = ensureOverlay();
    const statusEl = ns.qs("#cs-aw-status", el);
    const saveBtn = ns.qs("#cs-aw-btn-save", el);

    statusEl.textContent = "";
    statusEl.className = "cs-aw-status";
    if (saveBtn) saveBtn.disabled = false;

    renderBody();

    el.classList.add("cs-open");
  }

  function closeModal() {
    if (overlay) overlay.classList.remove("cs-open");
    currentCallIds = [];
    currentCallCount = 0;
    currentLastWindow = null;
    currentOnSaved = null;
    currentInitialCloseDate = null;
    currentCallPeriod = null;
    currentSubWindows = [];
    currentWindowIndex = null;
    currentFee = null;
    currentPayment = null;
    currentGenre = null;
    currentGenreStyle = null;
    currentSubGenre = [];
    currentIsBookLength = false;
    currentType = null;
    activeSection = "time";
  }

  function finishSave(savedCallback) {
    setTimeout(() => {
      closeModal();
      savedCallback?.();
      ns.exitExistingSelectMode?.();
    }, 1200);
  }

  async function handleSaveTime() {
    const statusEl = ns.qs("#cs-aw-status", overlay);
    const saveBtn = ns.qs("#cs-aw-btn-save", overlay);
    const isTypeOnly = mode === "type-only";
    const isAdd = mode === "add";
    const idleLabel = isTypeOnly ? "Save" : (isAdd ? "Add Window" : "Update Window");

    statusEl.textContent = "";
    statusEl.className = "cs-aw-status";

    let openDate = null;
    let closeDate = null;

    if (!isTypeOnly) {
      openDate = ns.qs("#cs-aw-open-date", overlay)?.value || null;
      closeDate = ns.qs("#cs-aw-close-date", overlay)?.value || null;

      if (currentCallPeriod?.limited && !closeDate) {
        statusEl.textContent = "Close date is required — this call type is Limited.";
        statusEl.classList.add("cs-error");
        return;
      }
    }

    saveBtn.disabled = true;
    saveBtn.textContent = isTypeOnly ? "Saving…" : (isAdd ? "Saving…" : "Updating…");

    try {
      const res = await fetch(`${ns.API_BASE}/extension/call-window`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          callIds: currentCallIds,
          action: mode,
          callPeriod: currentCallPeriod,
          ...(isTypeOnly ? {} : { openDate, closeDate }),
          ...(mode === "edit-index" ? { windowIndex: currentWindowIndex } : {}),
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        statusEl.textContent = data.error || (isTypeOnly ? "Failed to update call type." : (isAdd ? "Failed to add window." : "Failed to update window."));
        statusEl.classList.add("cs-error");
        saveBtn.disabled = false;
        saveBtn.textContent = idleLabel;
        return;
      }

      const noun = data.updated === 1 ? "call" : "calls";
      statusEl.textContent = isTypeOnly
        ? `Call type updated on ${data.updated} ${noun}.`
        : isAdd
          ? `Window added to ${data.updated} ${noun}.`
          : `Window updated on ${data.updated} ${noun}.`;
      statusEl.classList.add("cs-success");
      saveBtn.disabled = false;
      saveBtn.textContent = idleLabel;

      finishSave(currentOnSaved);
    } catch (err) {
      statusEl.textContent = err?.message || "Network error.";
      statusEl.classList.add("cs-error");
      saveBtn.disabled = false;
      saveBtn.textContent = idleLabel;
    }
  }

  async function handleSaveFeePayment() {
    const statusEl = ns.qs("#cs-aw-status", overlay);
    const saveBtn = ns.qs("#cs-aw-btn-save", overlay);
    const idleLabel = "Update Fee & Payment";

    statusEl.textContent = "";
    statusEl.className = "cs-aw-status";

    collectFeePaymentFromDom();

    if (currentFee.charges && !(Number(currentFee.amount) > 0)) {
      statusEl.textContent = "Fee amount is required when the call charges a fee.";
      statusEl.classList.add("cs-error");
      return;
    }
    const isContest = /contest/i.test(String(currentType || ""));
    if (currentPayment.pays) {
      if (isContest) {
        const hasPrize = Number(currentPayment.prize?.totalCashPrize) > 0 || Number(currentPayment.additional?.topPrize) > 0;
        if (!hasPrize) {
          statusEl.textContent = "Contest calls that pay must include a prize amount or total awarded.";
          statusEl.classList.add("cs-error");
          return;
        }
      } else if (!currentPayment.amount?.unspecified) {
        const hasAmount = Number(currentPayment.amount?.lower) > 0 || Number(currentPayment.amount?.upper) > 0;
        if (!hasAmount) {
          statusEl.textContent = "Payment amount is required when the call pays contributors (or mark it unspecified).";
          statusEl.classList.add("cs-error");
          return;
        }
      }
    }

    saveBtn.disabled = true;
    saveBtn.textContent = "Saving…";

    try {
      const res = await fetch(`${ns.API_BASE}/extension/call-fee-payment`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ callIds: currentCallIds, fee: currentFee, payment: currentPayment }),
      });
      const data = await res.json();

      if (!res.ok) {
        statusEl.textContent = data.error || "Failed to update fee & payment.";
        statusEl.classList.add("cs-error");
        saveBtn.disabled = false;
        saveBtn.textContent = idleLabel;
        return;
      }

      const noun = data.updated === 1 ? "call" : "calls";
      statusEl.textContent = `Fee & payment updated on ${data.updated} ${noun}.`;
      statusEl.classList.add("cs-success");
      saveBtn.disabled = false;
      saveBtn.textContent = idleLabel;

      finishSave(currentOnSaved);
    } catch (err) {
      statusEl.textContent = err?.message || "Network error.";
      statusEl.classList.add("cs-error");
      saveBtn.disabled = false;
      saveBtn.textContent = idleLabel;
    }
  }

  async function handleSaveGenre() {
    const statusEl = ns.qs("#cs-aw-status", overlay);
    const saveBtn = ns.qs("#cs-aw-btn-save", overlay);
    const idleLabel = "Update Genre";

    statusEl.textContent = "";
    statusEl.className = "cs-aw-status";

    const modeInfo = genreModeInfo();
    if (!modeInfo) {
      statusEl.textContent = "Selected calls mix book-length and short-form types — narrow your selection.";
      statusEl.classList.add("cs-error");
      return;
    }

    const selectedGenre = GENRE_OPTIONS.find((g) => currentGenre?.[g]);
    if (!selectedGenre) {
      statusEl.textContent = "Select a genre.";
      statusEl.classList.add("cs-error");
      return;
    }
    if (!currentSubGenre.length) {
      statusEl.textContent = "Select at least one subgenre.";
      statusEl.classList.add("cs-error");
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = "Saving…";

    try {
      const res = await fetch(`${ns.API_BASE}/extension/call-genre`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          callIds: currentCallIds,
          genre: currentGenre,
          genreStyle: currentGenreStyle,
          subGenre: currentSubGenre,
          type: currentType,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        statusEl.textContent = data.detail || data.error || "Failed to update genre.";
        statusEl.classList.add("cs-error");
        saveBtn.disabled = false;
        saveBtn.textContent = idleLabel;
        return;
      }

      const noun = data.updated === 1 ? "call" : "calls";
      statusEl.textContent = `Genre updated on ${data.updated} ${noun}.`;
      statusEl.classList.add("cs-success");
      saveBtn.disabled = false;
      saveBtn.textContent = idleLabel;

      finishSave(currentOnSaved);
    } catch (err) {
      statusEl.textContent = err?.message || "Network error.";
      statusEl.classList.add("cs-error");
      saveBtn.disabled = false;
      saveBtn.textContent = idleLabel;
    }
  }

  function handleSave() {
    if (activeSection === "feePay") return handleSaveFeePayment();
    if (activeSection === "genre") return handleSaveGenre();
    return handleSaveTime();
  }

  ns.openAddWindowModal = openModal;
})();
