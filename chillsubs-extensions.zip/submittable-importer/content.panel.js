(() => {
  const ns = window.ChillSubsExt;

  ns.ensurePanel = function ensurePanel() {
    if (ns.state.panelEl) return;

    ns.state.overlayEl = ns.el("div", "");
    ns.state.overlayEl.id = "cs-overlay";
    ns.state.overlayEl.addEventListener("click", ns.closePanel);
    document.body.appendChild(ns.state.overlayEl);

    ns.state.panelEl = ns.el("div", "");
    ns.state.panelEl.id = "cs-panel";
    ns.state.panelEl.innerHTML = `
      <div class="cs-panel-header">
        <div class="cs-panel-header-left">
          <span class="cs-panel-logo">ChillSubs</span>
          <span class="cs-panel-sub">Submittable Importer</span>
        </div>
        <button class="cs-close-btn" id="cs-close-btn" title="Close">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M3 3L13 13M13 3L3 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
        </button>
      </div>
      <div id="cs-panel-body" style="display:flex;flex-direction:column;flex:1;overflow:hidden;"></div>
      <div class="cs-panel-footer" id="cs-panel-footer" style="display:none;">
        <button class="cs-btn-secondary" id="cs-cancel-btn">Cancel</button>
        <button class="cs-btn-secondary" id="cs-reload-btn">Reload</button>
        <button class="cs-btn-primary" id="cs-confirm-btn">Add to ChillSubs</button>
      </div>
    `;
    document.body.appendChild(ns.state.panelEl);

    ns.qs("#cs-close-btn").addEventListener("click", ns.closePanel);
    ns.qs("#cs-cancel-btn", ns.state.panelEl).addEventListener("click", ns.closePanel);
    ns.qs("#cs-reload-btn", ns.state.panelEl).addEventListener("click", ns.handleReload);
    ns.qs("#cs-confirm-btn", ns.state.panelEl).addEventListener("click", ns.handleConfirm);
  };

  ns.openPanel = function openPanel() {
    ns.state.overlayEl.classList.add("cs-visible");
    ns.state.panelEl.classList.add("cs-open");
  };

  ns.closePanel = function closePanel() {
    if (ns.state.activeData && typeof ns.collectEdits === "function") {
      ns.collectEdits(ns.state.activeData.activeTab);
      ns.saveActiveDraft();
    }
    ns.state.overlayEl.classList.remove("cs-visible");
    ns.state.panelEl.classList.remove("cs-open");
    ns.state.activeData = null;
  };

  ns.renderLoading = function renderLoading(message = "Parsing call...") {
    ns.qs("#cs-panel-footer").style.display = "none";
    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-loading">
        <div class="cs-spinner"></div>
        <span class="cs-loading-text">${message}</span>
      </div>
    `;
  };

  ns.renderError = function renderError(message, detail = "") {
    const footer = ns.qs("#cs-panel-footer");
    footer.style.display = "none";
    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-error">
        <div class="cs-error-icon">⊘</div>
        <div class="cs-error-msg">${ns.escHtml(message)}</div>
        ${detail ? `<div class="cs-error-detail">${ns.escHtml(detail)}</div>` : ""}
        ${ns.state.activeData ? `<button type="button" class="cs-error-back-btn" id="cs-error-back-btn">← Back</button>` : ""}
      </div>
    `;

    if (ns.state.activeData) {
      const backBtn = ns.qs("#cs-error-back-btn");
      if (backBtn) {
        backBtn.addEventListener("click", () => {
          const { previews, magazineId, magazineName, sourcePayload, sourceKey, ownerCandidates, selectedOwner, parseToken, activeTab } = ns.state.activeData;
          ns.renderEditor(previews, magazineId, magazineName, sourcePayload, sourceKey, ownerCandidates, selectedOwner, parseToken, activeTab);
        });
      }
    }
  };

  ns.renderSuccess = function renderSuccess(created) {
    ns.qs("#cs-panel-footer").style.display = "none";
    const names = created.map((c) => `<li>${c.title}</li>`).join("");
    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-success">
        <div class="cs-success-icon">✓</div>
        <div class="cs-success-title">Added to ChillSubs</div>
        <div class="cs-success-detail">${created.length} call${created.length !== 1 ? "s" : ""} saved successfully.</div>
        <ul class="cs-created-list">${names}</ul>
      </div>
    `;
    setTimeout(ns.closePanel, 3500);
  };
})();
