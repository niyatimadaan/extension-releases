(() => {
  const ns = window.ChillSubsExt;

  // sourceKey → { callId, callTitle, ownerLabel, autoReason? }
  const matchState = new Map();

  // sourceKey → Set of button elements. A single call can render more than one
  // Match button sharing the same sourceKey (e.g. Duosuma lists the same call
  // both in its "Quick Links" list and again in its detail card, with an
  // identical submit href) — all of them need to flip to "Linked" together.
  const buttonsBySourceKey = new Map();

  function registerMatchButton(sourceKey, btn) {
    let set = buttonsBySourceKey.get(sourceKey);
    if (!set) {
      set = new Set();
      buttonsBySourceKey.set(sourceKey, set);
    }
    set.add(btn);
  }

  function applyLinkedState(sourceKey, matchedCalls, sourcePayload) {
    const buttons = buttonsBySourceKey.get(sourceKey);
    if (!buttons) return;
    buttons.forEach((btn) => {
      if (!btn.isConnected) { buttons.delete(btn); return; }
      btn.textContent = "Linked";
      btn.classList.add("cs-match-btn--linked");
      updateAddDateButton(btn, matchedCalls, sourcePayload);
    });
  }

  let callsCache = null;
  let callsCacheLoading = false;
  let callsCacheCallbacks = [];

  // ── Helpers ───────────────────────────────────────────────────────────────────

  function normalizeUrl(url) {
    if (!url) return "";
    try {
      const u = new URL(String(url).trim());
      return `${u.host}${u.pathname}`.toLowerCase().replace(/\/$/, "");
    } catch {
      return String(url).trim().toLowerCase();
    }
  }

  function normalizeTitle(title) {
    return String(title || "").trim().toLowerCase().replace(/\s+/g, " ");
  }
  ns.normalizeMatchTitle = normalizeTitle;

  function stripHtml(html) {
    return String(html || "").replace(/<[^>]*>/g, "").replace(/&nbsp;/g, " ").trim();
  }

  // Extract YYYY-MM-DD from either a date-only or full ISO datetime string
  function extractDateStr(value) {
    if (!value) return "";
    const m = String(value).match(/^(\d{4}-\d{2}-\d{2})/);
    return m ? m[1] : "";
  }

  function getCallVariantLabel(call) {
    if (call?.callMetadata?.variant) {
      return call.callMetadata.variant.toLowerCase().replace(/_/g, " ");
    }
    const genre = call?.genre || {};
    if (genre.fiction)    return "fiction";
    if (genre.nonfiction) return "nonfiction";
    if (genre.poetry)     return "poetry";
    if (genre.hybrid)     return "hybrid";
    if (genre.multimedia) return "multimedia";
    return "general";
  }

  function formatDisplayDate(value) {
    const d = extractDateStr(value);
    if (!d) return "—";
    const [y, mo, day] = d.split("-");
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return `${months[+mo - 1]} ${+day}, ${y}`;
  }

  // ── "Add date" button (shown alongside "Linked" when the matched call is closed) ──

  // Adds/removes the "Add date" button next to the Match/Linked button based on
  // whether any of the matched calls is currently closed (uses the server-computed
  // temporalState from computeCallTemporalState). A single Submittable listing is
  // often mapped to several DB calls (e.g. one per genre variant), so the date
  // update applies to ALL matched calls at once.
  function updateAddDateButton(matchBtn, calls, sourcePayload) {
    const titleRow = matchBtn.parentElement;
    if (!titleRow) return;
    let addDateBtn = titleRow.querySelector(".cs-match-adddate-btn");

    const matchedCalls = Array.isArray(calls) ? calls : [calls];
    const isClosed = matchedCalls.some((c) => c?.temporalState?.state === "closed");
    if (!isClosed) {
      if (addDateBtn) addDateBtn.remove();
      return;
    }

    if (!addDateBtn) {
      addDateBtn = ns.el("button", "cs-match-btn cs-match-adddate-btn");
      addDateBtn.type = "button";
      addDateBtn.textContent = "Add date";
      matchBtn.insertAdjacentElement("beforebegin", addDateBtn);
    }

    addDateBtn.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();

      ns.openAddWindowModal({
        callIds: matchedCalls.map((c) => c.id),
        callCount: matchedCalls.length,
        initialCloseDate: ns.extractDeadlineDate(sourcePayload.deadline),
        callFlags: ns.getCallPeriodFlags(matchedCalls),
        subWindows: ns.getSharedSubWindows(matchedCalls),
        onSaved: () => {
          callsCache = null;
          ns.clearDuosumaCallsCache?.();
          addDateBtn.remove();
        },
      });
    };
  }

  function clearAddDateButton(cat) {
    cat.querySelector(".cs-match-adddate-btn")?.remove();
  }

  // Returns IDs of ALL calls matching by link or title
  function defaultAutoMatchAllIds(sourcePayload, calls) {
    const matched = new Set();
    const incomingUrl   = normalizeUrl(sourcePayload.callUrl);
    const incomingTitle = normalizeTitle(sourcePayload.title);
    for (const c of calls) {
      if (incomingUrl   && normalizeUrl(c.link)    === incomingUrl)   { matched.add(c.id); continue; }
      if (incomingTitle && normalizeTitle(c.title) === incomingTitle)   matched.add(c.id);
    }
    return matched;
  }

  // Dispatches to a provider-specific auto-matcher (e.g. Duosuma's base-ID
  // comparison, since its links aren't stable enough for direct equality).
  function autoMatchAllIds(sourcePayload, calls) {
    if (sourcePayload?.provider === "duosuma") return ns.autoMatchDuosumaIds(sourcePayload, calls);
    return defaultAutoMatchAllIds(sourcePayload, calls);
  }

  function computeAutoMatchReason(sourcePayload, call) {
    if (sourcePayload?.provider === "duosuma") return ns.duosumaMatchReason(sourcePayload, call);
    return normalizeUrl(call.link) === normalizeUrl(sourcePayload.callUrl) ? "link" : "title";
  }

  // ── Word-level diff → HTML ────────────────────────────────────────────────────
  // Returns HTML with <mark class="cs-diff-add"> for words in newStr only
  // and <del class="cs-diff-del"> for words in oldStr only.

  function diffHtml(oldStr, newStr) {
    const esc = (s) => ns.escHtml(s);
    if (!oldStr && !newStr) return "";
    if (!oldStr) return `<mark class="cs-diff-add">${esc(newStr)}</mark>`;
    if (!newStr) return `<del class="cs-diff-del">${esc(oldStr)}</del>`;
    if (oldStr === newStr) return esc(oldStr);

    const oldW = oldStr.split(/(\s+)/);
    const newW = newStr.split(/(\s+)/);
    const m = oldW.length, n = newW.length;

    // LCS table
    const dp = Array.from({ length: m + 1 }, () => new Uint16Array(n + 1));
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = oldW[i - 1] === newW[j - 1]
          ? dp[i - 1][j - 1] + 1
          : Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }

    // Backtrack
    const ops = [];
    let i = m, j = n;
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && oldW[i - 1] === newW[j - 1]) {
        ops.unshift({ t: "=", s: oldW[i - 1] }); i--; j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        ops.unshift({ t: "+", s: newW[j - 1] }); j--;
      } else {
        ops.unshift({ t: "-", s: oldW[i - 1] }); i--;
      }
    }

    return ops.map((op) => {
      const e = esc(op.s);
      if (op.t === "+") return `<mark class="cs-diff-add">${e}</mark>`;
      if (op.t === "-") return `<del  class="cs-diff-del">${e}</del>`;
      return e;
    }).join("");
  }

  // ── Cache ─────────────────────────────────────────────────────────────────────

  async function ensureCallsLoaded() {
    if (callsCache !== null) return callsCache;
    if (callsCacheLoading) {
      return new Promise((resolve) => callsCacheCallbacks.push(resolve));
    }
    callsCacheLoading = true;
    try {
      const mainUrl = typeof ns.getMainUrl === "function"
        ? ns.getMainUrl()
        : `${location.protocol}//${location.host}`;
      const res = await fetch(
        `${ns.API_BASE}/extension/calls-for-match?mainUrl=${encodeURIComponent(mainUrl)}`,
      );
      const data = await res.json();
      callsCache = Array.isArray(data.calls) ? data.calls : [];
    } catch {
      callsCache = [];
    }
    callsCacheLoading = false;
    callsCacheCallbacks.forEach((cb) => cb(callsCache));
    callsCacheCallbacks = [];
    return callsCache;
  }

  // ── Button injection ──────────────────────────────────────────────────────────

  // Shared by Submittable and Duosuma: appends a Match/Linked button into
  // `anchorEl`, wires the click-to-open-panel handler, and silently
  // auto-matches on load. `cat` is threaded through to the panel functions
  // for later re-querying (for Submittable it's the whole `.category.panel-btn`
  // row; for Duosuma it's the same element as `anchorEl`, since there's no
  // separate row container). `loadCalls` defaults to Submittable's loader.
  ns.attachMatchButton = function attachMatchButton(cat, anchorEl, sourceKey, sourcePayload, loadCalls = ensureCallsLoaded) {
    if (!anchorEl || anchorEl.querySelector(".cs-match-btn")) return;

    const btn = ns.el("button", "cs-match-btn");
    btn.type = "button";
    btn.textContent = "Match";
    anchorEl.appendChild(btn);
    registerMatchButton(sourceKey, btn);

    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const calls = await loadCalls();
      openCallListPanel(cat, sourceKey, sourcePayload, calls);
    });

    // Auto-match on load — silently marks the button(s)
    loadCalls().then((calls) => {
      if (!cat.isConnected) return;

      // A sibling occurrence of this same sourceKey may have already
      // resolved the match — reuse it instead of recomputing.
      if (matchState.has(sourceKey)) {
        const { callIds } = matchState.get(sourceKey);
        const matchedCalls = calls.filter((c) => callIds.includes(c.id));
        if (matchedCalls.length) applyLinkedState(sourceKey, matchedCalls, sourcePayload);
        return;
      }

      const autoIds = autoMatchAllIds(sourcePayload, calls);
      if (!autoIds.size) return;

      const matchedCalls = calls.filter((c) => autoIds.has(c.id));
      const first = matchedCalls[0];
      matchState.set(sourceKey, {
        callIds: matchedCalls.map((c) => c.id),
        callId: first.id,
        callTitle: first.title,
        ownerLabel: first.ownerLabel,
        autoReason: computeAutoMatchReason(sourcePayload, first),
      });
      applyLinkedState(sourceKey, matchedCalls, sourcePayload);
    });
  };

  ns.injectMatchButtons = function injectMatchButtons() {
    document.querySelectorAll(".category.panel-btn").forEach((cat) => {
      if (!cat.dataset.csClickGuard) {
        cat.dataset.csClickGuard = "1";
        cat.addEventListener("click", (e) => {
          if (
            e.target.closest(".submit-column") ||
            e.target.closest(".more-column") ||
            e.target.closest(".cs-call-title-row")
          ) return;
          e.stopImmediatePropagation();
          e.preventDefault();
        }, true);
      }

      const titleRow = cat.querySelector(".cs-call-title-row");
      if (!titleRow) return;
      const sourceKey = cat.dataset.csCallKey;
      if (!sourceKey) return;
      const sourcePayload = ns.state.availableCallSources.get(sourceKey);
      if (!sourcePayload) return;

      ns.attachMatchButton(cat, titleRow, sourceKey, sourcePayload);
    });
  };

  // ── Panel helper ──────────────────────────────────────────────────────────────

  function preparePanel() {
    ns.ensurePanel();
    const footer = ns.qs("#cs-panel-footer", ns.state.panelEl);
    if (footer) footer.style.display = "none";
  }

  // ── Screen 1: call list with checkboxes ───────────────────────────────────────

  function openCallListPanel(cat, sourceKey, sourcePayload, calls) {
    preparePanel();

    const autoIds = autoMatchAllIds(sourcePayload, calls);

    // Collect IDs already matched by OTHER source keys on this page
    const otherMatchedIds = new Set(
      [...matchState.entries()]
        .filter(([k]) => k !== sourceKey)
        .flatMap(([, s]) => s.callIds || [s.callId]),
    );

    // Sort: auto-matched → unlinked open → unlinked closed → already linked elsewhere
    const sorted = [...calls].sort((a, b) => {
      const aAuto  = autoIds.has(a.id)        ? 0 : 1;
      const bAuto  = autoIds.has(b.id)        ? 0 : 1;
      const aOther = otherMatchedIds.has(a.id) ? 1 : 0;
      const bOther = otherMatchedIds.has(b.id) ? 1 : 0;
      if (aOther !== bOther) return aOther - bOther;   // already-linked last
      if (aAuto  !== bAuto)  return aAuto  - bAuto;    // auto first
      const aOpen = a.temporalState?.state === "open" ? 0 : 1;
      const bOpen = b.temporalState?.state === "open" ? 0 : 1;
      return aOpen - bOpen;
    });

    const rows = sorted.map((call) => {
      const isOpen    = call.temporalState?.state === "open";
      const isAuto    = autoIds.has(call.id);
      const isLinked  = otherMatchedIds.has(call.id);
      const autoReason = isAuto ? computeAutoMatchReason(sourcePayload, call) : null;
      const descPlain  = stripHtml(call.description);
      const descPreview = descPlain.length > 120 ? descPlain.slice(0, 120) + "…" : descPlain;

      let rowClass = "cs-mcl-row";
      if (isAuto)   rowClass += " cs-mcl-row--auto";
      if (isLinked) rowClass += " cs-mcl-row--linked";

      const variantLabel = getCallVariantLabel(call);

      return `
        <label class="${rowClass}">
          <input type="checkbox" class="cs-mcl-cb" value="${ns.escHtml(call.id)}"
                 ${isAuto ? "checked" : ""}>
          <div class="cs-mcl-row-main">
            <div class="cs-mcl-title">
              ${ns.escHtml(call.title || "Untitled")}
              <span class="cs-mcl-variant">${ns.escHtml(variantLabel)}</span>
            </div>
            <div class="cs-mcl-meta">
              ${call.ownerLabel ? `<span class="cs-mcl-owner">${ns.escHtml(call.ownerLabel)}</span>` : ""}
              <span class="cs-match-status ${isOpen ? "cs-match-status--open" : "cs-match-status--closed"}">
                ${isOpen ? "open" : (call.temporalState?.state || "closed")}
              </span>
              ${isAuto   ? `<span class="cs-match-auto-badge">auto · ${autoReason}</span>` : ""}
              ${isLinked ? `<span class="cs-mcl-linked-badge">linked</span>` : ""}
            </div>
            ${descPreview ? `<div class="cs-mcl-desc">${ns.escHtml(descPreview)}</div>` : ""}
          </div>
        </label>`;
    }).join("");

    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-editor-body">
        <div class="cs-field-group">
          <div class="cs-section-title">Select calls to update</div>
          <div id="cs-mcl-list">
            ${rows || `<div class="cs-mcl-empty">No existing calls found for this page.</div>`}
          </div>
        </div>
      </div>
      <div class="cs-mcl-footer">
        <button type="button" class="cs-btn-primary" id="cs-mcl-edit-btn" disabled>
          Edit 0 selected
        </button>
        <button type="button" class="cs-btn-secondary" id="cs-mcl-cancel-btn">Cancel</button>
      </div>
    `;

    ns.openPanel();

    const editBtn = ns.qs("#cs-mcl-edit-btn");

    function refreshEditBtn() {
      const n = ns.qs("#cs-panel-body").querySelectorAll(".cs-mcl-cb:checked").length;
      editBtn.disabled  = n === 0;
      editBtn.textContent = n ? `Edit ${n} selected ↓` : "Edit 0 selected";
    }

    ns.qs("#cs-panel-body").addEventListener("change", refreshEditBtn);
    refreshEditBtn();

    ns.qs("#cs-mcl-cancel-btn").addEventListener("click", () => ns.closePanel());

    editBtn.addEventListener("click", () => {
      const checkedIds = [...ns.qs("#cs-panel-body").querySelectorAll(".cs-mcl-cb:checked")]
        .map((cb) => cb.value);
      const selected = checkedIds.map((id) => calls.find((c) => c.id === id)).filter(Boolean);
      if (!selected.length) return;

      matchState.set(sourceKey, {
        callIds: selected.map((c) => c.id),
        callId: selected[0].id,
        callTitle: selected[0].title,
        ownerLabel: selected[0].ownerLabel,
      });
      const matchBtn = cat.querySelector(".cs-match-btn");
      if (matchBtn) {
        matchBtn.textContent = "Linked";
        matchBtn.classList.add("cs-match-btn--linked");
        updateAddDateButton(matchBtn, selected, sourcePayload);
      }

      openCallEditorPanel(cat, sourceKey, sourcePayload, selected, calls);
    });
  }

  // ── Screen 2: multi-call merge editor ────────────────────────────────────────

  function openCallEditorPanel(cat, sourceKey, sourcePayload, selectedCalls, allCalls) {
    preparePanel();

    const incomingTitle = sourcePayload.title || "";
    const incomingLink  = sourcePayload.callUrl || "";

    // Pull parsed description from draft cache if user already ran Add on this call
    const draftKey = typeof ns.getCallDraftKey === "function"
      ? ns.getCallDraftKey(sourcePayload.callUrl)
      : null;
    const draftCached = draftKey ? ns.state.draftCacheByCall?.get(draftKey) : null;
    const parsedDesc = draftCached?.previews?.[0]?.description
      ? stripHtml(draftCached.previews[0].description)
      : "";

    const cards = selectedCalls.map((call) => {
      const isOpen    = call.temporalState?.state === "open";
      const dbTitle   = call.title || "";
      const dbDesc    = stripHtml(call.description);
      const dbLink    = call.link || "";
      const id        = call.id;

      // All subWindows from DB, normalised to YYYY-MM-DD
      const subWindows = Array.isArray(call.readingPeriod?.subWindows)
        ? call.readingPeriod.subWindows.map((w) => ({
            openDate:  extractDateStr(w.openDate),
            closeDate: extractDateStr(w.closeDate),
          }))
        : [];
      const latestWindow = subWindows.length ? subWindows[subWindows.length - 1] : null;

      const titleConflict = normalizeTitle(incomingTitle) !== normalizeTitle(dbTitle) && incomingTitle;
      const linkConflict  = normalizeUrl(incomingLink)    !== normalizeUrl(dbLink)    && incomingLink;

      // ── Title ──────────────────────────────────────────────────────────────
      const titleHtml = titleConflict ? `
        <div class="cs-me-field">
          <div class="cs-me-field-label">Title</div>
          <div class="cs-me-conflict">
            <label class="cs-me-option">
              <input type="radio" name="cs-me-title-${id}" class="cs-me-title-radio" value="db"
                     data-title="${ns.escHtml(dbTitle)}" checked>
              <span class="cs-me-side cs-me-side--db">DB</span>
              <span class="cs-me-value">${diffHtml(incomingTitle, dbTitle)}</span>
            </label>
            <label class="cs-me-option">
              <input type="radio" name="cs-me-title-${id}" class="cs-me-title-radio" value="incoming"
                     data-title="${ns.escHtml(incomingTitle)}">
              <span class="cs-me-side cs-me-side--new">New</span>
              <span class="cs-me-value">${diffHtml(dbTitle, incomingTitle)}</span>
            </label>
          </div>
          <input type="text" class="cs-input cs-me-title-edit" id="cs-me-title-edit-${id}"
                 value="${ns.escHtml(dbTitle)}">
        </div>` : `
        <div class="cs-me-field">
          <div class="cs-me-field-label">Title</div>
          <input type="text" class="cs-input cs-me-title-edit" id="cs-me-title-edit-${id}"
                 value="${ns.escHtml(dbTitle)}">
        </div>`;

      // ── Description ────────────────────────────────────────────────────────
      const descPreview = dbDesc.length > 200 ? dbDesc.slice(0, 200) + "…" : dbDesc;
      const descHtml = `
        <div class="cs-me-field">
          <div class="cs-me-field-label">Description</div>
          <div class="cs-me-conflict">
            <label class="cs-me-option cs-me-option--top">
              <input type="radio" name="cs-me-desc-${id}" class="cs-me-desc-radio" value="db"
                     ${parsedDesc ? "" : "checked"}>
              <span class="cs-me-side cs-me-side--db">DB</span>
              <span class="cs-me-value cs-me-value--desc">${ns.escHtml(descPreview)}</span>
            </label>
            <label class="cs-me-option cs-me-option--textarea">
              <input type="radio" name="cs-me-desc-${id}" class="cs-me-desc-radio" value="new"
                     ${parsedDesc ? "checked" : ""}>
              <span class="cs-me-side cs-me-side--new">New</span>
              <textarea class="cs-textarea cs-me-desc-ta" data-call-id="${ns.escHtml(id)}"
                        placeholder="Paste new description…">${ns.escHtml(parsedDesc)}</textarea>
            </label>
          </div>
        </div>`;

      // ── Link ───────────────────────────────────────────────────────────────
      const linkHtml = linkConflict ? `
        <div class="cs-me-field">
          <div class="cs-me-field-label">Call URI</div>
          <div class="cs-me-conflict">
            <label class="cs-me-option">
              <input type="radio" name="cs-me-link-${id}" value="db">
              <span class="cs-me-side cs-me-side--db">DB</span>
              <code class="cs-me-value cs-me-value--code">${diffHtml(incomingLink, dbLink)}</code>
            </label>
            <label class="cs-me-option">
              <input type="radio" name="cs-me-link-${id}" value="incoming" checked>
              <span class="cs-me-side cs-me-side--new">New</span>
              <code class="cs-me-value cs-me-value--code">${diffHtml(dbLink, incomingLink)}</code>
            </label>
          </div>
        </div>` : `
        <div class="cs-me-field">
          <div class="cs-me-field-label">Call URI <span class="cs-me-same">unchanged</span></div>
          <code class="cs-me-value cs-me-value--code cs-me-value--plain">${ns.escHtml(dbLink || incomingLink)}</code>
        </div>`;

      return `
        <div class="cs-me-card" data-call-id="${ns.escHtml(id)}">
          <div class="cs-me-card-head">
            <span class="cs-me-card-name">${ns.escHtml(dbTitle || "Untitled")}</span>
            <span class="cs-mcl-variant">${ns.escHtml(getCallVariantLabel(call))}</span>
            <span class="cs-match-status ${isOpen ? "cs-match-status--open" : "cs-match-status--closed"}">
              ${isOpen ? "open" : (call.temporalState?.state || "closed")}
            </span>
          </div>
          ${titleHtml}
          ${descHtml}
          ${linkHtml}
          <div class="cs-me-field">
            <div class="cs-me-field-label">Reading windows</div>

            ${subWindows.length ? `
            <div class="cs-me-windows-list">
              ${subWindows.map((w, idx) => {
                const isLatest = idx === subWindows.length - 1;
                const range = [
                  w.openDate  ? formatDisplayDate(w.openDate)  : null,
                  w.closeDate ? formatDisplayDate(w.closeDate) : null,
                ].filter(Boolean).join(" – ") || "No dates set";
                return `<div class="cs-me-window-item${isLatest ? " cs-me-window-item--latest" : ""}">
                  <span class="cs-me-window-n">${idx + 1}</span>
                  <span class="cs-me-window-range">${ns.escHtml(range)}</span>
                  ${isLatest ? `<span class="cs-me-window-tag">latest</span>` : ""}
                </div>`;
              }).join("")}
            </div>` : `<div class="cs-me-window-empty">No reading windows in DB</div>`}

            <div class="cs-me-date-actions">
              <label class="cs-me-date-action">
                <input type="radio" name="cs-me-date-act-${id}" class="cs-me-date-radio"
                       value="none" checked> No change
              </label>
              ${subWindows.map((w, idx) => `
              <label class="cs-me-date-action">
                <input type="radio" name="cs-me-date-act-${id}" class="cs-me-date-radio"
                       value="edit-index-${idx}"
                       data-open="${ns.escHtml(w.openDate)}"
                       data-close="${ns.escHtml(w.closeDate)}">
                Edit window ${idx + 1}${idx === subWindows.length - 1 ? " (latest)" : ""}
              </label>`).join("")}
              <label class="cs-me-date-action">
                <input type="radio" name="cs-me-date-act-${id}" class="cs-me-date-radio"
                       value="add" data-open="" data-close=""> Add new window
              </label>
            </div>

            <div class="cs-me-date-inputs cs-me-date-inputs--hidden" id="cs-me-date-inputs-${id}">
              <div class="cs-match-date-row">
                <div class="cs-field-group--half">
                  <label class="cs-label" for="cs-me-open-${id}">Open date</label>
                  <input class="cs-input" id="cs-me-open-${id}" type="date" value="">
                </div>
                <div class="cs-field-group--half">
                  <label class="cs-label" for="cs-me-close-${id}">Close date</label>
                  <input class="cs-input" id="cs-me-close-${id}" type="date" value="">
                </div>
              </div>
            </div>
          </div>
        </div>`;
    }).join("");

    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-match-editor-header">
        <button type="button" class="cs-match-back-btn" id="cs-match-back-btn">← All calls</button>
        <span class="cs-match-editor-name">
          ${selectedCalls.length} call${selectedCalls.length !== 1 ? "s" : ""} selected
        </span>
      </div>
      <div class="cs-editor-body cs-me-body">
        ${cards}
        <div class="cs-match-panel-footer">
          <button type="button" class="cs-btn-primary" id="cs-me-save-btn">
            Save ${selectedCalls.length} call${selectedCalls.length !== 1 ? "s" : ""}
          </button>
          <button type="button" class="cs-btn-secondary" id="cs-me-unlink-btn">Unlink</button>
        </div>
      </div>
    `;

    ns.openPanel();

    // Show/hide date inputs and pre-fill when a date action radio changes
    ns.qs("#cs-panel-body").querySelectorAll(".cs-me-date-radio").forEach((radio) => {
      radio.addEventListener("change", () => {
        if (!radio.checked) return;
        const callId    = radio.name.replace("cs-me-date-act-", "");
        const inputsEl  = document.getElementById(`cs-me-date-inputs-${callId}`);
        const openInput = document.getElementById(`cs-me-open-${callId}`);
        const closeInput = document.getElementById(`cs-me-close-${callId}`);
        if (!inputsEl) return;

        if (radio.value === "none") {
          inputsEl.classList.add("cs-me-date-inputs--hidden");
        } else {
          inputsEl.classList.remove("cs-me-date-inputs--hidden");
          // Pre-fill with the window's existing dates (from data-* on the radio)
          if (openInput)  openInput.value  = radio.dataset.open  || "";
          if (closeInput) closeInput.value = radio.dataset.close || "";
        }
      });
    });

    // Sync title edit input when title conflict radio changes
    ns.qs("#cs-panel-body").querySelectorAll(".cs-me-title-radio").forEach((radio) => {
      radio.addEventListener("change", () => {
        if (!radio.checked) return;
        const callId = radio.name.replace("cs-me-title-", "");
        const input = document.getElementById(`cs-me-title-edit-${callId}`);
        if (input) input.value = radio.dataset.title || "";
      });
    });

    // Auto-select "New" radio when the description textarea gets content
    ns.qs("#cs-panel-body").querySelectorAll(".cs-me-desc-ta").forEach((ta) => {
      const callId = ta.dataset.callId;
      ta.addEventListener("input", () => {
        if (ta.value.trim()) {
          const radio = ns.qs(`input[name="cs-me-desc-${callId}"][value="new"]`);
          if (radio) radio.checked = true;
        }
      });
      ta.addEventListener("focus", () => {
        const radio = ns.qs(`input[name="cs-me-desc-${callId}"][value="new"]`);
        if (radio) radio.checked = true;
      });
    });

    ns.qs("#cs-match-back-btn").addEventListener("click", () => {
      openCallListPanel(cat, sourceKey, sourcePayload, allCalls);
    });

    ns.qs("#cs-me-unlink-btn").addEventListener("click", () => {
      matchState.delete(sourceKey);
      const btn = cat.querySelector(".cs-match-btn");
      if (btn) { btn.textContent = "Match"; btn.classList.remove("cs-match-btn--linked"); }
      clearAddDateButton(cat);
      ns.closePanel();
    });

    ns.qs("#cs-me-save-btn").addEventListener("click", async () => {
      await saveAllEdits(selectedCalls, incomingTitle, incomingLink);
    });
  }

  // ── Save ──────────────────────────────────────────────────────────────────────

  async function saveAllEdits(selectedCalls, incomingTitle, incomingLink) {
    const saveBtn = ns.qs("#cs-me-save-btn");
    if (!saveBtn) return;
    saveBtn.disabled = true;
    saveBtn.textContent = "Saving…";

    const errors = [];

    await Promise.all(selectedCalls.map(async (call) => {
      const id            = call.id;
      const dbTitle = call.title || "";
      const dbLink  = call.link  || "";
      const dbDesc  = stripHtml(call.description);

      // Title — read from the editable input (pre-filled from radio, then user-editable)
      const titleInput  = document.getElementById(`cs-me-title-edit-${id}`);
      const chosenTitle = titleInput ? titleInput.value.trim() : dbTitle;

      // Description
      const descRadio = document.querySelector(`input[name="cs-me-desc-${id}"]:checked`);
      const descTa    = document.querySelector(`.cs-me-desc-ta[data-call-id="${id}"]`);
      const chosenDesc = descRadio?.value === "new"
        ? (descTa?.value || "").trim()
        : dbDesc;

      // Link
      const linkRadio  = document.querySelector(`input[name="cs-me-link-${id}"]:checked`);
      const chosenLink = linkRadio?.value === "incoming" ? incomingLink : dbLink;

      // Dates
      const newOpen  = document.getElementById(`cs-me-open-${id}`)?.value  || "";
      const newClose = document.getElementById(`cs-me-close-${id}`)?.value || "";

      // Scalar patch
      const scalarPatch = {};
      if (chosenTitle !== dbTitle) scalarPatch.title = chosenTitle;
      if (chosenDesc  !== dbDesc)  scalarPatch.description = chosenDesc;
      if (chosenLink  !== dbLink)  scalarPatch.link = chosenLink;

      if (Object.keys(scalarPatch).length) {
        try {
          const res = await fetch(
            `${ns.API_BASE}/extension/calls/${encodeURIComponent(id)}/match-update`,
            {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(scalarPatch),
            },
          );
          if (!res.ok) {
            const d = await res.json().catch(() => ({}));
            errors.push(`"${call.title}": ${d.error || res.status}`);
          }
        } catch (err) {
          errors.push(`"${call.title}": ${err.message}`);
        }
      }

      // Date patch
      const dateActionRadio = document.querySelector(
        `input[name="cs-me-date-act-${id}"]:checked`,
      );
      const dateAction = dateActionRadio?.value || "none";

      if (dateAction !== "none") {
        const newOpen  = document.getElementById(`cs-me-open-${id}`)?.value  || "";
        const newClose = document.getElementById(`cs-me-close-${id}`)?.value || "";

        if (newOpen || newClose) {
          const body = {
            callIds:   [id],
            openDate:  newOpen  || null,
            closeDate: newClose || null,
            action:    "add",
          };

          if (dateAction === "add") {
            body.action = "add";
          } else if (dateAction.startsWith("edit-index-")) {
            body.action      = "edit-index";
            body.windowIndex = parseInt(dateAction.replace("edit-index-", ""), 10);
          }

          try {
            const res = await fetch(`${ns.API_BASE}/extension/call-window`, {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body),
            });
            if (!res.ok) {
              const d = await res.json().catch(() => ({}));
              errors.push(`"${call.title}" dates: ${d.error || res.status}`);
            }
          } catch (err) {
            errors.push(`"${call.title}" dates: ${err.message}`);
          }
        }
      }
    }));

    if (errors.length) {
      saveBtn.disabled = false;
      saveBtn.textContent = `Save ${selectedCalls.length} call${selectedCalls.length !== 1 ? "s" : ""}`;
      const errEl = ns.el("div", "cs-match-save-error");
      errEl.textContent = errors.join(" · ");
      ns.qs(".cs-match-panel-footer")?.prepend(errEl);
      return;
    }

    callsCache = null;
    ns.clearDuosumaCallsCache?.();

    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-success">
        <div class="cs-success-icon">✓</div>
        <div class="cs-success-title">Saved</div>
        <div class="cs-success-detail">
          ${selectedCalls.length} call${selectedCalls.length !== 1 ? "s" : ""} updated successfully.
        </div>
      </div>
    `;
    setTimeout(() => ns.closePanel(), 2500);
  }

  // ── Hook into injection cycle ─────────────────────────────────────────────────

  const _origInjectAddButtons = ns.injectAddButtons;
  ns.injectAddButtons = function injectAddButtons() {
    _origInjectAddButtons.call(ns);
    ns.injectMatchButtons();
  };

})();
