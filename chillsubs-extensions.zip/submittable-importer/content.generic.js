(() => {
  const ns = window.ChillSubsExt;

  // ── Inject "Parse Calls" button into the existing calls drawer ─────────────
  ns.initGenericPage = function initGenericPage() {
    // Wait for drawer to exist (ensureExistingCallsDrawer already ran in observe)
    const drawer = document.getElementById("cs-existing-drawer");
    if (!drawer || drawer.querySelector("#cs-generic-parse-btn")) return;

    const defaultBtns = drawer.querySelector(".cs-header-default-btns");
    if (!defaultBtns) return;

    const parseBtn = ns.el("button", "cs-existing-close cs-generic-parse-btn");
    parseBtn.id = "cs-generic-parse-btn";
    parseBtn.type = "button";
    parseBtn.textContent = "Parse Calls";

    defaultBtns.insertBefore(parseBtn, defaultBtns.firstChild);
    parseBtn.addEventListener("click", ns.handleGenericParse);
  };

  // Pages under this character count are sent in full; larger pages require a selection.
  const PAGE_TEXT_LIMIT = 15000;

  // ── Main trigger ────────────────────────────────────────────────────────────
  ns.handleGenericParse = function handleGenericParse() {
    const selectedText = window.getSelection?.()?.toString?.()?.trim?.() ?? "";
    const pageText = (document.body?.innerText ?? "").trim();

    ns.ensurePanel();
    ns.openPanel();

    if (selectedText) {
      ns.fetchAndRenderGenericParse({
        pageText: selectedText,
        pageUrl: window.location.href,
        pageTitle: document.title,
      });
      return;
    }

    if (pageText.length <= PAGE_TEXT_LIMIT) {
      ns.fetchAndRenderGenericParse({
        pageText,
        pageUrl: window.location.href,
        pageTitle: document.title,
      });
      return;
    }

    ns.renderGenericNoSelection();
  };

  // ── "No selection" panel state (shown only when page is too long) ───────────
  ns.renderGenericNoSelection = function renderGenericNoSelection() {
    ns.qs("#cs-panel-footer").style.display = "none";
    ns.qs("#cs-panel-body").innerHTML = `
      <div class="cs-generic-no-selection">
        <div class="cs-generic-no-selection-icon">
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
            <rect x="4" y="8" width="24" height="3" rx="1.5" fill="currentColor" opacity=".25"/>
            <rect x="4" y="14" width="18" height="3" rx="1.5" fill="currentColor" opacity=".25"/>
            <rect x="4" y="20" width="22" height="3" rx="1.5" fill="currentColor" opacity=".25"/>
            <rect x="12" y="12" width="14" height="10" rx="2" fill="currentColor" opacity=".18" stroke="currentColor" stroke-width="1.5"/>
          </svg>
        </div>
        <div class="cs-generic-no-selection-title">Page too long — select text first</div>
        <div class="cs-generic-no-selection-detail">
          This page has too much text to send in full.
          Highlight just the submission guidelines,
          then click <strong>Parse Calls</strong> again.
        </div>
      </div>
    `;
  };

  // ── Fetch + render ──────────────────────────────────────────────────────────
  ns.fetchAndRenderGenericParse = async function fetchAndRenderGenericParse(payload) {
    ns.renderLoading("Extracting calls with AI…");

    try {
      const res = await fetch(`${ns.API_BASE}/extension/generic-parse`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok) {
        ns.renderError(data.error ?? "Extraction failed.", data.detail ?? "");
        return;
      }

      // Use page URL as the draft cache key for generic pages
      const sourceKey = `generic:${payload.pageUrl}`;
      const sourcePayload = { ...payload, provider: "generic" };

      ns.renderEditor(
        data.previews,
        data.magazineId,
        data.magazineName,
        sourcePayload,
        sourceKey,
        data.ownerCandidates,
        data.selectedOwner,
        data.parseToken,
      );
      ns.saveActiveDraft();
    } catch {
      ns.renderError("Could not reach ChillSubs backend.", "Is the server running on localhost:3001?");
    }
  };
})();
