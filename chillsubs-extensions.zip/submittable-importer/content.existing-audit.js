(() => {
  const ns = window.ChillSubsExt;

  // Returns the toggle button HTML (shown inline next to the owner name)
  ns.getOwnerAuditHtml = function getOwnerAuditHtml(owner) {
    const ownerType = String(owner?.type || "").trim().toLowerCase();
    if (!owner?.id || ownerType === "organisation") return "";
    const ownerId = ns.escHtml(String(owner.id));
    const ownerTypeEsc = ns.escHtml(ownerType);
    return `<button class="cs-existing-owner-audit-btn" type="button" data-owner-id="${ownerId}" data-owner-type="${ownerTypeEsc}">Guidelines</button>`;
  };

  // Returns the collapsible panel placeholder that sits below the title row
  ns.getOwnerAuditPanelHtml = function getOwnerAuditPanelHtml(owner) {
    const ownerType = String(owner?.type || "").trim().toLowerCase();
    if (!owner?.id || ownerType === "organisation") return "";
    const ownerId = ns.escHtml(String(owner.id));
    return `<div class="cs-existing-audit-panel" id="cs-audit-${ownerId}" hidden></div>`;
  };

  // ── Rendering ────────────────────────────────────────────────────────────────

  function row(label, value) {
    return `<div class="cs-audit-row"><span class="cs-audit-label">${ns.escHtml(label)}</span><span class="cs-audit-val">${value}</span></div>`;
  }

  function linkRow(label, url) {
    return `<div class="cs-audit-row"><span class="cs-audit-label">${ns.escHtml(label)}</span><a class="cs-audit-link" href="${ns.escHtml(url)}" target="_blank" rel="noopener noreferrer">${ns.escHtml(url)}</a></div>`;
  }

  function boolVal(val) {
    return val ? "yes" : "no";
  }

  function formatStatsResponseTime(rt) {
    if (!rt) return null;
    const num = rt.time?.maximumNumber;
    const unit = rt.time?.unitOfTime || "days";
    if (num == null) return null;
    const timing = rt.type?.afterDeadline ? " after deadline"
      : rt.type?.afterSubmission ? " after submission"
      : "";
    return `${num} ${unit}${timing}`;
  }

  function renderAuditInfo(panel, data) {
    const { audit } = data;
    const subs = audit?.guidelines?.submissions || {};
    const parts = [];

    if (subs.submissionMethod?.length) {
      parts.push(row("Method", ns.escHtml(subs.submissionMethod.join(", "))));
    }
    if (audit.submissionMethod) {
      parts.push(row("Sub. method", ns.escHtml(audit.submissionMethod)));
    }
    if (subs.submissionMethodAddress) {
      parts.push(linkRow("Sub. address", subs.submissionMethodAddress));
    }
    if (subs.guidelinesLink) {
      parts.push(linkRow("Guidelines link", subs.guidelinesLink));
    }
    if (audit.guidelinesLink) {
      parts.push(linkRow("Guidelines link (top)", audit.guidelinesLink));
    }
    if (subs.lookingFor) {
      parts.push(row("Looking for", ns.escHtml(subs.lookingFor)));
    }
    if (audit.howToSubmit) {
      parts.push(row("How to submit", ns.escHtml(audit.howToSubmit)));
    }
    if (subs.acceptsMultipleSubmissions != null) {
      parts.push(row("Multiple submissions", boolVal(subs.acceptsMultipleSubmissions)));
    }
    if (subs.acceptsSimultaneousSubmissions != null) {
      parts.push(row("Simultaneous", boolVal(subs.acceptsSimultaneousSubmissions)));
    } else if (audit.simultaneousSubmissions != null) {
      parts.push(row("Simultaneous", boolVal(audit.simultaneousSubmissions)));
    }
    if (subs.acceptsTranslations != null) {
      parts.push(row("Translations", boolVal(subs.acceptsTranslations)));
    }
    if (subs.aiPolicy?.hasThis != null) {
      const ai = subs.aiPolicy;
      const aiText = boolVal(ai.hasThis) + (ai.comments ? ` — ${ns.escHtml(ai.comments)}` : "");
      parts.push(row("AI policy", aiText));
    }
    if (audit.acceptPreviouslyPublished != null) {
      parts.push(row("Prev. published", boolVal(audit.acceptPreviouslyPublished)));
    }
    if (audit.previouslyPublishedLimitations) {
      parts.push(row("Prev. pub. limits", ns.escHtml(audit.previouslyPublishedLimitations)));
    }
    if (audit.readingBlind != null) {
      parts.push(row("Blind reading", boolVal(audit.readingBlind)));
    }
    if (audit.eligibilityDetails) {
      parts.push(row("Eligibility", ns.escHtml(audit.eligibilityDetails)));
    }
    if (audit.rights) {
      parts.push(row("Rights", ns.escHtml(audit.rights)));
    }
    if (audit.coverLetterAndBio) {
      parts.push(row("Cover letter", ns.escHtml(audit.coverLetterAndBio)));
    }
    if (audit.formattingRequirements) {
      parts.push(row("Formatting", ns.escHtml(audit.formattingRequirements)));
    }
    if (audit.responseTime) {
      const rVal = audit.responseTime + (audit.responseDays ? ` (${audit.responseDays}d)` : "");
      parts.push(row("Response time", ns.escHtml(rVal)));
    }
    const statsRt = formatStatsResponseTime(audit.stats?.responseTime);
    if (statsRt) {
      parts.push(row("Response time (stats)", ns.escHtml(statsRt)));
    }
    if (audit.reviewStatus) {
      parts.push(row("Review status", ns.escHtml(audit.reviewStatus)));
    }
    if (audit.fullAuditDate) {
      parts.push(row("Last audit", ns.escHtml(new Date(audit.fullAuditDate).toLocaleDateString())));
    }

    if (!parts.length) {
      panel.innerHTML = `<div class="cs-audit-empty">No guidelines data found.</div>`;
      return;
    }
    panel.innerHTML = `<div class="cs-audit-content">${parts.join("")}</div>`;
  }

  // ── Delegated click handler ──────────────────────────────────────────────────

  document.body.addEventListener("click", async (e) => {
    const btn = e.target.closest(".cs-existing-owner-audit-btn");
    if (!btn) return;

    const ownerId = btn.dataset.ownerId;
    const ownerType = btn.dataset.ownerType;
    if (!ownerId || !ownerType) return;

    const panel = document.getElementById(`cs-audit-${ownerId}`);
    if (!panel) return;

    // Toggle closed
    if (!panel.hidden) {
      panel.hidden = true;
      btn.classList.remove("cs-existing-owner-audit-btn--open");
      return;
    }

    // Already fetched — just show
    if (panel.dataset.loaded === "1") {
      panel.hidden = false;
      btn.classList.add("cs-existing-owner-audit-btn--open");
      return;
    }

    // Fetch from backend
    btn.disabled = true;
    btn.textContent = "Loading…";
    try {
      const res = await fetch(
        `${ns.API_BASE}/extension/audit?ownerId=${encodeURIComponent(ownerId)}&ownerType=${encodeURIComponent(ownerType)}`
      );
      const data = await res.json();
      if (!res.ok) {
        panel.innerHTML = `<div class="cs-audit-empty">${ns.escHtml(data.error || "Failed to load guidelines.")}</div>`;
      } else {
        renderAuditInfo(panel, data);
        panel.dataset.loaded = "1";
      }
    } catch (err) {
      panel.innerHTML = `<div class="cs-audit-empty">Error: ${ns.escHtml(err?.message || String(err))}</div>`;
    } finally {
      btn.disabled = false;
      btn.textContent = "Guidelines";
      panel.hidden = false;
      btn.classList.add("cs-existing-owner-audit-btn--open");
    }
  });
})();
