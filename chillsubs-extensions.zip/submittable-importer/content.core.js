(() => {
  const ns = (window.ChillSubsExt = window.ChillSubsExt || {});

  ns.API_BASE = "https://submit.chillsubs.com";
  // ns.API_BASE = "http://localhost:3001";
  ns.DEV_API_BASE = "http://localhost:3001";
  ns.DROPDOWN_OPTIONS = window.CALL_DROPDOWN_OPTIONS || {};
  ns.CONTEST_TITLE_PATTERN = /\b(contest|prize|award|competition)\b/i;
  ns.GENERIC_BOOK_PATTERN = /\b(book|manuscript)\b/i;
  ns.BOOK_TITLE_MATCHERS = [
    { pattern: /\bessay collection\b/i, type: "essay_collection" },
    { pattern: /\bfull[\s-]*length book\b/i, type: "full_length_book" },
    { pattern: /\bnovelette\b/i, type: "novelette" },
    { pattern: /\bnovella\b/i, type: "novella" },
    { pattern: /\bnovel\b/i, type: "novel" },
    { pattern: /\bchapbook\b/i, type: "chapbook" },
    { pattern: /\bcollection\b/i, type: "collection" },
  ];
  ns.TYPE_OPTIONS_BY_GENRE = ns.DROPDOWN_OPTIONS.TYPE_OPTIONS_BY_GENRE || {
    fiction: ["shortFiction"],
    nonfiction: ["shortNonfiction"],
    poetry: ["general", "bookLengthPoetry", "poetryContest", "bookLengthPoetryContest"],
    hybrid: ["hybrid", "hybridContest"],
    multimedia: ["general", "bookLengthMultimedia", "multimediaContest"],
    general: ["general", "contest", "bookLength", "bookLengthContest", "anthology", "pitch"],
  };
  ns.SUBGENRE_OPTIONS_BY_GENRE = {
    fiction: ns.DROPDOWN_OPTIONS.FICTION_SUBGENRES || [],
    nonfiction: ns.DROPDOWN_OPTIONS.NONFICTION_SUBGENRES || [],
    poetry: ns.DROPDOWN_OPTIONS.POETRY_FORMS || [],
    hybrid: Array.from(
      new Set([
        ...(ns.DROPDOWN_OPTIONS.FICTION_SUBGENRES || []),
        ...(ns.DROPDOWN_OPTIONS.NONFICTION_SUBGENRES || []),
        ...(ns.DROPDOWN_OPTIONS.POETRY_FORMS || []),
      ]),
    ),
    multimedia: ns.DROPDOWN_OPTIONS.MULTIMEDIA_CATEGORIES || [],
  };
  ns.STYLE_OPTIONS_BY_GENRE = ns.DROPDOWN_OPTIONS.STYLE_OPTIONS_BY_GENRE || {
    fiction: ["shortStory", "flash", "micro", "longRead", "script", "other"],
    nonfiction: ["essay", "flash", "micro", "longRead", "script", "other"],
    poetry: [],
    hybrid: ["essay", "micro", "flash", "longRead", "other"],
    multimedia: [],
    general: ["general", "flash", "micro", "essay", "longRead", "other"],
  };
  ns.BOOK_STYLE_OPTIONS = ns.DROPDOWN_OPTIONS.BOOK_STYLE_OPTIONS || ["novel", "novella", "novelette", "collection", "chapbook", "full_length_book", "essay_collection"];
  ns.STATUS_OPTIONS = ["open", "closed", "archived"];

  // Mirrors the backend's isBookLengthCall()/BOOK_LENGTH_TYPE_PATTERN (submissionCall/inference.js):
  // a book-length call's genreStyle holds a book type (novel/novella/...), not a short-form style.
  ns.isBookLengthType = function isBookLengthType(type) {
    const t = String(type || "").trim();
    if (!t) return false;
    if (/^bookLength/i.test(t)) return true;
    return (ns.BOOK_STYLE_OPTIONS || []).includes(t);
  };

  ns.state = {
    panelEl: null,
    overlayEl: null,
    activeData: null,
    draftCacheByCall: new Map(),
    availableCallSources: new Map(),
    selectedCallKeys: new Set(),
    batchToolbarEl: null,
  };

  ns.el = function el(tag, cls, html = "") {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html) e.innerHTML = html;
    return e;
  };

  ns.qs = function qs(sel, root = document) {
    return root.querySelector(sel);
  };

  ns.isSubmittableHost = function isSubmittableHost(host = window.location.host) {
    return /\.submittable\.com$/i.test(String(host || ""));
  };

  ns.isDuosumaPage = function isDuosumaPage(url = window.location.href) {
    try {
      const parsed = new URL(url, window.location.href);
      return /(^|\.)duotrope\.com$/i.test(parsed.host) && /\/duosuma\//i.test(parsed.pathname);
    } catch {
      return false;
    }
  };

  ns.getParseEndpoint = function getParseEndpoint(sourcePayload = null) {
    if (sourcePayload?.provider === "duosuma") return `${ns.API_BASE}/extension/duosuma/parse`;
    if (sourcePayload?.provider === "generic") return `${ns.API_BASE}/extension/generic-parse`;
    return `${ns.API_BASE}/extension/parse`;
  };

  ns.escHtml = function escHtml(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;");
  };

  ns.setDeep = function setDeep(obj, parts, value) {
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i += 1) {
      if (cur[parts[i]] == null) cur[parts[i]] = {};
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = value;
  };

  // Union of readingPeriod.callPeriod flags across one or more calls (e.g. a bulk selection).
  ns.getCallPeriodFlags = function getCallPeriodFlags(calls) {
    const list = Array.isArray(calls) ? calls : [calls];
    const flags = { alwaysOpen: false, limited: false, recurring: false, unconfirmed: false };
    for (const call of list) {
      const cp = call?.readingPeriod?.callPeriod || {};
      if (cp.alwaysOpen) flags.alwaysOpen = true;
      if (cp.limited) flags.limited = true;
      if (cp.recurring) flags.recurring = true;
      if (cp.unconfirmed) flags.unconfirmed = true;
    }
    return flags;
  };

  // Returns readingPeriod.subWindows only when identical across all given calls (null otherwise) —
  // per-window edit-index only makes sense when the selection shares one set of windows.
  ns.getSharedSubWindows = function getSharedSubWindows(calls) {
    const list = Array.isArray(calls) ? calls : [calls];
    const normalized = list.map((call) =>
      Array.isArray(call?.readingPeriod?.subWindows)
        ? call.readingPeriod.subWindows.map((w) => ({ openDate: w.openDate || null, closeDate: w.closeDate || null }))
        : [],
    );
    const serialized = normalized.map((w) => JSON.stringify(w));
    const allSame = serialized.every((s) => s === serialized[0]);
    return allSame ? normalized[0] : null;
  };

  ns.extractSubmittableCallId = function extractSubmittableCallId(callUrl) {
    const raw = String(callUrl || "").trim();
    if (!raw) return "";

    try {
      const parsed = new URL(raw, location.href);
      const matchedPath = parsed.pathname.match(/\/submit\/(\d+)/i);
      if (matchedPath?.[1]) return matchedPath[1];
    } catch {
      // Fall back to a raw string match below.
    }

    return raw.match(/\/submit\/(\d+)/i)?.[1] || "";
  };

  ns.getCallDraftKey = function getCallDraftKey(callUrl) {
    const raw = String(callUrl || "").trim();
    if (!raw) return "";

    const callId = ns.extractSubmittableCallId(raw);
    if (callId) {
      try {
        const parsed = new URL(raw, location.href);
        return `${parsed.origin}/submit/${callId}`;
      } catch {
        return `/submit/${callId}`;
      }
    }

    try {
      return new URL(raw, location.href).toString();
    } catch {
      return raw;
    }
  };

  ns.openSourcePayload = async function openSourcePayload(sourcePayload, loadingMessage = "Parsing call...") {
    const fallbackOrigin = `${location.protocol}//${location.host}`;
    const normalizedSourcePayload = {
      ...(sourcePayload || {}),
      callUrl: sourcePayload?.callUrl || location.href,
      mainUrl: sourcePayload?.mainUrl || (typeof ns.getMainUrl === "function" ? ns.getMainUrl() : fallbackOrigin),
    };
    const sourceKey = ns.getCallDraftKey(normalizedSourcePayload.callUrl);

    ns.ensurePanel();
    ns.openPanel();

    const cached = ns.state.draftCacheByCall.get(sourceKey);
    if (cached) {
      ns.renderEditor(
        cached.previews,
        cached.magazineId,
        cached.magazineName,
        normalizedSourcePayload,
        sourceKey,
        cached.ownerCandidates,
        cached.selectedOwner,
        cached.parseToken,
      );
      return;
    }

    await ns.fetchAndRenderParse(normalizedSourcePayload, sourceKey, loadingMessage);
  };

  ns.saveActiveDraft = function saveActiveDraft() {
    const { activeData, draftCacheByCall } = ns.state;
    if (!activeData?.sourceKey) return;
    draftCacheByCall.set(activeData.sourceKey, {
      previews: JSON.parse(JSON.stringify(activeData.previews || [])),
      magazineId: activeData.magazineId,
      magazineName: activeData.magazineName,
      ownerCandidates: JSON.parse(JSON.stringify(activeData.ownerCandidates || [])),
      selectedOwner: activeData.selectedOwner ? { ...activeData.selectedOwner } : null,
      parseToken: activeData.parseToken || null,
      sourcePayload: { ...(activeData.sourcePayload || {}) },
    });
  };

  ns.captureEditorScroll = function captureEditorScroll() {
    return {
      panelBody: ns.qs("#cs-panel-body")?.scrollTop ?? 0,
      editorBody: ns.qs("#cs-editor-body")?.scrollTop ?? 0,
    };
  };

  ns.restoreEditorScroll = function restoreEditorScroll(snapshot) {
    if (!snapshot) return;
    const panelBody = ns.qs("#cs-panel-body");
    const editorBody = ns.qs("#cs-editor-body");
    if (panelBody) panelBody.scrollTop = snapshot.panelBody ?? 0;
    if (editorBody) editorBody.scrollTop = snapshot.editorBody ?? 0;
  };

  ns.getEditorFocusTarget = function getEditorFocusTarget() {
    const active = document.activeElement;
    if (!active || !active.dataset) return null;

    if (active.dataset.field) {
      return { type: "field", value: active.dataset.field };
    }
    if (active.hasAttribute("data-style-genre")) {
      return { type: "style", value: active.getAttribute("data-style-genre") };
    }
    if (active.hasAttribute("data-subgenre-genre")) {
      return { type: "subgenre", value: active.getAttribute("data-subgenre-genre") };
    }
    return null;
  };

  ns.restoreEditorFocus = function restoreEditorFocus(target) {
    if (!target) return;

    let selector = null;
    if (target.type === "field") selector = `[data-field="${CSS.escape(target.value)}"]`;
    if (target.type === "style") selector = `[data-style-genre="${CSS.escape(target.value)}"]`;
    if (target.type === "subgenre") selector = `[data-subgenre-genre="${CSS.escape(target.value)}"]`;
    if (!selector) return;

    const next = ns.qs(selector, ns.qs("#cs-editor-body"));
    if (next && typeof next.focus === "function") {
      next.focus({ preventScroll: true });
    }
  };

  ns.rerenderTabPreservingScroll = function rerenderTabPreservingScroll(index) {
    const snapshot = ns.captureEditorScroll();
    const focusTarget = ns.getEditorFocusTarget();
    ns.renderTabEditor(index);
    ns.restoreEditorScroll(snapshot);
    ns.restoreEditorFocus(focusTarget);
  };

  ns.hasMeaningfulText = function hasMeaningfulText(value) {
    return Boolean(String(value ?? "").replace(/<[^>]*>/g, "").replace(/&nbsp;/g, " ").trim());
  };

  ns.getSelectedPreviewGenres = function getSelectedPreviewGenres(preview) {
    return Object.entries(preview?.genre || {})
      .filter(([, enabled]) => Boolean(enabled))
      .map(([genre]) => genre);
  };

  ns.getStyleOptionsForGenre = function getStyleOptionsForGenre(genre) {
    if (genre === "book") return ns.BOOK_STYLE_OPTIONS || [];
    return Array.isArray(ns.STYLE_OPTIONS_BY_GENRE?.[genre]) ? ns.STYLE_OPTIONS_BY_GENRE[genre] : [];
  };

  ns.inferTitleDrivenType = function inferTitleDrivenType(title) {
    const normalizedTitle = String(title || "").trim();
    if (!normalizedTitle) return { type: "general", bookType: null };

    if (ns.CONTEST_TITLE_PATTERN.test(normalizedTitle)) {
      return { type: "contest", bookType: null };
    }

    for (const matcher of ns.BOOK_TITLE_MATCHERS) {
      if (matcher.pattern.test(normalizedTitle)) {
        return { type: matcher.type, bookType: matcher.type };
      }
    }

    if (ns.GENERIC_BOOK_PATTERN.test(normalizedTitle)) {
      return { type: "chapbook", bookType: "chapbook" };
    }

    return { type: "general", bookType: null };
  };

  // Converts a call's callMetadata.variant enum (FLASH_FICTION, SHORT_FICTION_CONTEST,
  // BOOK_LENGTH_FICTION, ...) to the camelCase token the Type dropdown (TYPE_OPTIONS_BY_GENRE)
  // uses (flashFiction, shortFictionContest, bookLengthFiction, ...) so the Edit Genre panel
  // can preselect a call's current shape. POETRY/MULTIMEDIA's plain (non-book, non-contest)
  // variants have no camelCase counterpart of their own in TYPE_OPTIONS_BY_GENRE — those
  // genres use "general" for that case instead.
  const PLAIN_VARIANT_TO_TYPE_TOKEN = { POETRY: "general", MULTIMEDIA: "general" };
  ns.variantToTypeToken = function variantToTypeToken(variant) {
    const v = String(variant || "").trim().toUpperCase();
    if (!v) return null;
    if (PLAIN_VARIANT_TO_TYPE_TOKEN[v]) return PLAIN_VARIANT_TO_TYPE_TOKEN[v];
    return v.toLowerCase().replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
  };

  ns.typeRequiresGenreStyle = function typeRequiresGenreStyle(preview) {
    if (!preview) return false;
    const type = String(preview?.type || "").trim();
    if (!type || type === "pitch") return false;
    
    // Book-length types should show book style options
    const isBookType = /^(bookLength|bookLengthContest|bookLengthFiction|bookLengthFictionContest|bookLengthNonfiction|bookLengthNonfictionContest|bookLengthPoetry|bookLengthPoetryContest|bookLengthMultimedia)$/i.test(type);
    // const hasBookMetadata = Boolean(preview?.callMetadata?.bookType);
    if (isBookType) return true;
    
    return ns.getSelectedPreviewGenres(preview).some((genre) => ns.getStyleOptionsForGenre(genre).length > 0);
  };

  ns.normalizePaymentAmount = function normalizePaymentAmount(preview) {
    if (!preview.payment) preview.payment = {};
    if (!preview.payment.amount) preview.payment.amount = {};

    const amount = preview.payment.amount;
    const lower = amount.lower;
    const upper = amount.upper;

    amount.unspecified = Boolean(amount.unspecified);

    if (amount.exact == null) {
      amount.exact = upper == null || upper === "";
    }

    if (amount.unspecified) {
      amount.lower = null;
      amount.upper = null;
      amount.exact = true;
    } else if (amount.exact) {
      amount.upper = null;
    }
  };

  ns.normalizeReadingPeriodModes = function normalizeReadingPeriodModes(preview, preferredMode = null) {
    if (!preview.readingPeriod) preview.readingPeriod = {};
    if (!preview.readingPeriod.callPeriod) {
      preview.readingPeriod.callPeriod = { alwaysOpen: false, limited: true, recurring: false };
    }
    if (!preview.readingPeriod.submissionCap) {
      preview.readingPeriod.submissionCap = { hasThis: false, amount: null };
    } else {
      preview.readingPeriod.submissionCap.hasThis = Boolean(preview.readingPeriod.submissionCap.hasThis);
      if (preview.readingPeriod.submissionCap.amount === "") {
        preview.readingPeriod.submissionCap.amount = null;
      }
    }

    const callPeriod = preview.readingPeriod.callPeriod;
    const modePriority = ["alwaysOpen", "limited", "recurring"];
    const activeModes = modePriority.filter((mode) => Boolean(callPeriod[mode]));
    const resolvedMode = preferredMode && modePriority.includes(preferredMode)
      ? preferredMode
      : activeModes[0] || "limited";

    modePriority.forEach((mode) => {
      callPeriod[mode] = mode === resolvedMode;
    });
  };

  ns.normalizeEligibilityAutomation = function normalizeEligibilityAutomation(preview) {
    preview.useAiEligibility = Boolean(preview?.useAiEligibility);
    preview.aiEligibilityLoading = Boolean(preview?.aiEligibilityLoading);
    preview.aiEligibilityError = typeof preview?.aiEligibilityError === "string" ? preview.aiEligibilityError : "";
    preview.aiEligibilityPreview = preview?.aiEligibilityPreview && typeof preview.aiEligibilityPreview === "object"
      ? {
          eligibility: { ...(preview.aiEligibilityPreview.eligibility || {}) },
          eligibilityText: typeof preview.aiEligibilityPreview.eligibilityText === "string"
            ? preview.aiEligibilityPreview.eligibilityText
            : "",
        }
      : null;
  };

  ns.isContestType = function isContestType(preview) {
    return Boolean(preview?.callTypes?.contest) || /contest/i.test(String(preview?.type || ""));
  };

  ns.hasMeaningfulLimit = function hasMeaningfulLimit(preview) {
    const values = [
      preview?.length?.minimumWordCount,
      preview?.length?.maximumWordCount,
      preview?.length?.minimumPageCount,
      preview?.length?.maximumPageCount,
      preview?.length?.minimumLineCount,
      preview?.length?.maximumLineCount,
      preview?.minPiecesPerSub,
      preview?.maxPiecesPerSub,
    ];

    return values.some((value) => Number(value || 0) > 0);
  };

  ns.validatePreview = function validatePreview(preview) {
    const errors = [];
    const title = String(preview?.title || "").trim();
    const selectedGenres = ns.getSelectedPreviewGenres(preview);
    const selectedMediums = Object.entries(preview?.medium || {})
      .filter(([, enabled]) => Boolean(enabled))
      .map(([medium]) => medium);
    const callPeriod = preview?.readingPeriod?.callPeriod || {};
    const activeModes = ["alwaysOpen", "limited", "recurring"].filter((mode) => Boolean(callPeriod[mode]));
    const windows = Array.isArray(preview?.readingPeriod?.subWindows) ? preview.readingPeriod.subWindows : [];
    const usableWindows = windows.filter((win) => win?.openDate || win?.closeDate);
    const status = String(preview?.status || "").trim();
    const numericPairs = [
      ["Word count", preview?.length?.minimumWordCount, preview?.length?.maximumWordCount],
      ["Page count", preview?.length?.minimumPageCount, preview?.length?.maximumPageCount],
      ["Line count", preview?.length?.minimumLineCount, preview?.length?.maximumLineCount],
      ["Pieces per submission", preview?.minPiecesPerSub, preview?.maxPiecesPerSub],
    ];

    if (!title) errors.push("Title is required.");
    if (!ns.hasMeaningfulText(preview?.description || "")) errors.push("Description / guidelines are required.");
    if (!selectedMediums.length) errors.push("Select at least one medium.");
    if (!selectedGenres.length) errors.push("Select at least one genre.");
    if (!Array.isArray(preview?.subGenre) || preview.subGenre.length === 0) {
      errors.push("Select at least one subgenre.");
    }
    if (!["job", "internship", "volunteer", "fellowship", "grant", "residency"].includes(String(preview?.type || "").trim())
      && !ns.hasMeaningfulLimit(preview)) {
      errors.push("Add at least one submission limit.");
    }
    if (ns.typeRequiresGenreStyle(preview) && !String(preview?.genreStyle || "").trim()) {
      errors.push("Select a style for the chosen genre.");
    }
    // Theme title removing
    // if (preview?.theme?.isThemedCall && !String(preview?.theme?.title || "").trim()) {
    //   errors.push("Theme title is required for themed calls.");
    // }
    if (activeModes.length !== 1) {
      errors.push("Choose exactly one reading period mode.");
    } else if (activeModes[0] !== "alwaysOpen" && !usableWindows.length) {
      errors.push("Add at least one reading window for limited or recurring calls.");
    }

    usableWindows.forEach((win) => {
      if (win?.openDate && win?.closeDate && win.openDate > win.closeDate) {
        errors.push("Reading period open date must be on or before close date.");
      }
    });

    const capAmount = preview?.readingPeriod?.submissionCap?.amount;
    if (preview?.readingPeriod?.submissionCap?.hasThis && capAmount != null && capAmount !== "" && Number(capAmount) <= 0) {
      errors.push("Enter a submission cap amount greater than zero.");
    }

    if (status && !ns.STATUS_OPTIONS.includes(status)) {
      errors.push(`Status must be one of: ${ns.STATUS_OPTIONS.join(", ")}.`);
    }

    numericPairs.forEach(([label, min, max]) => {
      if (min != null && max != null && min > max) {
        errors.push(`${label}: minimum cannot be greater than maximum.`);
      }
    });

    if (preview?.payment?.pays) {
      if (ns.isContestType(preview)) {
        const totalAwarded = Number(preview?.payment?.prize?.totalCashPrize || 0);
        const topPrize = Number(preview?.payment?.additional?.topPrize || 0);
        const secondPrize = Number(preview?.payment?.additional?.secondPrize || 0);
        const thirdPrize = Number(preview?.payment?.additional?.thirdPrize || 0);

        if (totalAwarded <= 0 && topPrize <= 0 && secondPrize <= 0 && thirdPrize <= 0) {
          errors.push("Enter at least one contest prize amount or total awarded.");
        }
      } else {
        const paymentTypes = Object.values(preview?.payment?.type || {}).some(Boolean);
        const lower = Number(preview?.payment?.amount?.lower || 0);
        const upper = Number(preview?.payment?.amount?.upper || 0);
        const exact = Boolean(preview?.payment?.amount?.exact);
        const unspecified = Boolean(preview?.payment?.amount?.unspecified);

        if (!paymentTypes) errors.push("Select at least one payment type.");
        if (unspecified) {
          // Amount is intentionally left blank.
        } else if (exact) {
          if (lower <= 0) errors.push("Enter an exact payment amount.");
        } else {
          if (lower <= 0 || upper <= 0) errors.push("Enter both lower and upper payment amounts for a range.");
          if (lower > 0 && upper > 0 && lower > upper) {
            errors.push("Payment range lower amount cannot exceed upper amount.");
          }
        }
      }
    }

    if (preview?.fee?.charges && Number(preview?.fee?.amount || 0) <= 0) {
      errors.push("Enter a submission fee amount when fees are enabled.");
    }

    return errors;
  };

  ns.detectPreviewGenre = function detectPreviewGenre(preview) {
    const selectedGenres = ns.getSelectedPreviewGenres(preview);
    if (selectedGenres.length === 1 && ns.TYPE_OPTIONS_BY_GENRE[selectedGenres[0]]) {
      return selectedGenres[0];
    }
    if (selectedGenres.length > 1) return "general";
    if (preview?.detectedGenre && ns.TYPE_OPTIONS_BY_GENRE[preview.detectedGenre]) {
      return preview.detectedGenre;
    }
    return "general";
  };

  ns.getTypeOptionsForPreview = function getTypeOptionsForPreview(preview) {
    const detectedGenre = ns.detectPreviewGenre(preview);
    return ns.TYPE_OPTIONS_BY_GENRE[detectedGenre] || ns.TYPE_OPTIONS_BY_GENRE.general || ["general"];
  };

  ns.buildCallTypesFromType = function buildCallTypesFromType(type) {
    const t = String(type || "").trim();
    const isContest = /contest/i.test(t) || t === "contest";
    const isBook = /bookLength|chapbook/i.test(t);

    return {
      general: !isContest && t !== "anthology" && t !== "pitch",
      contest: isContest,
      anthology: t === "anthology",
      pitch: t === "pitch",
      book: isBook,
    };
  };

  ns.syncPreviewTypeToCallTypes = function syncPreviewTypeToCallTypes(preview) {
    preview.callTypes = ns.buildCallTypesFromType(preview?.type);
    preview.details = { ...(preview.details || {}), variant: preview?.type || null };
  };

  ns.autoSelectTypeFromTitle = function autoSelectTypeFromTitle(preview) {
    const titleSignals = ns.inferTitleDrivenType(preview?.title);
    const typeOptions = ns.getTypeOptionsForPreview(preview);
    const currentType = String(preview?.type || "").trim();

    if (titleSignals.type !== "general" && typeOptions.includes(titleSignals.type)) {
      if (currentType !== titleSignals.type) {
        preview.type = titleSignals.type;
        ns.syncPreviewTypeToCallTypes(preview);
        return true;
      }
    }

    return false;
  };

  ns.normalizeSubGenreByGenre = function normalizeSubGenreByGenre(preview) {
    const current = preview?.subGenreByGenre || {};
    const next = {};
    ["fiction", "nonfiction", "poetry", "hybrid", "multimedia"].forEach((genre) => {
      const values = Array.isArray(current[genre]) ? current[genre] : [];
      next[genre] = Array.from(new Set(values.filter(Boolean)));
    });
    preview.subGenreByGenre = next;
  };

  ns.ensureDefaultSubgenresForSelectedGenres = function ensureDefaultSubgenresForSelectedGenres(preview) {
    const genre = preview?.genre || {};
    let changed = false;

    Object.entries(genre).forEach(([genreName, enabled]) => {
      if (!enabled) return;
      const options = ns.SUBGENRE_OPTIONS_BY_GENRE[genreName] || [];
      const selected = preview.subGenreByGenre?.[genreName] || [];
      if (options.length && selected.length === 0) {
        const defaults = genreName === "multimedia"
          ? [options[0], options[1]]
          : [options[0]];
        preview.subGenreByGenre[genreName] = defaults.length ? defaults : [options[0]];
        changed = true;
      }
    });

    return changed;
  };

  ns.normalizeStyleByGenre = function normalizeStyleByGenre(preview) {
    const current = preview?.styleByGenre || {};
    const next = {};
    const isBookType = /^bookLength/i.test(String(preview?.type || "").trim());
    ["fiction", "nonfiction", "poetry", "hybrid", "multimedia"].forEach((genre) => {
      const options = isBookType ? (ns.BOOK_STYLE_OPTIONS || []) : ns.getStyleOptionsForGenre(genre);
      if (!options.length) {
        next[genre] = [];
        return;
      }
      const values = Array.isArray(current[genre]) ? current[genre] : [];
      next[genre] = values.length && options.includes(values[0]) ? [values[0]] : [];
    });
    preview.styleByGenre = next;
  };

  ns.ensureDefaultStylesForSelectedGenres = function ensureDefaultStylesForSelectedGenres(preview) {
    const genre = preview?.genre || {};
    const isBookType = /^bookLength/i.test(String(preview?.type || "").trim());
    let changed = false;

    Object.entries(genre).forEach(([genreName, enabled]) => {
      if (!enabled) return;
      const options = isBookType ? (ns.BOOK_STYLE_OPTIONS || []) : ns.getStyleOptionsForGenre(genreName);
      const selected = preview.styleByGenre?.[genreName] || [];
      if (options.length && selected.length === 0) {
        preview.styleByGenre[genreName] = [options[0]];
        changed = true;
      }
    });

    return changed;
  };

  ns.syncPreviewStyles = function syncPreviewStyles(preview) {
    ns.normalizeStyleByGenre(preview);
    ns.ensureDefaultStylesForSelectedGenres(preview);

    if (!ns.typeRequiresGenreStyle(preview)) {
      preview.genreStyle = null;
      return;
    }

    const type = String(preview?.type || "").trim();
    const isBookType = /^bookLength/i.test(type);

    if (isBookType) {
      const bookOptions = ns.BOOK_STYLE_OPTIONS || [];
      const selectedGenres = ns.getSelectedPreviewGenres(preview);
      const firstBookType = selectedGenres
        .map((g) => (preview.styleByGenre?.[g] || [])[0])
        .find((s) => s && bookOptions.includes(s));
      preview.genreStyle = firstBookType
        || (bookOptions.includes(preview.genreStyle) ? preview.genreStyle : null)
        || bookOptions[0] || null;
      if (!preview.callMetadata) preview.callMetadata = {};
      preview.callMetadata.bookType = preview.genreStyle || null;
      return;
    }

    const selectedGenres = ns.getSelectedPreviewGenres(preview)
      .filter((genre) => ns.getStyleOptionsForGenre(genre).length > 0);

    const styles = [];
    selectedGenres.forEach((genre) => {
      const selected = preview.styleByGenre?.[genre] || [];
      selected.forEach((item) => styles.push(item));
    });

    preview.genreStyle = styles[0] || null;
  };

  ns.syncPreviewSubGenres = function syncPreviewSubGenres(preview) {
    ns.normalizeSubGenreByGenre(preview);
    ns.ensureDefaultSubgenresForSelectedGenres(preview);

    const selectedGenres = Object.entries(preview.genre || {})
      .filter(([, enabled]) => Boolean(enabled))
      .map(([genre]) => genre);

    const merged = [];
    selectedGenres.forEach((genre) => {
      const subgenres = preview.subGenreByGenre?.[genre] || [];
      subgenres.forEach((item) => merged.push(item));
    });

    preview.subGenre = Array.from(new Set(merged));
  };

  ns.initializePreviewType = function initializePreviewType(preview) {
    ns.normalizeEligibilityAutomation(preview);
    ns.normalizePaymentAmount(preview);
    ns.normalizeReadingPeriodModes(preview);
    ns.autoSelectTypeFromTitle(preview);
    const options = ns.getTypeOptionsForPreview(preview);
    if (!options.includes(preview?.type)) {
      preview.type = options[0] || "general";
    }
    ns.normalizeStyleByGenre(preview);
    ns.normalizeSubGenreByGenre(preview);
    ns.syncPreviewStyles(preview);
    ns.syncPreviewSubGenres(preview);
    ns.syncPreviewTypeToCallTypes(preview);
  };

  ns.formatTypeLabel = function formatTypeLabel(type) {
    if (type === "general") return "General";
    return String(type || "")
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/^./, (c) => c.toUpperCase());
  };
})();
